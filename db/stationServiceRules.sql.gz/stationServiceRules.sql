--
-- PostgreSQL database dump
--

\restrict hsfVllipSaK6NywVhhjBdQ4XUibNuc9nibLcHGPViCBjNrC0avx6uFQ83zNZBTV

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: stationServiceRules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."stationServiceRules" (
    "stationID" integer NOT NULL,
    "serviceID" integer NOT NULL,
    "minimumStanding" double precision DEFAULT '-10'::integer NOT NULL,
    "minimumCharSecurity" double precision DEFAULT '-10'::integer NOT NULL,
    "maximumCharSecurity" double precision DEFAULT 10 NOT NULL,
    "minimumCorpSecurity" double precision DEFAULT '-10'::integer NOT NULL,
    "maximumCorpSecurity" double precision DEFAULT 10 NOT NULL,
    "discountPerGoodStandingPoint" double precision DEFAULT 0 NOT NULL,
    "surchargePerBadStandingPoint" double precision DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "stationServiceRules"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."stationServiceRules" IS 'MADE: who a player-owned station lets use each service, and at what cost (svc::outposts).';


--
-- Name: stationServiceRules stationServiceRules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."stationServiceRules"
    ADD CONSTRAINT "stationServiceRules_pkey" PRIMARY KEY ("stationID", "serviceID");


--
-- PostgreSQL database dump complete
--

\unrestrict hsfVllipSaK6NywVhhjBdQ4XUibNuc9nibLcHGPViCBjNrC0avx6uFQ83zNZBTV

