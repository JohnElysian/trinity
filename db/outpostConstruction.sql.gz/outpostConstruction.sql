--
-- PostgreSQL database dump
--

\restrict CdwSJK5a2wxTpbW25yl2hb2kDWie5sq3S8BwnT63KScxa9rsWtMhq5LQfJ4X3gi

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: outpostConstruction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."outpostConstruction" (
    "platformID" integer NOT NULL,
    "ownerID" integer NOT NULL,
    "solarSystemID" integer NOT NULL,
    "builderID" integer DEFAULT 0 NOT NULL,
    "startedAt" bigint NOT NULL,
    "doneAt" bigint NOT NULL
);


--
-- Name: TABLE "outpostConstruction"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."outpostConstruction" IS 'MADE: outpost platforms under construction, and when each becomes a station (svc::outposts).';


--
-- Name: outpostConstruction outpostConstruction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."outpostConstruction"
    ADD CONSTRAINT "outpostConstruction_pkey" PRIMARY KEY ("platformID");


--
-- PostgreSQL database dump complete
--

\unrestrict CdwSJK5a2wxTpbW25yl2hb2kDWie5sq3S8BwnT63KScxa9rsWtMhq5LQfJ4X3gi

