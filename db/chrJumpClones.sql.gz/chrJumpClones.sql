--
-- PostgreSQL database dump
--

\restrict xsw1exmaj2U1C7XpTIgbeYCNXzTffIrjq8MDMcK8NscsbrVfURQt1SEAJ5GrluK

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrJumpClones; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrJumpClones" (
    "jumpCloneID" integer DEFAULT nextval('public.dyn_id_seq'::regclass) NOT NULL,
    "ownerID" integer NOT NULL,
    "locationID" integer NOT NULL,
    "createdAt" bigint DEFAULT 0 NOT NULL
);


--
-- Name: TABLE "chrJumpClones"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."chrJumpClones" IS 'MADE: jump clones, in stations or ships with a clone vat bay; implants are entity rows located on the clone (svc::clones).';


--
-- Name: chrJumpClones chrJumpClones_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrJumpClones"
    ADD CONSTRAINT "chrJumpClones_pkey" PRIMARY KEY ("jumpCloneID");


--
-- Name: chrJumpClones_location; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chrJumpClones_location" ON public."chrJumpClones" USING btree ("locationID");


--
-- Name: chrJumpClones_owner; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "chrJumpClones_owner" ON public."chrJumpClones" USING btree ("ownerID");


--
-- PostgreSQL database dump complete
--

\unrestrict xsw1exmaj2U1C7XpTIgbeYCNXzTffIrjq8MDMcK8NscsbrVfURQt1SEAJ5GrluK

