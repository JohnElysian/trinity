--
-- PostgreSQL database dump
--

\restrict 8T27MLJ1whzAut7mz2Rv8cDI7D2rsKiLYPblSDXm4A0uYCczYebx51UwVYuUbY2

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dgmEffects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."dgmEffects" (
    "effectID" integer NOT NULL,
    "effectName" text,
    "effectCategory" integer,
    "preExpression" integer,
    "postExpression" integer,
    description text,
    guid text,
    "graphicID" integer,
    "isOffensive" integer,
    "isAssistance" integer,
    "durationAttributeID" integer,
    "trackingSpeedAttributeID" integer,
    "dischargeAttributeID" integer,
    "rangeAttributeID" integer,
    "falloffAttributeID" integer,
    "disallowAutoRepeat" integer,
    published integer,
    "displayName" text,
    "isWarpSafe" integer,
    "rangeChance" integer,
    "electronicChance" integer,
    "propulsionChance" integer,
    distribution integer,
    "sfxName" text,
    "npcUsageChanceAttributeID" integer,
    "npcActivationChanceAttributeID" integer,
    "fittingUsageChanceAttributeID" integer
);


--
-- Data for Name: dgmEffects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."dgmEffects" ("effectID", "effectName", "effectCategory", "preExpression", "postExpression", description, guid, "graphicID", "isOffensive", "isAssistance", "durationAttributeID", "trackingSpeedAttributeID", "dischargeAttributeID", "rangeAttributeID", "falloffAttributeID", "disallowAutoRepeat", published, "displayName", "isWarpSafe", "rangeChance", "electronicChance", "propulsionChance", distribution, "sfxName", "npcUsageChanceAttributeID", "npcActivationChanceAttributeID", "fittingUsageChanceAttributeID") FROM stdin;
4	shieldBoosting	1	183	131		effects.ShieldBoosting	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	0	\N	\N	\N	\N
7	speedBoost	1	3517	3518		effects.SpeedBoost	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
9	missileLaunching	2	114	89	Launches a missile	effects.MissileDeployment	\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
10	targetAttack	2	115	89	Combat	effects.Laser	\N	1	0	51	160	6	54	158	0	0		0	0	0	0	2	\N	\N	\N	\N
11	loPower	0	131	131	Requires a low power slot.		295	0	0	\N	\N	\N	\N	\N	0	1	Low power	0	0	0	0	\N	\N	\N	\N	\N
12	hiPower	0	131	131	Requires a high power slot.		293	0	0	\N	\N	\N	\N	\N	0	1	High power	0	0	0	0	\N	\N	\N	\N	\N
13	medPower	0	131	131	Requires a medium power slot.		294	0	0	\N	\N	\N	\N	\N	0	1	Medium power	0	0	0	0	\N	\N	\N	\N	\N
16	online	1	633	400	this is the online effect		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
17	mining	2	3134	184	mining of ore	effects.Mining	\N	0	0	73	\N	\N	54	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
18	shieldTransfer	2	185	89	Boosts the shield of the target ship by draining the doers ships shield.	effects.ShieldTransfer	\N	0	1	73	\N	6	87	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
21	shieldCapacityBonusOnline	4	199	201	Increases maximum shield capacity.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
22	maxVelocityBonus	4	205	206	Enhances the maximum speed of the ship.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
25	capacitorCapacityBonus	4	227	228			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
26	structureRepair	1	131	233		effects.StructureRepair	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
27	armorRepair	1	131	236	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	0	\N	\N	\N	\N
29	modifyTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
31	energyTransfer	2	131	258		effects.EnergyTransfer	\N	0	1	73	\N	6	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
32	energyVampire	2	270	131	Steals power from the target.	effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
34	projectileFired	2	115	131		effects.ProjectileFired	\N	1	0	51	160	6	54	158	0	0		0	0	0	0	2	\N	\N	\N	\N
36	energyDestabilization	2	286	131	Drains power from the target.	effects.EnergyDestabilization	\N	1	0	73	\N	6	98	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
38	empWave	1	288	131	Triggering of an EMP wave being broadcast into space.	effects.EMPWave	\N	1	0	73	\N	6	99	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
39	warpScramble	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	\N	0	0		0	0	0	0	1	None	\N	\N	\N
40	launcherFitted	0	373	319			\N	0	0	\N	\N	\N	\N	0	0	0		0	0	0	0	\N	\N	\N	\N	\N
42	turretFitted	0	379	305	This is just a test. Ehmm. If your'e reading this in an error message, your ship probably doesn't have any turret slot left.		\N	0	0	\N	\N	\N	\N	0	0	0		0	0	0	0	\N	\N	\N	\N	\N
46	shipScan	2	131	402	Scans the energy status, cargo and hardware of a given ship.	effects.ShipScan	\N	0	0	73	\N	6	125	510	0	0		0	0	0	0	0	\N	\N	\N	\N
47	cargoScan	2	131	403	Scan the cargo of a targeted ship.	effects.CargoScan	\N	0	0	73	\N	6	126	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
48	powerBooster	1	404	131	Consumes power booster charges to increase the available power in the capacitor.		\N	0	0	73	\N	\N	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
50	modifyShieldRechargeRate	4	439	440			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
51	modifyPowerRechargeRate	4	443	444			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
53	ecmBurst	1	471	131		effects.ECMBurst	\N	1	0	73	\N	6	142	158	0	0		0	1	1	0	2	\N	\N	\N	\N
54	targetPassively	2	472	131	Targets an object without letting it know.		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
55	targetHostiles	1	131	473	Target all hostile ships within range (if electronics can handle it).		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
56	powerOutputMultiply	4	477	478			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
57	shieldCapacityMultiply	4	485	486			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
58	capacitorCapacityMultiply	4	483	484			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
59	cargoCapacityMultiply	4	490	491			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
60	structureHPMultiply	4	494	495			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
61	agilityBonus	0	500	501			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
62	maxPassengersBonus	0	506	507			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
63	armorHPMultiply	4	509	510			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
67	miningLaser	2	3134	184	Mining of ore.	effects.Laser	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	2	None	\N	\N	\N
70	agilityMultiply	0	566	567	Scale the agility of a ship.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
73	repairCostMultiply	0	578	579			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
81	surveyScan	1	131	602	Scanning an asteroid to determine any helpful information.	effects.SurveyScan	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
82	corporationMemberLimitBonus	0	609	610	Modify the maximum number of members a character is capable of managing in a corporation.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
87	cpuUsageMultiply	0	638	639	Scales amount of CPU used by module(s).		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
88	miningDurationMultiply	0	646	647	Scales the mining duration of a mining laser module.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
89	projectileWeaponSpeedMultiply	4	654	655	Scale the projectile weapon firing speed.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
91	energyWeaponDamageMultiply	4	668	671	Scales the damage done by all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
92	projectileWeaponDamageMultiply	4	667	670	Scales the damage done by all fitted projectile weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
93	hybridWeaponDamageMultiply	4	669	672	Scales the damage done by all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
95	energyWeaponSpeedMultiply	4	681	683	Scales the rate of fire of all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
96	hybridWeaponSpeedMultiply	4	682	684	Scales the rate of fire of all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
97	turretWeaponAccuracyMultiply	0	703	705	Scale the accuracy of all fitted turret weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
100	hybridWeaponAccuracyMultiply	0	698	701	Scales the accuracy of all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
101	useMissiles	1	131	131	The ammunition loaded into this item defines its operation.		\N	0	0	51	\N	6	\N	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
102	mineLaying	1	114	131	Drops a mine in space.		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
103	defenderMissileLaunching	1	706	131	Drops a defender missile in space to go do its thing.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
104	fofMissileLaunching	1	707	131	Launches an FOF missile.  Auto targets at someone hostile to you.		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
105	shieldResonanceMultiplyOnline	4	431	434			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
106	miningAmountMultiply	0	715	716	Scales the amount mined by all fitted mining lasers.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
107	characterMissileDamageMultiply	0	721	722	Increases the damage scaling done to missiles damage for missiles launched by the character.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
109	turretWeaponCapacitorNeedMultiply	0	743	745	Scales the capacitor need for all the fitted turret weapons.		\N	0	0	\N	\N	\N	\N	\N	0	1	turretWeaponCapacitorMultiply	0	0	0	0	\N	\N	\N	\N	\N
110	characterBlueprintResearchTimeBonus	0	750	751	Modifies the aptitude the character has for researching blueprints by a given percentage.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
111	characterBlueprintManufactureTimeBonus	0	756	757	Modifies the aptitude the character has for manufacturing from blueprints by a given percentage.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
112	characterCharismaSkillTrainingTimeBonus	0	778	779	Modifies the speed at which skills with charisma as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
113	characterIntelligenceSkillTrainingTimeBonus	0	780	781	Modifies the speed at which skills with intelligence as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
114	characterMemorySkillTrainingTimeBonus	0	782	783	Modifies the speed at which skills with memory as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
115	characterPerceptionSkillTrainingTimeBonus	0	785	784	Modifies the speed at which skills with perception as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
116	characterWillpowerSkillTrainingTimeBonus	0	786	787	Modifies the speed at which skills with willpower as their primary attribute are trained.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
118	electronicAttributeModifyOnline	4	846	847	Modifies the targeting range of a ship and also the maximum number of targets that its electronics can lock and also how long it takes to lock targets.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
120	turretWeaponRangeTrackingSpeedMultiplyOnline	4	884	885	Scales the range and tracking speed of turret weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
123	turretWeaponRangeTrackingSpeedMultiplyActivate	1	884	885	Modifies maximum turret weapon range and tracking speed for the length of the duration.	effects.TurretWeaponRangeTrackingSpeedMultiplyActivate	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
124	scanStrengthBonusTarget	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	0	1	73	\N	6	\N	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
126	turretWeaponRangeTrackingSpeedMultiplyTarget	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.TurretWeaponRangeTrackingSpeedMultiplyTarget	\N	0	1	73	\N	6	54	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
127	torpedoLaunching	1	114	131		effects.TorpedoDeployment	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
130	cheatTeleDock	2	1018	131	Automatically docks at the targeted station.		\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
131	cheatTeleGate	2	1019	131	Automatically invokes the destination of the target stargate.		\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
132	skillEffect	0	1071	1070	masks skill level onto skill modules.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
146	damageMultiplierSkillBonus	0	1167	1168	Boost of damageMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1	DamageBonus	0	0	0	0	\N	\N	\N	\N	\N
152	skillBoostDamageMultiplierBonus	0	1167	1168	Boost of damageMultiplierBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	1	SkillBoostDamageMultiplierBonus	0	0	0	0	\N	\N	\N	\N	\N
157	largeHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeHybridTurret	0	1188	1189	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
159	mediumEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumEnergyTurret	0	1200	1201	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
160	mediumHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumHybridTurret	0	1206	1207	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
161	mediumProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringMediumProjectileTurret	0	1212	1213	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
162	largeEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeEnergyTurret	0	1174	1175	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
163	rapidFiringSkillBoostRofBonus	0	1217	1218	Boost of rofBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
167	sharpshooterSkillBoostRangeSkillBonus	0	1241	1242	Boost of rangeSkillBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
172	smallEnergyTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallEnergyTurret	0	1266	1267	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
173	smallHybridTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallHybridTurret	0	1272	1273	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
174	smallProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringSmallProjectileTurret	0	1278	1279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
187	caldariCruiserSkillBoostCcTRangeBonus	0	1331	1332	Boost of ccTRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
189	caldariFrigateSkillBoostCfTRangeBonus	0	1338	1339	Boost of cfTRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
204	signatureAnalysisSkillBoostScanspeedBonus	0	1403	1404	Boost of scanspeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
205	signatureAnalysisScanspeedBonusPostPercentScanSpeedLocationShip	0	1407	1408	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Targeting Speed Bonus	0	0	0	0	\N	\N	\N	\N	\N
206	longRangeTargetingSkillBoostMaxTargetRangeBonus	0	1412	1413	Boost of MaxTargetRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
208	propulsionJammingSkillBoostDurationBonus	0	1423	1424	Boost of durationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
209	propulsionJammingDurationBonusPostPercentDurationLocationShipModulesRequiringPropulsionJamming	0	1429	1430	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
210	sensorLinkingDurationBonusPostPercentDurationLocationShipModulesRequiringSensorLinking	0	1435	1436	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
211	sensorUpgradesSkillBoostCpuNeedBonus	0	1440	1441	Boost of cpuNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
212	sensorUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringSensorUpgrades	0	1446	1447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	CPU need reduction	0	0	0	0	\N	\N	\N	\N	\N
213	targetingSkillBoostMaxTargetBonus	0	1451	1452	Boost of maxTarget Bonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
214	targetingMaxTargetBonusModAddMaxLockedTargetsLocationChar	0	1453	1454	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
215	weaponDisruptionDurationBonusPostPercentDurationLocationShipModulesRequiringWeaponDisruption	0	1459	1460	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Duration Bonus	0	0	0	0	\N	\N	\N	\N	\N
216	electronicWarfareSkillBoostDurationBonus	0	1464	1465	Boost of DurationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
218	engineeringSkillBoostPowerOutputBonus	0	1475	1476	Boost of PowerOutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
220	energyManagementSkillBoostCapRechargeBonus	0	1482	1483	Boost of CapRechargeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
222	navigationSkillBoostVelocityBonus	0	1491	1492	Boost of velocityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
223	navigationVelocityBonusPostPercentMaxVelocityLocationShip	0	1494	1495	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
225	accerationControlSkillBoostCapNeedBonus	0	1504	1505	Boost of capNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
227	accerationControlCapNeedBonusPostPercentCapacitorNeedLocationShipGroupAfterburner	0	1516	1517	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor need reduction	0	0	0	0	\N	\N	\N	\N	\N
228	accerationControlSkillBoostSpeedFBonus	0	1521	1522	Boost of speedFBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
230	afterburnerDurationBonusPostPercentDurationLocationShipModulesRequiringAfterburner	0	1531	1532	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
232	evasiveManuveringSkillBoostAgilityBonus	0	1541	1542	Boost of agilityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
234	warpdriveoperationSkillBoostWarpCapacitorNeedBonus	0	1549	1550	Boost of warpCapacitorNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
235	warpdriveoperationWarpCapacitorNeedBonusPostPercentWarpCapacitorNeedLocationShip	0	1553	1554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
236	energyEmmisionSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringEnergyEmmisionSystems	0	1559	1560	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor Need Reduction	0	0	0	0	\N	\N	\N	\N	\N
239	corporationManagementSkillBoostCorporationMemberBonus	0	1574	1575	Boost of corporationMemberBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
242	accerationControlSpeedFBonusPostPercentSpeedFactorLocationShipGroupAfterburner	0	1587	1588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Aterburner Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
243	highSpeedManuveringSkillBoostCapacitorNeedMultiplier	0	1591	1592	Boost of capacitorNeedMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
244	highSpeedManuveringCapacitorNeedMultiplierPostPercentCapacitorNeedLocationShipModulesRequiringHighSpeedManuvering	0	1597	1598	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
246	sensorUpgradesSkillBoostPowerNeedBonus	0	1614	1615	Boost of PowerNeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
251	hullUpgradesSkillBoostHullHpBonus	0	1631	1632	Boost of hullHpBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
253	shadowBarrageDmgMultiplierWithDamageMultiplierPostPercentBarrageDmgMutator	0	1645	1646	Set barrageDmgMultiplier to damageMultiplier modified (PostPercent) by BarrageDmgMutator		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
254	shadowBarrageFalloffWithFalloffPostPercentBarrageFalloffMutator	0	1657	1658	Set barrageFalloff to falloff modified (PostPercent) by barrageFalloffMutator		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
263	barrage	2	1659	1104	Barrage Attack, Attack with barrageDmgMultiplier as a damage multiplier	effects.Barrage	\N	1	0	51	160	6	54	328	0	1	Barrage Attack	0	0	0	0	0	\N	\N	\N	\N
267	amarrCruiserSkillBoostPowerOutputBonus	0	1676	1677	Boost of powerOutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
270	hullUpgradesSkillBoostArmorHpBonus	0	1689	1690	Boost of armorHpBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
271	hullUpgradesArmorHpBonusPostPercentHpLocationShip	0	1691	1692	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Armor Hp Bonus	0	0	0	0	\N	\N	\N	\N	\N
272	repairSystemsDurationBonusPostPercentDurationLocationShipModulesRequiringRepairSystems	0	1697	1698	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
273	shieldUpgradesPowerNeedBonusPostPercentPowerLocationShipModulesRequiringShieldUpgrades	0	1703	1704	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Power need reduction	0	0	0	0	\N	\N	\N	\N	\N
274	energyManagementSkillBoostCapacitorBonus	0	1707	1708	Boost of capacitorBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
277	tacticalshieldManipulationSkillBoostUniformityBonus	0	1721	1722	Boost of uniformityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
279	shieldEmmisionSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringShieldEmmisionSystems	0	1732	1733	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor need Bonus	0	0	0	0	\N	\N	\N	\N	\N
280	shieldManagementSkillBoostShieldCapacityBonus	0	1737	1738	Boost of shieldCapacityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
283	shieldoperationSkillBoostRechargeratebonus	0	1751	1752	Boost of rechargeratebonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
287	controlledBurstsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringGunnery	0	1774	1775	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor Need Reductin	0	0	0	0	\N	\N	\N	\N	\N
288	skillBoostTrackingSpeedMultiplier	0	1782	1783	Boost of trackingSpeedMultiplier by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
289	motionPredictionTrackingSpeedMultiplierPostPercentTrackingSpeedLocationShipModulesRequiringGunnery	0	1786	1787	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Tracking speed bonus	0	0	0	0	\N	\N	\N	\N	\N
290	sharpshooterRangeSkillBonusPostPercentMaxRangeLocationShipModulesRequiringGunnery	0	1790	1791	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Range Bonus	0	0	0	0	\N	\N	\N	\N	\N
297	skillBoostFalloffBonus	0	1806	1807	Boost of falloffBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
298	surgicalStrikeFalloffBonusPostPercentFalloffLocationShipModulesRequiringGunnery	0	1810	1811	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Falloff Bonus	0	0	0	0	\N	\N	\N	\N	\N
301	empathySkillBoostCharismaBonus	0	1824	1825	Boost of charismaBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
302	empathyCharismaBonusModAddCharismaLocationChar	0	1826	1827	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Charisma Bonus	0	0	0	0	\N	\N	\N	\N	\N
303	instantRecallSkillBoostMemoryBonus	0	1830	1831	Boost of memoryBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
304	instantRecallMemoryBonusModAddMemoryLocationChar	0	1832	1833	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
305	analyticalMindSkillBoostIntelligenceBonus	0	1836	1837	Boost of intelligenceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
306	analyticalMindIntelligenceBonusModAddIntelligenceLocationChar	0	1838	1839	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Inteligence bonus	0	0	0	0	\N	\N	\N	\N	\N
307	ironWillSkillBoostWillpowerBonus	0	1842	1843	Boost of willpowerBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
308	ironWillWillpowerBonusModAddWillpowerLocationChar	0	1844	1845	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Willpower bonus	0	0	0	0	\N	\N	\N	\N	\N
309	spatialAwarenessSkillBoostPerceptionBonus	0	1848	1849	Boost of perceptionBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
310	spatialAwarenessPerceptionBonusModAddPerceptionLocationChar	0	1850	1851	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Preception bonus	0	0	0	0	\N	\N	\N	\N	\N
312	signatureAnalysisMaxTargetRangeBonusPostPercentMaxTargetRangeLocationShip	0	1857	1858	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
315	dronesSkillBoostMaxActiveDroneBonus	0	1872	1873	Boost of maxActiveDroneBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
316	dronesMaxActiveDroneBonusModAddMaxActiveLocationChar	0	1876	1877	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dronesMaxActiveDroneBonusModAddMaxActiveDronesLocationChar	0	0	0	0	\N	\N	\N	\N	\N
317	amarrTechSkillBoostAmarrTechMutator	0	1894	1895	Boost of amarrTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
318	amarrTechAmarrTechMutatorPostPercentAmarrTechTimePercentLocationChar	0	1898	1899	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Amarr tech skill bonus	0	0	0	0	\N	\N	\N	\N	\N
319	caldariTechSkillBoostCaldariTechMutator	0	1903	1904	Boost of caldariTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
320	caldariTechCaldariTechMutatorPostPercentCaldariTechTimePercentLocationChar	0	1907	1908	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Caldari tech production bonus	0	0	0	0	\N	\N	\N	\N	\N
321	gallenteTechSkillBoostGallenteTechMutator	0	1912	1913	Boost of gallenteTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
322	gallenteTechGallenteTechMutatorPostPercentGallenteTechTimePercentLocationChar	0	1916	1917	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Gallente Tech time	0	0	0	0	\N	\N	\N	\N	\N
325	minmatarTechSkillBoostMinmatarTechMutator	0	1930	1931	Boost of minmatarTechMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
326	minmatarTechMinmatarTechMutatorPostPercentMinmatarTechTimePercentLocationChar	0	1934	1935	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Minmatar tech bonus	0	0	0	0	\N	\N	\N	\N	\N
331	refineryEfficiencySkillBoostRefiningYieldMutator	0	1959	1960	Boost of refiningYieldMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
334	cSOTrainingSkillBoostResearchGangSizeBonus	0	1995	1996	Boost of researchGangSizeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
335	cSOTrainingResearchGangSizeBonusModAddMaxResearchGangSizeShip	0	1999	2000	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
336	battleshipConstructionSkillBoostBattleshipConstructionTimeBonus	0	2004	2005	Boost of battleshipConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
337	battleshipConstructionBattleshipConstructionTimeBonusPostPercentBattleshipConstructionTimeChar	0	2008	2009	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Battleship Construction Time	0	0	0	0	\N	\N	\N	\N	\N
338	cruiserConstructionSkillBoostCruiserConstructionTimeBonus	0	2013	2014	Boost of cruiserConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
339	cruiserConstructionCruiserConstructionTimeBonusPostPercentCruiserConstructionTimeChar	0	2017	2018	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
340	frigateConstructionSkillBoostFrigateConstructionTimeBonus	0	2022	2023	Boost of frigateConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
341	frigateConstructionFrigateConstructionTimeBonusPostPercentFrigateConstructionTimeChar	0	2026	2027	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
342	industrialConstructionSkillBoostIndustrialConstructionTimeBonus	0	2031	2032	Boost of industrialConstructionTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
343	industrialConstructionIndustrialConstructionTimeBonusPostPercentIndustrialConstructionTimeChar	0	2035	2036	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
344	connectionsSkillBoostConnectionBonusMutator	0	2040	2041	Boost of connectionBonusMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
346	criminalConnectionsSkillBoostCriminalConnectionsMutator	0	2049	2050	Boost of criminalConnectionsMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
348	diplomacySkillBoostDiplomacyMutator	0	2058	2059	Boost of diplomacyMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
349	diplomacyDiplomacyMutatorModAddDiplomacyBonusChar	0	2062	2063	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
350	fasttalkSkillBoostFastTalkMutator	0	2067	2068	Boost of fastTalkMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
352	fasttalkFastTalkMutatorPostPercentFastTalkPercentageChar	0	2074	2075	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
353	ethnicRelationsSkillBoostNonRaceCorporationMembersBonus	0	2081	2082	Boost of nonRaceCorporationMembersBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
354	ethnicRelationsNonRaceCorporationMembersBonusPostPercentMaxNonRaceCorporationMembersChar	0	2085	2086	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
355	ethnicRelationsNonRaceCorporationMembersBonusModAddMaxNonRaceCorporationMembersChar	0	2088	2089	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
356	assaultFormationDamageMultiplierBonusPostPercentDamageMultiplierGangShipModulesRequiringGunnery	0	2092	2093	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
368	gallenteFrigateSkillBoostCpuOutputBonus	0	2157	2158	Boost of cpu OutputBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
389	astrogeologySkillBoostMiningAmountBonus	0	2232	2233	Boost of miningAmountBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
391	astrogeologyMiningAmountBonusPostPercentMiningAmountLocationShipModulesRequiringMining	0	2240	2241	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
392	mechanicHullHpBonusPostPercentHpShip	0	2242	2243	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
394	navigationVelocityBonusPostPercentMaxVelocityShip	0	2248	2249	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
395	evasiveManeuveringAgilityBonusPostPercentAgilityShip	0	2250	2251	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
396	energyGridUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringEnergyGridUpgrades	0	2256	2257	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
397	electronicsCpuOutputBonusPostPercentCpuOutputLocationShipGroupComputer	0	2258	2259	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
399	connectionsConnectionBonusMutatorModAddConnectionsBonusChar	0	2269	2270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
402	criminalConnectionsCriminalConnectionsMutatorModAddCriminalConnectionsBonusChar	0	2278	2279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
403	negotiationSkillBoostNegotiationBonus	0	2283	2284	Boost of NegotiationBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
404	negotiationNegotiationBonusPostPercentNegotiationPercentageChar	0	2287	2288	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
406	socialSkillBoostSocialMutator	0	2296	2297	Boost of socialMutator by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
407	socialSocialMutatorPostPercentSocialBonusChar	0	2300	2301	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
408	largeProjectileTurretDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringLargeProjectileTurret	0	2306	2307	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
412	industrySkillBoostManufacturingTimeBonus	0	2323	2324	Boost of manufacturingTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
413	gunnerySkillBoostTurretSpeeBonus	0	2328	2329	Boost of TurretSpeeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
414	gunneryTurretSpeeBonusPostPercentSpeedLocationShipModulesRequiringGunnery	0	2330	2331	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
415	tradeSkillBoostTradePremiumBonus	0	2339	2340	Boost of tradePremiumBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
416	tradeTradePremiumBonusPostPercentTradePremiumChar	0	2343	2344	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
417	smugglingSkillBoostSmugglingChanceBonus	0	2348	2349	Boost of smugglingChanceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
425	industryManufacturingTimeBonusPostPercentManufactureTimeMultiplierChar	0	2379	2380	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
428	productionEfficiencySkillBoostManufactureCostBonus	0	2393	2394	Boost of manufactureCostBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
429	productionEfficiencyManufactureCostBonusPostPercentManufactureCostMultiplierChar	0	2395	2396	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
430	scienceSkillBoostCopySpeedBonus	0	2400	2401	Boost of CopySpeedBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
431	scienceCopySpeedBonusPostPercentCopySpeedPercentChar	0	2404	2405	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
432	researchSkillBoostBlueprintmanufactureTimeBonus	0	2409	2410	Boost of blueprintmanufactureTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
433	researchBlueprintmanufactureTimeBonusPostPercentProductionTimeResearchSpeedChar	0	2413	2414	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
435	refineryEfficiencyRefiningYieldMutatorPostPercentRefiningYieldPercentageChar	0	2421	2422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
436	missileLauncherOperationSpeedBonusPostPercentSpeedLocationShipModulesRequiringMissileLauncherOperation	0	2429	2430	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
439	learningSkillBoostLearningBonus	0	2446	2447	Boost of learningBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
440	learningLearningBonusPostPercentIntelligenceChar	0	2449	2450	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
441	learningLearningBonusPostPercentWillpowerChar	0	2452	2453	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
442	learningLearningBonusPostPercentPerceptionChar	0	2455	2456	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
443	learningLearningBonusPostPercentCharismaChar	0	2458	2459	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
444	learningLearningBonusPostPercentMemoryChar	0	2461	2462	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
445	energyManagementCapacitorBonusPostPercentCapacityLocationShipGroupCapacitor	0	2468	2469	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
446	shieldManagementShieldCapacityBonusPostPercentCapacityLocationShipGroupShield	0	2472	2473	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
448	scoutDroneOperationSkillBoostDroneRangeBonus	0	2481	2482	Boost of droneRangeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
452	shipVelocityBonusMF	0	2497	2498	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
453	minmatarFrigateSkillLevelPreMulShipBonusMFShip	0	2500	2501	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
456	shipTargetRangeBonusMF	0	2511	2512	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
458	shipCargoBonusMF	0	2515	2516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipCapacityBonusMF	0	0	0	0	\N	\N	\N	\N	\N
459	shipMiningBonusMF	0	2517	2518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
460	caldariFrigateSkillLevelPreMulShipBonusCFShip	0	2524	2525	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
462	shipHybridRangeBonusCF	0	2534	2535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
464	shipShieldCapBonusCF	0	2538	2539	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
466	shipTargetRangeBonusCF	0	2542	2543	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
468	gallenteFrigateSkillLevelPreMulShipBonusGFShip	0	2548	2549	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
469	shipMiningBonusGF	0	2550	2551	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
472	shipHybridTrackingBonusGf	0	2561	2562	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipHybridTrackingBonus	0	0	0	0	\N	\N	\N	\N	\N
474	shipTargetRangeBonusGF	0	2566	2567	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
476	amarrFrigateSkillLevelPreMulShipBonusAFShip	0	2573	2574	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
479	shipDroneRangeBonusGF	0	2581	2582	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
480	shipCargoBonusAF	0	2583	2584	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipCargoBonus	0	0	0	0	\N	\N	\N	\N	\N
481	metallurgySkillBoostMineralNeedResearchBonus	0	2588	2589	Boost of mineralNeedResearchBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
482	shipTargetingRangeBonusAF	0	2590	2591	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
485	energysystemsoperationCapRechargeBonusPostPercentRechargeRateLocationShipGroupCapacitor	0	2601	2602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
486	shieldOperationRechargeratebonusPostPercentRechargeRateLocationShipGroupShield	0	2603	2604	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
490	engineeringPowerEngineeringOutputBonusPostPercentPowerOutputLocationShipGroupPowerCore	0	2616	2617	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
494	warpDriveOperationWarpCapacitorNeedBonusPostPercentWarpCapacitorNeedLocationShipGroupPropulsion	0	2636	2637	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
496	prototypingSkillBoostPrototypingBonus	0	2647	2648	Boost of prototypingBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
497	prototypingPrototypingBonusModAddPrototypingChanceChar	0	2654	2656	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
498	inventionSkillBoostInventionBonus	0	2655	2657	Boost of inventionBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
500	amarrCruiserSkillLevelPreMulShipBonusACShip	0	2668	2669	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
504	scoutDroneOperationDroneRangeBonusModAddDroneControlDistanceChar	0	2674	2675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
506	fuelConservationCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringAfterburner	0	2690	2691	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
507	longRangeTargetingMaxTargetRangeBonusPostPercentMaxTargetRangeLocationShipGroupElectronic	0	2692	2693	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
508	shipPDmgBonusMF	0	2736	2737	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
509	shipCargoBonusCF	0	2738	2739	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
510	amarrFrigateSkillLevelPreMulShipBonus2AFShip	0	2743	2744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
511	shipEnergyTCapNeedBonusAF	0	2747	2748	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
512	shipSHTDmgBonusGF	0	2751	2752	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
514	shipSETDmgBonusAF	0	2753	2754	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
516	shipTCapNeedBonusAC	0	2761	2762	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
517	gallenteCruiserSkillLevelPreMulShipBonusGCShip	0	2766	2767	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
520	caldariCruiserSkillLevelPreMulShipBonusCCShip	0	2777	2778	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
521	shipHRangeBonusCC	0	2783	2784	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
524	minmatarCruiserSkillLevelPreMulShipBonusMCShip	0	2802	2803	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
525	shipVelocityBonusMC	0	2804	2805	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
526	minmatarIndustrialSkillLevelPreMulShipBonusMIShip	0	2809	2810	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
527	shipVelocityBonusMI	0	2811	2812	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
529	shipCargoBonusAI	0	2818	2819	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
530	caldariIndustrialSkillLevelPreMulShipBonusCIShip	0	2823	2824	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
532	gallenteIndustrialSkillLevelPreMulShipBonusGIShip	0	2830	2831	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
533	shipPTrackingBonus	0	2833	2834	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
536	cpuMultiplierPostMulCpuOutputShip	4	2843	2844	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
537	droneBayBonus	4	2849	2850	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
538	amarrBattleshipSkillLevelPostMulShipBonusABShip	0	2852	2853	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
541	caldariBattleshipSkillLevelPreMulShipBonusCBShip	0	2859	2860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
542	shipCapNeedBonusAB	0	2865	2866	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
548	minmatarBattleshipSkillLevelPreMulShipBonusMBShip	0	2886	2887	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
549	shipPTDmgBonusMB	0	2889	2890	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
550	shipHTDmgBonusGB	0	2893	2894	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipHTDmgBonus	0	0	0	0	\N	\N	\N	\N	\N
551	shipPTRangeBonusMB	0	2897	2898	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
553	shipHTTrackingBonusGB	0	2904	2905	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
556	caldariBattleshipSkillLevelPreMulShipBonus2CBShip	0	2916	2917	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
558	metallurgyMineralNeedResearchBonusPostPercentMineralNeedResearchSpeedChar	0	2924	2925	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
562	shipHTDmgBonusfixedGC	0	2940	2941	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipHTDmgBonusfixedGC	0	0	0	0	\N	\N	\N	\N	\N
563	warpScrambleForEntity	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	0	0	505	\N	6	103	\N	0	1	Warp Scramble	0	0	0	0	1	\N	504	\N	\N
566	laboratoryOperationSkillLevelModAddMaxLaborotorySlotsChar	0	2951	2952	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
568	massProductionSkillLevelModAddManufactureSlotLimitChar	0	2958	2959	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
569	missileLaunchingForEntity	2	114	89			\N	1	0	506	\N	\N	\N	\N	0	1	missileLaunching	0	0	0	0	0	\N	\N	\N	\N
571	reverseEngineeringInventionBonusModAddReverseEngineeringChanceLocationChar	0	2970	2971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
575	modifyTargetSpeed2	2	3489	3491		effects.ModifyTargetSpeed	\N	0	0	513	\N	515	514	\N	0	1	modifyTargetSpeed	0	0	0	0	2	\N	512	\N	\N
581	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringGunnery	0	3009	3010	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
582	rapidFiringRofBonusPostPercentSpeedLocationShipModulesRequiringGunnery	0	3011	3012	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
583	amarrIndustrialSkillLevelPreMulShipBonusAI2Ship	0	2816	2817	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
584	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipModulesRequiringGunnery	0	3015	3016	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
586	decreaseTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	\N	6	54	\N	0	1	Decrease Target Speed	0	0	0	0	\N	\N	\N	\N	\N
587	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupEnergyWeapon	0	2968	2969	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
588	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupProjectileWeapon	0	3023	3024	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
589	surgicalStrikeDamageMultiplierBonusPostPercentDamageMultiplierLocationShipGroupHybridWeapon	0	3027	3028	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
590	energyPulseWeaponsDurationBonusPostPercentDurationLocationShipModulesRequiringEnergyPulseWeapons	0	3031	3032	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
592	targetArmorRepair	2	131	3038		effects.RemoteArmourRepair	\N	0	1	73	\N	6	54	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
594	armorExtender	4	3041	3042	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
596	ammoInfluenceRange	0	3573	3574			\N	0	0	\N	\N	\N	\N	\N	0	0	ammoInfluence	0	0	0	0	\N	\N	\N	\N	\N
597	targetedEMResonanceMultiply	2	3050	3051	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedEMResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
598	ammoSpeedMultiplier	0	3054	3055	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
599	ammoFallofMultiplier	0	3059	3060	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
600	ammoTrackingMultiplier	0	3063	3064	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
602	shipPTurretSpeedBonusMC	0	3069	3070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
604	shipPTspeedBonusMB2	0	3076	3077	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
605	minmatarBattleshipSkillLevelPreMulShipBonusMB2Ship	0	3080	3081	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
607	cloaking	1	3908	3909		effects.Cloaking	\N	0	0	\N	\N	\N	\N	\N	0	1	Cloaking	0	0	0	0	2	\N	\N	\N	\N
609	turretWeaponRangeTrackingSpeedMultiplyTargetHostile	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
611	gallenteBattleshipSkillLevelPreMulShipBonusGBShip	0	3094	3095	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
615	targetedKineticResonanceMultiply	2	3123	3124	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
616	targetedThermalResonanceMultiply	2	3127	3128	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedThermalResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
617	targetedExplosiveResonanceMultiply	2	3131	3132	Automatically generated effect	effects.EnergyDestabilization	0	0	0	73	\N	6	54	\N	0	1	TargetedExplosiveResonanceMultiply	0	0	0	0	1	\N	\N	\N	\N
621	deepCoreMiningSkillBoostDamageCloudChanceReduction	0	3148	3149	Boost of damageCloudChanceReduction by ModAdd of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
622	damageCloudChanceReduction	0	3151	3152	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
623	miningDroneOperationMiningAmountBonusPostPercentMiningDroneAmountPercentChar	0	3153	3154	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
624	standardMissilesSkillBoostMissileVelocityBonus	0	3158	3159	Boost of missileVelocityBonus  by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
627	powerIncrease	4	3174	3175	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
638	shieldDefensiveOperationsShieldCapacityBonusPostPercentShieldCapacityGangShips	0	3218	3219	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
639	reconOperationsMaxTargetRangeBonusPostPercentMaxTargetRangeGangShips	0	3222	3223	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
643	chiefFieldEngineerCapacitorBonusPostPercentCapacitorCapacityGangShips	0	3238	3239	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
648	shipSpecialityMining	0	3257	3258	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	deepCoreMiningCPUReduction	0	0	0	0	\N	\N	\N	\N	\N
649	anchorDrop	1	131	131	Anchoring this object in space.	effects.AnchorDrop	\N	0	0	556	\N	\N	\N	\N	0	1	anchoring	0	0	0	0	2	\N	\N	\N	\N
650	anchorLift	1	131	131		effects.AnchorLift	\N	0	0	556	\N	\N	\N	\N	0	1	unanchoring	0	0	0	0	2	\N	\N	\N	\N
651	cloakingSkillBoostCloakVelocityBonus	0	3262	3263	Boost of cloakVelocityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
653	shipSpecialityCloak	0	3272	3273	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipSpecialityCloak	0	0	0	0	\N	\N	\N	\N	\N
657	agilityMultiplierEffect	4	3285	3286	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	AgilityMultiplierEffect	0	0	0	0	\N	\N	\N	\N	\N
658	missileVelocityBonusGeneric	0	3290	3291	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	MissileVelocityBonusGeneric	0	0	0	0	\N	\N	\N	\N	\N
660	missileEMDmgBonus	0	3300	3301	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
661	missileExplosiveDmgBonus	0	3305	3306	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
662	missileThermalDmgBonus	0	3310	3311	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
663	heavyMissilesSkillBoostMaxflightTimeBonus	0	3315	3316	Boost of max flightTimeBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
668	missileKineticDmgBonus2	0	3338	3339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
669	shipLauncherspeedCB2	0	3341	3342	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
670	antiWarpScramblingPassive	4	2946	2947	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	antiWarpScrambling	0	0	0	0	\N	\N	\N	\N	\N
672	weaponUpgradesSkillBoostCpu	0	3350	3351	Boost of cpu by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
675	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringEnergyPulseWeapons	0	3359	3360	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
677	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringMissileLauncherOperation	0	3352	3353	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
682	gallenteBattleshipSkillLevelPreMulShipBonusGB2Ship	0	3380	3381	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
688	electronic2AttributeModifyOnline	4	3398	3399	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
698	signatureAnalysisSkillLevelPreMulScanResolutionBonusSelf	0	3425	3426	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
699	signatureAnalysisScanResolutionBonusPostPercentScanResolutionShip	0	3427	3428	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
703	interceptorsSkillLevelPreMulEliteBonusInterceptorShip	0	3451	3452	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
704	covertOpsSkillLevelPreMulEliteBonusCoverOpsShip	0	3455	3456	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
705	bombersSkillLevelPreMulEliteBonusBombersShip	0	3459	3460	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
706	covertOpsWarpResistance	0	3463	3464	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
707	bomberRocketRangeBonus	0	3469	3470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
708	bomberLightsRangeBonus	0	3473	3474	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
709	interceptorSignatoreRadiusBonus	0	3475	3476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
710	speedBoostFactorCalculator	0	3500	3501	Aid to auto-calc this.	\N	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
712	speedBoostFactorCalculator2	0	3515	3516	Aid to auto-calc	\N	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
713	stealthActive	1	3520	3521	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
716	sensorBoostTargeted	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	0	1	73	\N	6	\N	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
720	sensorBoosterActive	1	3527	3528		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	1	sensorBoosterActivated	1	0	0	0	\N	\N	\N	\N	\N
721	miningCapBonus	0	3536	3537	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Reduces Mining laser activation power	0	0	0	0	\N	\N	\N	\N	\N
726	shipBonusCargo2GI	0	3547	3548	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
727	shipBonusCargoCI	0	3549	3550	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
728	shipBonusCargoMI	0	3551	3552	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
729	shipBonusVelocityGI	0	3553	3554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
730	shipBonusVelocityCI	0	3569	3572	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
732	shipVelocityBonusAI	0	3557	3558	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShipVelocityBonusAI	0	0	0	0	\N	\N	\N	\N	\N
734	amarrBattleshipSkillLevelPreMulShipBonusAB2Ship	0	3565	3566	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
736	shipBonusCapCapAB	0	3567	3568	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
744	surveyScanspeedBonusPostPercentDurationLocationShipModulesRequiringElectronics	0	3587	3588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
751	gallenteFrigateSkillLevelPreMulShipBonusGF2Ship	0	3610	3611	Automatically generated effect	gallenteFrigateSkillLevelPreMulShipBonusGF2Ship	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
754	shipHybridDamageBonusCF	0	3620	3621	Automatically generated effect	shipHybridDamageBonusCF	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
757	shipETDamageAF	0	3628	3629	Automatically generated effect	shipETDamageAF	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
760	shipMissileSpeedBonusCF	0	3645	3646	Automatically generated effect	shipMissileSpeedBonusCF	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
761	caldariFrigateSkillLevelPreMulShipBonusCF2Ship	0	3649	3650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
762	minmatarFrigateSkillLevelPreMulShipBonusMF2Ship	0	3653	3654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
763	missileDMGBonus	4	3657	3658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
765	leadershipEffect	0	3663	3664	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
768	hypereuclideanNavigationCloakVelocityBonusModAddSpeedFactorLocationShipModulesRequiringCloaking	0	3670	3671	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
775	capBoostAmplifier	4	3694	3695	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
782	missileGuidanceAgilityBonusPostPercentAgilityOwnerCharModulesRequiringMissileLauncherOperation	0	3726	3727	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
784	missileBombardmentMaxFlightTimeBonusPostPercentExplosionDelayOwnerCharModulesRequiringMissileLauncherOperation	0	3728	3729	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
793	escortHullUpgradeCpu Bonus	0	3758	3759	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
796	escortShieldUpgradeCpu Bonus	0	3775	3776	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
797	caldariBattleshipSkillLevelPreMulShipBonusCB3Ship	0	3767	3768	Automatically generated effect	caldariBattleshipSkillLevelPreMulShipBonusCB3Ship	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
802	shipDronesMaxGB	0	3785	3786	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
804	ammoInfluenceCapNeed	0	3797	3798	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
820	speedBoostPassive	4	3517	3518		effects.SpeedBoost	\N	0	0	\N	\N	\N	\N	\N	0	1	speedBoost	0	0	0	0	\N	\N	\N	\N	\N
834	ammoInfluenceCapRecharge	0	443	444	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
835	freightSkillBoostCargoCapacityBonus	0	3904	3905	Boost of cargoCapacityBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
836	skillFreightBonus	0	3906	3907	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
837	sensorBoostTargetedHostile	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
838	ammoInfluenceShipVelocity	0	3908	3909	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
848	cloakingTargetingDelayBonusPostPercentCloakingTargetingDelayBonusForShipModulesRequiringCloaking	0	3924	3925	Applies the cloaking skill's reduction bonus to cloakingTargetingDelay time.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
850	cloakingSkillBoostCloakingTargetingDelayBonus	0	3928	3929	Applies cloaking skill's level to cloakingTargetingDelayBonus.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
854	cloakingScanResolutionMultiplier	0	3935	3408	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
856	warpSkillSpeed	0	3949	3950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	WarpSkillSpeed	0	0	0	0	\N	\N	\N	\N	\N
857	bountyHuntingSkillBoostBountySkillBonus	0	3957	3958	Boost of bountySkillBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
858	bountyhunterskill	0	3961	3962	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
859	advancedBountyHuntingSkillBoostBountySkillMultiplyer	0	3967	3968	Boost of bountySkillMultiplyer by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
860	advBountyhunterSkill	0	3971	3972	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
867	missileFlightTimeAndDamage	1	3996	3997	Adjusts missile flight time and damage.		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
874	shipProjectileOptimalBonuseMF2	0	4026	4027	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
875	shipLaserOptimalBonuseAF	0	4030	4031	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
876	shieldBoostingForEntities	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
878	armorRepairForEntities	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
881	implantEWcpuneed	0	4048	4049	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
882	shipHybridRangeBonusCF2	0	4052	4053	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
885	suicideBomb	1	288	233	Triggering of an EMP wave being broadcast into space.	effects.EMPWave	\N	1	0	73	\N	6	99	\N	0	1	empWave	0	0	0	0	2	\N	\N	\N	\N
887	shipETspeedBonusAB2	0	4066	4067	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
889	missileLauncherSpeedMultiplier	4	4069	4070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
891	shipCruiseMissileVelocityBonusCB3	0	4081	4082	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
892	shipTorpedosVelocityBonusCB3	0	4087	4088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
896	covertOpsCpuBonus1	0	4111	4112	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
897	covertOpsCpuMultplier1	0	4115	4116	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
898	shipMissileKineticDamageCF	0	4119	4120	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
899	shipMissileKineticDamageCC	0	4121	4122	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
900	shipDroneScoutThermalDamageGF2	0	4125	4126	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
901	onlineForStructures	1	131	131	this is the online effect for structures	effects.StructureOnline	\N	0	0	\N	\N	\N	\N	\N	0	1	online	0	0	0	0	\N	\N	\N	\N	\N
902	decloakWave	1	4129	131	Triggering of an EMP wave being broadcast into space.	effects.DecloakWave	\N	0	0	73	\N	6	651	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
903	ammoInfluenceSignatureRadius	0	4133	4134	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
904	ammoInfluenceShieldCapacity	0	4136	4137	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
907	shipLaserRofAC2	0	4152	4153	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
909	shipArmorHpAC2	0	4158	4159	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
912	shipMissileLauncherRofCC2	0	4164	4165	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
914	shipMiningYieldCC2	0	4170	4171	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
918	shipDronesMaxGC2	0	4184	4185	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
919	shipHybridTrackingGC2	0	4186	4187	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
923	shipMiningYieldMC2	0	4196	4197	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
926	amarrCruiserSkillLevelPreMulShipBonusAC2Ship	0	4214	4215	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
927	caldariCruiserSkillLevelPreMulShipBonusCC2Ship	0	4218	4219	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
928	gallenteCruiserSkillLevelPreMulShipBonusGC2Ship	0	4222	4223	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
929	minmatarCruiserSkillLevelPreMulShipBonusMC2Ship	0	4226	4227	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
930	shipCargoCapacityGC2	0	4228	4229	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
934	shipMaxVelocityMC2	0	4238	4239	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
939	shipShieldBoostCC2	0	4253	4254	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
952	boosterTimeBonus	0	4288	4289	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
953	biologyTimeBonus	0	4292	4293	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
958	shipArmorEmResistanceAC2	0	4256	4257	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
959	shipArmorExplosiveResistanceAC2	0	4259	4260	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
960	shipArmorKineticResistanceAC2	0	4262	4263	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
961	shipArmorThermalResistanceAC2	0	4265	4266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
967	shipMwdLessCapNerfGC2	0	4320	4321	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
968	shipProjectileDmgMC2	0	4322	4323	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
969	smartbombEMBonus	4	4327	4328	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
970	smartbombKineticBonus	4	4331	4332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
971	smartbombThermalBonus	4	4335	4336	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
972	smartbombEXBonus	4	4339	4340	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
973	smartbombRangeBonus	4	4345	4346	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
980	cloakingWarpSafe	1	3908	3909		effects.Cloaking	\N	0	0	\N	\N	\N	\N	\N	0	1	Cloaking	1	0	0	0	2	\N	\N	\N	\N
983	droneHeavyControlUnitMultiplier	1	4372	4373			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
987	gunshipSkillMultiplier1	0	4387	4388	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
988	gunshipSkillMultiplier2	0	4391	4392	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
989	eliteBonusGunshipHybridOptimal1	0	4393	4394	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
990	eliteBonusGunshipProjectileOptimal1	0	4395	4396	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
991	eliteBonusGunshipLaserOptimal1	0	4397	4398	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
996	eliteBonusGunshipHybridTracking2	0	4415	4416	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
998	eliteBonusGunshipProjectileFalloff2	0	4419	4420	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
999	eliteBonusGunshipShieldBoost2	0	4421	4422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1001	eliteBonusGunshipCapRecharge2	0	4426	4427	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1002	eliteBonusGunshipDroneCapacity2	0	4428	4429	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1003	selfT2SmallLaserPulseDamageBonus	0	4434	4435	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1004	selfT2SmallLaserBeamDamageBonus	0	4440	4441	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1005	selfT2SmallHybridBlasterDamageBonus	0	4444	4445	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1006	selfT2SmallHybridRailDamageBonus	0	4450	4451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1007	selfT2SmallProjectileACDamageBonus	0	4456	4457	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1008	selfT2SmallProjectileArtyDamageBonus	0	4462	4463	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1009	selfT2MediumLaserPulseDamageBonus	0	4468	4469	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1010	selfT2MediumLaserBeamDamageBonus	0	4474	4475	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1011	selfT2MediumHybridBlasterDamageBonus	0	4480	4481	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1012	selfT2MediumHybridRailDamageBonus	0	4486	4487	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1013	selfT2MediumProjectileACDamageBonus	0	4492	4493	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1014	selfT2MediumProjectileArtyDamageBonus	0	4498	4499	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1015	selfT2LargeLaserPulseDamageBonus	0	4504	4505	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1016	selfT2LargeLaserBeamDamageBonus	0	4510	4511	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1017	selfT2LargeHybridBlasterDamageBonus	0	4516	4517	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1018	selfT2LargeHybridRailDamageBonus	0	4522	4523	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1019	selfT2LargeProjectileACDamageBonus	0	4528	4529	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1020	selfT2LargeProjectileArtyDamageBonus	0	4534	4535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1021	eliteBonusGunshipHybridDmg2	0	4536	4537	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1022	anchorDropForStructures	1	131	131	Anchoring this object in space.	effects.AnchorDrop	\N	0	0	\N	\N	\N	\N	\N	0	1	anchoring	0	0	0	0	2	\N	\N	\N	\N
1023	anchorLiftForStructures	1	131	131		effects.AnchorLift	\N	0	0	\N	\N	\N	\N	\N	0	1	unanchoring	0	0	0	0	2	\N	\N	\N	\N
1024	shipMissileHeavyVelocityBonusCC2	0	4542	4543	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1025	shipMissileLightVelocityBonusCC2	0	4546	4547	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1030	remoteArmorSystemsCapNeedBonusPostPercentCapacitorNeedLocationShipModulesRequiringRemoteArmorSystems	0	4566	4567	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1033	eliteBonusLogisticRemoteArmorRepairCapNeed1	0	4576	4577	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1034	eliteBonusLogisticRemoteArmorRepairCapNeed2	0	4578	4579	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1035	eliteBonusLogisticShieldTransferCapNeed2	0	4584	4585	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1036	eliteBonusLogisticShieldTransferCapNeed1	0	4586	4587	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1042	eliteBonusLogisticTrackingLinkBonus1	0	4604	4605			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1045	eliteBonusLogisticTrackingLinkBonus2	0	4610	4611			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1046	shipRemoteArmorRange1	0	4614	4615	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1047	shipRemoteArmorRange2	0	4616	4617	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1048	shipShieldTransferRange1	0	4620	4621	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1049	shipShieldTransferRange2	0	4622	4623	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1052	logisticSkillMultiplier1	0	4633	4634	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1053	logisticSkillMultiplier2	0	4637	4638	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1054	shipTrackingLinkRange1	0	4640	4641	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1055	shipTrackingLinkRange2	0	4642	4643	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1056	eliteBonusHeavyGunshipHybridOptimal1	0	4658	4659	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1057	eliteBonusHeavyGunshipProjectileOptimal1	0	4660	4661	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1058	eliteBonusHeavyGunshipLaserOptimal1	0	4664	4665	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1060	eliteBonusHeavyGunshipProjectileFallOff1	0	4670	4671	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1061	eliteBonusHeavyGunshipHybridDmg2	0	4672	4673	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1062	eliteBonusHeavyGunshipLaserDmg2	0	4674	4675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1063	eliteBonusHeavyGunshipProjectileTracking2	0	4676	4677	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1066	eliteBonusHeavyGunshipDroneCapacity2	0	4686	4687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1077	warshipSkillMultiplier2	0	4723	4724	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1079	warshipSkillMultiplier1	0	4730	4731	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1080	eliteBonusHeavyGunshipHybridFallOff1	0	4732	4733	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1081	eliteBonusHeavyGunshipHeavyMissileFlightTime1	0	4734	4735	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1082	eliteBonusHeavyGunshipLightMissileFlightTime1	0	4736	4737	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1084	eliteBonusHeavyGunshipDroneControlRange1	0	4740	4741	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1086	projectileFiredForEntities	2	115	131		effects.ProjectileFiredForEntities	\N	1	0	51	160	6	54	158	0	1	projectileFired	0	0	0	0	1	\N	\N	\N	\N
1087	eliteBonusHeavyGunshipProjectileDmg2	0	4750	4751	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1095	destroyerPenalityTurretROF	0	4789	4790	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1099	shipProjectileTrackingMF2	0	4801	4802	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1108	controlTowerAmarrLaserDMGBonus	0	4831	4832	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1109	battlecruiserSkillLevelPreMulShipBonusBC1Ship	0	4856	4857	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1110	shipProjectileRofMBC2	0	4858	4859	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1111	battlecruiserSkillLevelPreMulShipBonusBC2Ship	0	4862	4863	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1117	shipArmorThermResistanceABC1	0	4882	4883	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1118	shipArmorEMResistanceABC1	0	4884	4885	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1119	shipArmorExplosiveResistanceABC1	0	4886	4887	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1120	shipArmorKineticResistanceABC1	0	4888	4889	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1121	shipShieldEmResistanceCBC2	0	4890	4891	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1122	shipShieldExplosiveResistanceCBC2	0	4892	4893	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1123	shipShieldKineticResistanceCBC2	0	4894	4895	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1124	shipShieldThermalResistanceCBC2	0	4896	4897	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1125	shipLaserCapABC2	0	4900	4901	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1126	shipHybridDmgGBC1	0	4902	4903	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1129	structureUnanchorForced	2	131	131			\N	1	0	676	\N	\N	76	\N	0	1	Force Unanchor	0	0	0	0	2	\N	\N	\N	\N
1130	controlTowerAmarrLaserOptimalBonus	0	4922	4923	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1131	controlTowerSiloCapacityBonus	0	4928	4929	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1133	controlTowerMinmatarProjectileOptimalBonus	0	4938	4939	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1134	controlTowerMinmatarProjectileFallOffBonus	0	4942	4943	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1137	controlTowerMinmatarProjectileRofBonus	0	4958	4959	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1138	controlTowerMoonHarvesterCPUBonus	0	4966	4967	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1139	destroyerSkillLevelPreMulShipBonusDF2Ship	0	4973	4974	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1140	destroyerSkillLevelPreMulShipBonusDF1Ship	0	4977	4978	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1141	shipHybridTrackingGD2	0	4979	4980	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1143	shipLaserCapNeedAD1	0	4985	4986	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1144	shipLaserTrackingAD2	0	4987	4988	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1145	shipHybridRangeCD1	0	4989	4990	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1147	shipProjectileTrackingMD2	0	4995	4996	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1150	systemScan	1	131	131	Scan the solar system.		\N	0	0	73	\N	6	\N	\N	0	1	Analyzing Scans	0	0	0	0	\N	\N	\N	\N	\N
1152	controlTowerGallenteHybridDamageBonus	0	5017	5018	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1156	controlTowerTrackingArrayHybridOptimalBonus	4	5026	5027	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1157	controlTowerTrackingArrayLaserOptimalBonus	4	5028	5029	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1158	controlTowerTrackingArrayProjectileOptimalBonus	4	5030	5031	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1159	controlTowerTrackingArrayProjectileTrackingBonus	4	5034	5035	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1160	controlTowerTrackingArrayHybridTrackingBonus	4	5038	5039	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1161	controlTowerTrackingArrayLaserTrackingBonus	4	5040	5041	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1165	shipIceHarvesterCPUNeed	0	5063	5064	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1166	shipMinerCPUNeed	0	5067	5068	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1171	massFactor	0	5089	5090	Needed for all ships for speed boost of afterburners and microwarpdrives.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1173	ammoInfluenceEntityFlyRange	0	5102	5103	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1176	accerationControlSkillAb&MwdSpeedBoost	0	5113	5114			\N	0	0	\N	\N	\N	\N	\N	0	0	accerationControlSkillAb	0	0	0	0	\N	\N	\N	\N	\N
1179	eliteBonusGunshipLaserDamage2	0	5121	5122	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1181	eliteBonusLogisticEnergyTransferCapNeed1	0	5133	5134	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1182	shipEnergyTransferRange1	0	5137	5138	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1183	eliteBonusLogisticEnergyTransferCapNeed2	0	5139	5140	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1184	shipEnergyTransferRange2	0	5141	5142	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1185	structureStealthEmitterArraySigDecrease	0	3277	3278	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1188	miningBargeSkillLevelPostMulShipBonusORE2Ship	0	5159	5160	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1190	iceHarvestCycleTimeModulesRequiringIceHarvesting	0	5165	5166	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1191	iceHarvestCycleTimeBonus	0	5169	5170	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1192	controlTowerCaldariEwTargetSwitchDelayBonus	0	5048	5049	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1193	shipHybridOptimalCBC1	0	5171	5172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1194	shipShieldBoostMBC1	0	5173	5174	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1195	shipArmorRepairingGBC2	0	5175	5176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1197	shipMiningBonusORE2	0	5181	5182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1198	shipHybridFallOffGD1	0	5185	5186	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1199	targetAttackForStructures	2	115	89	Combat	effects.ProjectileFiredForEntities	\N	1	0	51	160	6	54	158	0	1	targetAttack	0	0	0	0	2	\N	\N	\N	\N
1200	miningInfoMultiplier	0	5190	5191	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	MiningInfoMultiplier	0	0	0	0	\N	\N	\N	\N	\N
1202	shipMissileEMDamage2AF	0	5194	5195	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1203	controlTowerCaldariMissileVelocityBonus	0	5200	5201	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1204	shipPTurretSpeedBonusGB	0	5204	5205	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1210	controlTowerCaldariMissileRofBonus	0	5228	5229	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1212	crystalMiningamountInfo2	0	5236	5237	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1213	shipProjectileTrackingGC2	0	5239	5240	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1215	shipEnergyDrainAmountAF1	0	5247	5248	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1217	shipStasisRangeMF1	0	5255	5256	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1218	shipBonusPirateSmallHybridDmg	0	5257	5258	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1219	shipEnergyVampireTransferAmountBonusAB	0	5259	5260	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1220	shipEnergyVampireTransferAmountBonusAc	0	5261	5262	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	shipEnergyVampireTransferAmountBonusAB	0	0	0	0	\N	\N	\N	\N	\N
1221	shipStasisWebRangeBonusMB	0	5263	5264	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1222	shipStasisWebRangeBonusMC2	0	5265	5266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1224	shipMWDCapBonusMC	0	5267	5268	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1226	shipMWDCapBonusMB	0	5269	5270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1228	shipProjectileTrackingGF	0	5275	5276	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1229	shipMWDCapBonusMF	0	5277	5278	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1230	shipMissileVelocityPirateFactionFrigate	0	5279	5280	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1231	shipBonusLaserCapPirateCruiser	0	5281	5282	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1232	shipProjectileRofPirateCruiser	0	5283	5284	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1233	shipHybridDmgPirateCruiser	0	5285	5286	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1234	shipMissileVelocityPirateFactionLight	0	5287	5288	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1235	shipMissileVelocityPirateFactionHeavy	0	5289	5290	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1236	shipMissileVelocityPirateFactionCruise	0	5291	5292	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1237	shipMissileVelocityPirateFactionTorp	0	5293	5294	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1238	shipLaserCapPirateBattleship	0	5297	5298	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1239	shipProjectileRofPirateBattleship	0	5299	5300	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1240	shipHybridDmgPirateBattleship	0	5301	5302	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1243	shipMissileExplosiveDamageMF1	0	5310	5311	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1244	smugglingModifier	0	5315	5316	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1252	shipProjectileDamageDF1	0	5329	5330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1253	speedBoostMassAddition	1	5331	5332		effects.SpeedBoost	\N	0	0	73	\N	6	\N	\N	0	1	Speed Boost	0	0	0	0	\N	\N	\N	\N	\N
1254	speedBoostMassSigRad	1	5333	5334			\N	0	0	73	\N	6	\N	\N	0	1	Speed Boost	0	0	0	0	\N	\N	\N	\N	\N
1255	setBonusBloodraider	0	5342	5343	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1256	setBonusBloodraiderNosferatu	0	5346	5347	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1257	blackMarketTradingSkillBoostContrabandDetectionChanceBonus	0	5352	5353	Boost of contrabandDetectionChanceBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1258	skillBoostContrabandDetectionChanceBonusEffect	0	5356	5357	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	SkillBoostContrabandDetectionChanceBonusEffect	0	0	0	0	\N	\N	\N	\N	\N
1259	testfuelConsumption	1	5360	5361	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	TESTfuelConsumption	0	0	0	0	\N	\N	\N	\N	\N
1260	testmassThrust	1	5364	5365	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	TESTmassThrust	0	0	0	0	\N	\N	\N	\N	\N
1261	setBonusSerpentis	0	5370	5371	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1262	setBonusSerpentis2	0	5376	5377	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1264	interceptor2HybridTracking	0	5381	5382	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1265	interceptor2MissileKineticDamage	0	5383	5384	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1266	interceptor2MissileVelocity	0	5385	5386	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1268	interceptor2LaserTracking	0	5389	5390	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1269	interceptor2ProjectileFallOff	0	5391	5392	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1270	interceptor2ProjectileTracking	0	5393	5394	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1271	newEwTestscanStrengthBonusTargetHostile	2	956	903	Modifies the scanning strengths of a targeted object.	effects.ScanStrengthBonusTarget	\N	1	0	73	\N	6	54	158	0	0		0	0	0	0	1	\N	\N	\N	\N
1272	newEwTestswarpScramble	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	158	0	0		0	0	0	0	1	\N	\N	\N	\N
1273	newEwTestssensorBoostTargetedHostile	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	0	0	0	1	\N	\N	\N	\N
1274	newEwTeststurretWeaponRangeTrackingSpeedMultiplyTargetHostile	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.Target_paint	\N	1	0	73	\N	6	54	158	0	0		0	0	0	0	1	\N	\N	\N	\N
1275	newEwTestsdecreaseTargetSpeed	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	160	6	54	158	0	1	newEwTestsDecrease Target Speed	0	0	0	0	1	\N	\N	\N	\N
1278	interceptor2MissileEmDamage	0	5396	5397	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1279	interceptors2SkillLevelPreMulEliteBonusInterceptorShip	0	5400	5401	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1280	structuralAnalyzisSkillBoostRepairBonus	0	5406	5407	Boost of repairBonus by PostPercent of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1281	structuralAnalysisEffect	0	5408	5409	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1282	eliteIndustrial1SkillLevelPreMulEliteBonusEliteIndustrialShip	0	5415	5416	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1283	eliteIndustrial2SkillLevelPreMulEliteBonusEliteIndustrialShip	0	5419	5420	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1290	amarrIndustrialSkillLevelPreMulShipBonusAI22Ship	0	5442	5443	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1291	caldariIndustrialSkillLevelPreMulShipBonusCI2Ship	0	5446	5447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1292	gallenteIndustrialSkillLevelPreMulShipBonusGI2Ship	0	5450	5451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1293	minmatarIndustrialSkillLevelPreMulShipBonusMI2Ship	0	5454	5455	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1304	eliteIndustrialShieldBoostAmountElite1	0	5474	5475	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	eliteIndustrialShieldBoostAmountMI1	0	0	0	0	\N	\N	\N	\N	\N
1305	eliteIndustrialShieldBoostCapNeedElite2	0	5476	5477	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1306	eliteIndustrialArmorRepairAmountElite1	0	5478	5479	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1307	eliteIndustrialArmorRepairCapNeedElite1	0	5421	5422	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1308	eliteIndustrialArmorRepairDurationElite2	0	5425	5426	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1309	shipMissileThermDamageGallenteInterceptor2	0	5488	5489	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1318	ewSkillScanStrengthBonus	0	5526	5527			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1320	propulsionSkillFallOffBonus	0	5534	5535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1321	ewSkillScanStrengthBonusSkillLevel	0	5537	5538	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	ewSkillEwStrengthBonusSkillLevel	0	0	0	0	\N	\N	\N	\N	\N
1322	propulsionSkillMaxRangeBonus	0	5539	5540	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1329	propulsionSkillPropulsionStrengthBonus	0	5561	5562			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1330	propulsionSkillPropulsionStrengthBonusSkillLevel	0	5565	5566	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1335	amarrShipEwWeaponDisruptionAF1	0	5581	5582			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1339	gallenteShipEwSensorDampenGF2	0	5595	5596			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1343	gallenteShipEwSensorDampenGC2	0	5603	5604			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1354	ewTestEffectRsd	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
1355	ewTestEffectWs	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	73	\N	6	54	158	0	0		0	1	0	1	2	\N	\N	\N	\N
1358	ewTestEffectJam	2	5643	5644	Automatically generated effect		0	1	0	73	\N	6	54	158	0	0		0	1	1	0	1	\N	\N	\N	\N
1360	ewSkillRsdCapNeedBonusSkillLevel	0	5649	5650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1361	ewSkillTdCapNeedBonusSkillLevel	0	5653	5654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1367	propulsionSkillStasisStrengthBonus	0	5678	5679	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1369	ewSkillTrackingDisruptionBonus	0	5682	5683			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1370	ewSkillTpCapNeedBonusSkillLevel	0	5686	5687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1372	ewSkillEwCapNeedSkillLevel	0	5695	5696	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1373	ewSkillTargetPaintingStrengthBonusSkillLevel	0	5699	5700	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1376	ewSkillSignatureDampenBonus	0	5705	5706			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1387	leadershipCpuBonus	0	5743	5744	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	logisticsCPUReduction	0	0	0	0	\N	\N	\N	\N	\N
1390	stealthOnline	4	3520	3521	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1394	covertOpsStealthBomberCruiseLauncerPowerNeedBonus	0	5777	5778	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1395	shieldBoostAmplifierPassive	0	3171	3172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1397	setBonusGuristas	0	5786	5787	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1398	eliteBonusCoverOpsCruiseEmDmg1	0	5791	5792	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1399	eliteBonusCoverOpsCruiseThermalDmg1	0	5795	5796	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1400	eliteBonusCoverOpsCruiseExplosiveDmg1	0	5799	5800	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1401	eliteBonusCoverOpsCruiseLauncherPowerNeed1	0	5802	5803	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1402	eliteBonusCoverOpsCloakingVelocity2	0	5806	5807	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1403	shipMissileCruiseKineticDmgCF2	0	5810	5811	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1405	covertOpsSkillLevelPreMulEliteBonusCoverOpsShip2	0	5814	5815	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1407	eliteBonusCoverOpsScanProbeDuration2	0	5827	5828	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1409	systemScanDurationSkillAstrometrics	0	5833	5834	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1410	propulsionSkillCapNeedBonusSkillLevel	0	5657	5658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1411	gangBonusSignature	1	5835	5836	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	1	gangSignatureBoost	0	0	0	0	0	\N	\N	\N	\N
1412	shipBonusHybridOptimalCB	0	5837	5838	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1434	caldariShipEwStrengthCB	0	5888	5889			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1440	missileEMdamageOther	0	5903	5904	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1441	caldariShipEwOptimalRangeCB3	0	5907	5908	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1442	caldariShipEwOptimalRangeCC2	0	5909	5910	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1443	caldariShipEwCapacitorNeedCC	0	5911	5912	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1445	ewSkillRsdMaxRangeBonus	0	5915	5916	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1446	ewSkillTpMaxRangeBonus	0	5919	5920	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1448	ewSkillTdMaxRangeBonus	0	5929	5930	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1449	ewSkillRsdFallOffBonus	0	5933	5934	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1450	ewSkillTpFallOffBonus	0	5937	5938	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1451	ewSkillTdFallOffBonus	0	5941	5942	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1452	ewSkillEwMaxRangeBonus	0	5943	5944	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1453	ewSkillEwFallOffBonus	0	5947	5948	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1467	missileSkillAoeVelocityBonusSkillLevel	0	5982	5983	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1472	missileSkillAoeCloudSizeBonus	0	6000	6001			0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1473	missileSkillAoeCloudSizeBonusSkillLevel	0	6004	6005	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1483	contrabandMasking	1	6032	6033			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	0	\N	\N	\N	\N
1486	commandMultiplier	0	6050	6051	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1495	flagshipmultiRelayEffect	4	6083	6084	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	multiRelayEffect	0	0	0	0	\N	\N	\N	\N	\N
1496	relayActiveMultiplier	1	6087	6088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1498	masterAndCommander2	0	6076	6077	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1499	shieldOperationSkillBoostCapacitorNeedBonusSkillLevel	0	6097	6098	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	shieldOperationSkillBoostCapacitorNeedBonus	0	0	0	0	\N	\N	\N	\N	\N
1500	shieldOperationSkillBoostCapacitorNeedBonus	0	6099	6100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1501	covertOpsStealthBomberCruiseMissileExplosionRadiusBonus	0	6102	6103	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1502	armorTankingGang	0	6106	6107	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1510	gangArmorHardening	1	6128	6129		effects.ElectronicAttributeModifyActivate	\N	1	1	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1541	squadronmultiplyer	0	6211	6212	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1542	squadronCommand	0	6219	6220	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1546	gangPropulsionJammingBoost	1	6235	6236	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1548	gangShieldHardening	1	6239	6240		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1549	ewTargetPaint	2	3836	3837	Automatically generated effect	effects.TargetPaint	0	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	\N	\N	\N	\N
1550	ewSkillTargetPaintingStrengthBonus	0	5951	5952	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1551	minmatarShipEwTargetPainterMF2	0	5953	5954	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1577	angelsetbonus	0	6304	6305	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1579	setBonusSansha	0	6313	6314	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1581	jumpDriveSkillsRangeBonus	0	6321	6322	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1582	jumpDriveSkillsRangeBonusSkillLevel	0	6325	6326	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1585	capitalTurretSkillLaserDamage	0	6338	6339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1586	capitalTurretSkillProjectileDamage	0	6344	6345	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1587	capitalTurretSkillHybridDamage	0	6350	6351	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1588	capitalLauncherSkillCitadelKineticDamage	0	6356	6357	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	capitalLauncherSkillCitadelDamage	0	0	0	0	\N	\N	\N	\N	\N
1590	missileSkillAoeVelocityBonus	0	6278	6279	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1592	capitalLauncherSkillCitadelEmDamage	0	6365	6366	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1593	capitalLauncherSkillCitadelExplosiveDamage	0	6369	6370	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1594	capitalLauncherSkillCitadelThermalDamage	0	6373	6374	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1595	missileSkillWarheadUpgradesEmDamageBonus	0	6375	6376	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1596	missileSkillWarheadUpgradesExplosiveDamageBonus	0	6377	6378	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1597	missileSkillWarheadUpgradesKineticDamageBonus	0	6379	6380	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1614	skillAdvancedSpaceshipAgilityBonus	0	6409	6410	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1615	shipAdvancedSpaceshipCommandAgilityBonus	0	6412	6413	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1616	skillCapitalShipsAdvancedAgility	0	6418	6419	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1617	shipCapitalAgilityBonus	0	6420	6421	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1618	dreadnoughtBoostShipBonusA1	0	6434	6435	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dreadnoughtBoostShipBonusA	0	0	0	0	\N	\N	\N	\N	\N
1619	dreadnoughtBoostShipBonusA2	0	6438	6439	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dreadnoughtBoostShipBonus	0	0	0	0	\N	\N	\N	\N	\N
1620	dreadnoughtBoostShipBonusC1	0	6442	6443	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1621	dreadnoughtBoostShipBonusC2	0	6446	6447	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1622	dreadnoughtBoostShipBonusG1	0	6450	6451	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1623	dreadnoughtBoostShipBonusG2	0	6454	6455	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1624	dreadnoughtBoostShipBonusM1	0	6458	6459	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1625	dreadnoughtBoostShipBonusM2	0	6462	6463	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1626	dreadnoughtShipBonusLaserCapNeedA1	0	6466	6467	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1627	dreadnoughtShipBonusLaserRofA2	0	6469	6470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1628	dreadnoughtShipBonusLauncherRofC1	0	6471	6472	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1630	dreadnoughtShipBonusHybridDmgG1	0	6475	6476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1632	dreadnoughtShipBonusProjectileRofM1	0	6481	6482	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1633	dreadnoughtShipBonusLauncherRofM2	0	6483	6484	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1634	capitalShieldOperationSkillCapacitorNeedBonus	0	6489	6490	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1635	capitalRepairSystemsSkillDurationBonus	0	6495	6496	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1638	skillAdvancedWeaponUpgradesPowerNeedBonus	0	6505	6506			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1643	armoredWarfareMindlink	0	6517	6518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ArmoredWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1644	shirmishWarfareMindlink	0	6523	6524	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	ShirmishWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1645	siegeWarfareMindlink	0	6529	6530	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	SiegeWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1646	covertWarfareMindlink	0	6535	6536	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	CovertWarfareMindlink	0	0	0	0	\N	\N	\N	\N	\N
1648	gangECCMfixed	1	6539	6540		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	1	Gang ECCM	0	0	0	0	0	\N	\N	\N	\N
1649	skillCynosuralTheoryConsumptionQuantityBonus	0	6547	6548	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	skillConsumptionQuantityBonus	0	0	0	0	\N	\N	\N	\N	\N
1650	skillSiegeModuleConsumptionQuantityBonus	0	6553	6554	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1651	skillCynosural&SiegeConsumQuantityBonusSkillLevel	0	6557	6558	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1652	skillJumpDriveConsumptionAmountBonus	0	6561	6562	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	skilljumpDriveConsumptionAmountBonus	0	0	0	0	\N	\N	\N	\N	\N
1657	missileSkillWarheadUpgradesThermalDamageBonus	0	6388	6389	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1659	freighterA1SkillLevel	0	6590	6591	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusA1	0	0	0	0	\N	\N	\N	\N	\N
1660	freighterA2SkillLevel	0	6572	6573	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusA2	0	0	0	0	\N	\N	\N	\N	\N
1661	freighterC1SkillLevel	0	6594	6595	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusC1	0	0	0	0	\N	\N	\N	\N	\N
1663	freighterC2SkillLevel	0	6601	6602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusG1	0	0	0	0	\N	\N	\N	\N	\N
1664	freighterG1SkillLevel	0	6605	6606	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusG1	0	0	0	0	\N	\N	\N	\N	\N
1665	freighterG2SkillLevel	0	6609	6610	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusG2	0	0	0	0	\N	\N	\N	\N	\N
1666	freighterM1SkillLevel	0	6613	6614	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterMaxVelocityBonusM1	0	0	0	0	\N	\N	\N	\N	\N
1667	freighterM2SkillLevel	0	6617	6618	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	freighterCargoBonusM2	0	0	0	0	\N	\N	\N	\N	\N
1668	freighterCargoBonusA2	0	6576	6577	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1669	freighterCargoBonusC2	0	6619	6620	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1670	freighterCargoBonusG2	0	6621	6622	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1671	freighterCargoBonusM2	0	6623	6624	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1672	freighterMaxVelocityBonusA1	0	6574	6575	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1673	freighterMaxVelocityBonusC1	0	6625	6626	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1674	freighterMaxVelocityBonusG1	0	6627	6628	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1675	freighterMaxVelocityBonusM1	0	6629	6630	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1676	testfuelBoostShipSpeedActivation	1	6633	6634	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	TESTfuelBoostShipSpeedActivation	0	0	0	0	\N	\N	\N	\N	\N
1720	shieldBoostAmplifier	4	6717	6718			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1721	dreadnoughtShipBonusMissileKineticDmgC2	0	6720	6721	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1722	jumpDriveSkillsCapacitorNeedBonus	0	6726	6727	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1723	jumpDriveSkillsCapacitorNeedBonusSkillLevel	0	6730	6731	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1729	cynosuralGenerationTmp	1	6742	6743			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
1730	droneDmgBonus	0	6744	6745	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1731	testDroneShieldEffect	0	6750	6751	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	TestDroneShieldEffect	0	0	0	0	\N	\N	\N	\N	\N
1738	openSpawnContainer	2	131	131		effects.TargetScan	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1740	dataMiningSkillMultiplierFixed	0	6782	6783	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1745	siegeModeEffectOld	1	6790	6791		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0	siegeModeEffect	0	0	0	0	0	None	\N	\N	\N
1746	gangArmorRepairSpeedAmplifier	1	6794	6795	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1747	gangArmorRepairCapReducer	1	6798	6799	Automatically generated effect	effects.ElectronicAttributeModifyActivate	0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1752	entityEwTestEffectJam	2	5643	5644	Automatically generated effect		0	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	1	\N	\N	\N	\N
1755	gangAbMwdFactorBoost	1	6820	6821			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1756	skirmishWarfareVelocityBonus	0	6823	6824	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1763	missileSkillRapidLauncherRoF	0	6859	6860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1764	missileSkillMissileProjectileVelocityBonus	0	6861	6862	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1765	missileSkillMissileProjectileVelocityBonusSkillLevel	0	6864	6865	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1767	shipBonusPirateSanshaLaserCap	0	6871	6872	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1773	shipFalloffBonusGF	0	6892	6893	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1791	amarrShipEwTrackingDisruptAC1	0	6943	6944			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1802	shipMissileLightVelocityBonusCF2	0	6970	6971	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1803	shipMissileRocketVelocityBonusCF2	0	6972	6973	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1804	shipArmorEMResistanceAF1	0	6978	6979	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1805	shipArmorTHResistanceAF1	0	6980	6981	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1806	shipArmorKNResistanceAF1	0	6982	6983	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1807	shipArmorEXResistanceAF1	0	6984	6985	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1812	shipShieldEMResistanceCC2	0	6994	6995	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1813	shipShieldThermalResistanceCC2	0	6996	6997	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1814	shipShieldKineticResistanceCC2	0	6998	6999	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1815	shipShieldExplosiveResistanceCC2	0	7000	7001	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1816	shipShieldEMResistanceCF2	0	7002	7003	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1817	shipShieldThermalResistanceCF2	0	7004	7005	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1819	shipShieldKineticResistanceCF2	0	7008	7009	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1820	shipShieldExplosiveResistanceCF2	0	7010	7011	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1822	increaseGallenteNavyBonus	4	7021	7022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1824	increaseCaldariNavyBonus	4	7034	7035	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1825	increaseAmarrNavyBonus	4	7038	7039	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1826	increaseRepublicFleetBonus	4	7042	7043	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1833	miningYieldGangBonus	0	7073	7074	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1835	miningYieldMultiply	4	7078	7079	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1838	eliteBargeSkillMultiplier1	0	7094	7095	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1839	eliteBargeSkillMultiplier2	0	7098	7099	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1840	eliteBonusBargeMiningYield	0	7100	7101	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1848	miningForemanMindlink	0	7130	7131	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1849	miningBargeSkillLevelPostMulShipBonusORE3Ship	0	7136	7137	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1851	selfRof	0	7140	7141	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	SelfRof	0	0	0	0	\N	\N	\N	\N	\N
1852	shipMiningBonusAF	0	7142	7143	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1853	shipMiningBonusCF	0	7144	7145	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1854	shipCargoBonusGF	0	7146	7147	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1855	shipBonusScanProbeDurationCF	0	7148	7149	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1856	shipBonusScanProbeDurationGF	0	7150	7151	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1857	shipBonusScanProbeDurationMF	0	7152	7153	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1862	shipMissileEMDamageCF	0	7171	7172	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1863	shipMissileThermalDamageCF	0	7173	7174	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1864	shipMissileExplosiveDamageCF	0	7175	7176	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1865	shipMissileEMDamageMF2	0	7177	7178	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1866	shipMissileThermalDamageMF2	0	7179	7180	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1867	shipMissileKineticDamageMF2	0	7181	7182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1868	shipMissileThermalDamageAF1	0	7183	7184	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1869	shipMissileKineticDamageAF1	0	7185	7186	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1870	shipMissileExplosiveDamageAF1	0	7187	7188	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1871	entityTargetJam	2	7210	7211	Automatically generated effect		0	1	0	929	\N	\N	936	953	0	0		0	0	1	0	\N	\N	\N	930	\N
1872	entityCapacitorDrain	2	270	131	Steals power from the target.	effects.EnergyVampire	\N	0	0	942	\N	\N	937	\N	0	0		0	0	0	0	\N	\N	\N	931	\N
1877	entityTrackingDisrupt	2	1013	1014	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration.	effects.ElectronicAttributeModifyTarget	\N	0	0	944	\N	\N	940	951	0	0		0	1	0	0	1	\N	\N	933	\N
1878	entitySensorDampen	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	1	0	943	\N	\N	938	950	0	0		0	1	0	0	1	\N	\N	932	\N
1879	entityTargetPaint	2	3836	3837	Automatically generated effect		0	0	0	945	\N	\N	941	954	0	0		0	1	0	0	1	\N	\N	935	\N
1882	miningYieldMultiplyPercent	4	2240	2241	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1885	shipCruiseLauncherROFBonus2CB	0	7234	7235	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1886	shipSiegeLauncherROFBonus2CB	0	7236	7237	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1894	caldariNavyBonusHybridDamage	0	7265	7266	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1895	miningUpgradeCPUReductionBonus	0	7269	7270	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1896	eliteBargeBonusIceHarvestingCycleTimeBarge3	0	7271	7272	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1897	shieldCompensationSkillBoostHardeningBonus	0	7277	7278	Boost of hardeningBonus by PreMul of skillLevel		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1904	caldariNavyBonusCPUEnhancerBonus	1	7307	7308	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1905	caldariNavyBonusShieldBooster	0	7311	7312	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1908	reconShipSkillMultiplier1	0	7325	7326	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1909	reconShipSkillMultiplier2	0	7329	7330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1910	eliteBonusVampireDrainAmount2	0	7331	7332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1911	eliteReconBonusGravimetricStrength2	0	7335	7336	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1912	eliteReconBonusMagnetometricStrength2	0	7339	7340	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1913	eliteReconBonusRadarStrength2	0	7343	7344	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1914	eliteReconBonusLadarStrength2	0	7347	7348	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1920	eliteReconEnergyVampireRangeBonus1	0	7359	7360	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1921	eliteReconStasisWebBonus2	0	7361	7362	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1922	eliteReconJumpScramblerRangeBonus2	0	7367	7368	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1938	setActiveDamageResonanceMultiplier	1	7421	7422		effects.ModifyShieldResonance	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	2	\N	\N	\N	\N
1943	ammoEMResistOther	0	7435	7436	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	EM Resistance Modifier	0	0	0	0	\N	\N	\N	\N	\N
1959	armorReinforcerMassAdd	4	5841	5842	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1962	signatureRadiusBonus	1	7501	7502	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
1963	shipCargoBonusMF2	0	7503	7504	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1964	shipBonusShieldTransferCapneed1	0	7505	7506	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1965	shipBonusEnergyTransferCapNeed1	0	7507	7508	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1968	shipBonusTrackingLinkMC1	0	7513	7514			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1969	shipBonusRemoteArmorRepairCapNeedGC1	0	7515	7516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
1996	caldariShipEwCapacitorNeedCF2	0	7577	7578	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2000	droneRangeBonusAdd	4	2674	2675	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2003	droneDamageMultiplierBonusPercent	4	7602	7603	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2007	droneTrackingComputerMultiply	4	7616	7617		droneTrackingComputerMultiply	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2008	cynosuralDurationBonus	0	7618	7619	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2009	reconShipCpuMultiplier1	0	7620	7621	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2010	propulsionDroneJammingStrength	0	7626	7627	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2011	droneMaxVelocitySkillBonus	0	7630	7631	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2013	droneMaxVelocityBonus	0	7638	7639	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2014	droneMaxRangeBonus	0	7641	7642	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2015	droneDurabilityShieldCapBonus	0	7645	7646	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2016	droneDurabilityArmorHPBonus	0	7649	7650	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2017	droneDurabilityHPBonus	0	7653	7654	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2018	damageRepairedSkillBonus	0	7658	7659	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2019	repairDroneShieldBonusBonus	0	7662	7663	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2020	repairDroneArmorDamageAmountBonus	0	7666	7667	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2029	addToSignatureRadius2	4	7686	7687	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2041	modifyArmorResonancePostPercent	4	7725	7726			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2052	modifyShieldResonancePostPercent	4	7755	7756			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2053	emShieldCompensationHardeningBonusGroupShieldAmp	0	7761	7762	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2054	explosiveShieldCompensationHardeningBonusGroupShieldAmp	0	7765	7766	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2055	kineticShieldCompensationHardeningBonusGroupShieldAmp	0	7769	7770	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2056	thermalShieldCompensationHardeningBonusGroupShieldAmp	0	7773	7774	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2062	shieldCompensationSkillBoostHardeningBonus2	0	7793	7794	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2071	empWaveGrid	1	131	131	Triggering of a grid-wide EMP wave being broadcast into space.	effects.EMPWaveGrid	\N	1	0	73	\N	6	\N	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
2084	modifyArmorResonancePassivePostPercent	4	7861	7862			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2098	modifyActiveArmorResonanceAndNullifyPassiveResonance	1	7906	7907			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2105	emArmorCompensationHardeningBonusGroupArmorCoating	0	7924	7925	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2106	explosiveArmorCompensationHardeningBonusGroupArmorCoating	0	7928	7929	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2107	kineticArmorCompensationHardeningBonusGroupArmorCoating	0	7932	7933	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2108	thermicArmorCompensationHardeningBonusGroupArmorCoating	0	7936	7937	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2109	emArmorCompensationHardeningBonusGroupEnergized	0	7942	7943	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2110	explosiveArmorCompensationHardeningBonusGroupEnergized	0	7946	7947	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2111	kineticArmorCompensationHardeningBonusGroupEnergized	0	7950	7951	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2112	thermicArmorCompensationHardeningBonusGroupEnergized	0	7954	7955	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2113	passiveEmArmorResonanceBonusGroupArmorHardener2	0	7957	7958	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2115	passiveKineticArmorResonanceBonusGroupArmorHardener2	0	7963	7964	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2116	passiveThermicArmorResonanceBonusGroupArmorHardener2	0	7966	7967	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2117	modifyShieldResonancePassivePostPercent	4	7982	7983			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2118	modifyActiveShieldResonanceAndNullifyPassiveResonance	1	7968	7969		effects.ModifyShieldResonance	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2126	passiveEmShieldResonanceBonusGroupArmorHardener2	0	7989	7990	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2127	passiveExplosiveShieldResonanceBonusGroupArmorHardener2	0	7993	7994	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2128	passiveKineticShieldResonanceBonusGroupArmorHardener2	0	7997	7998	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2129	passiveThermicShieldResonanceBonusGroupArmorHardener2	0	8001	8002	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2130	smallHybridMaxRangeBonus	0	8003	8004	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2131	smallEnergyMaxRangeBonus	0	8005	8006	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2132	smallProjectileMaxRangeBonus	0	8007	8008	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2133	energyTransferArrayMaxRangeBonus	0	8009	8010	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2134	shieldTransporterMaxRangeBonus	0	8015	8016	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2135	armorRepairProjectorMaxRangeBonus	0	8021	8022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2136	trackingLinkMaxRangeBonus	0	8027	8028	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2140	dreadnoughShipBonusDroneShieldCapG2	0	8038	8039	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2141	dreadnoughShipBonusDroneArmorHPG2	0	8040	8041	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2142	dreadnoughShipBonusDroneStructureHPG2	0	8042	8043	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2143	minmatarShipEwTargetPainterMC2	0	6949	6950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2148	droneDamageBonusRequringDrones	0	7602	7603	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2152	jumpPortalGeneration	1	6732	6733		effects.JumpPortal	\N	0	0	1002	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2155	eliteBonusCommandShipProjectileDamageCS1	0	8087	8088	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2156	eliteBonusCommandShipProjectileFalloffCS2	0	8089	8090	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2157	eliteBonusCommandShipLaserDamageCS1	0	8091	8092	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2158	eliteBonusCommandShipLaserROFCS2	0	8093	8094	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2159	eliteBonusCommandShipHybridDamageCS1	0	8095	8096	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2160	eliteBonusCommandShipHybridFalloffCS2	0	8097	8098	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2161	eliteBonusCommandShipHybridOptimalCS1	0	8099	8100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2162	eliteBonusCommandShipSiegeCS2	0	8101	8102	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2163	eliteBonusCommandShipProjectileTrackingCS1	0	8103	8104	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2164	eliteBonusCommandShipSkirmishCS2	0	8105	8106	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2166	eliteBonusCommandShipArmoredCS2	0	8109	8110	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2168	eliteBonusCommandShipInfoCS2	0	8113	8114	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2179	shipBonusDroneHitpointsGC2	0	8138	8139			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2181	shipBonusDroneHitpointsFixedAC2	0	8142	8143			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2186	shipBonusDroneHitpointsGB2	0	8152	8153			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2187	shipBonusDroneDamageMultiplierGB2	0	8154	8155	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2188	shipBonusDroneDamageMultiplierGC2	0	8156	8157	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2189	shipBonusDroneDamageMultiplierAC2	0	8158	8159	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2190	dreadnoughtShipBonusDroneDamageMultiplierG2	0	8160	8161	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2191	shipMissileVelocityDF1	0	8168	8169	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2192	entityShieldBoostingSmall	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1006	\N
2193	entityShieldBoostingMedium	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1007	\N
2194	entityShieldBoostingLarge	1	4037	131		effects.ShieldBoosting	\N	0	0	636	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	1008	\N
2195	entityArmorRepairingSmall	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1009	\N
2196	entityArmorRepairingMedium	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1010	\N
2197	entityArmorRepairingLarge	1	4039	131	Repair damage to the ships armor.	effects.ArmorRepair	\N	0	0	630	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	1011	\N
2199	eliteBonusInterdictorsMissileThermalDamage1	0	8177	8178	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2200	eliteBonusInterdictorsMissileKineticDamage1	0	8179	8180	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2201	eliteBonusInterdictorsProjectileFalloff1	0	8181	8182	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2202	droneDmgBonusRequiringScoutDroneOP	0	8183	8184	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2215	shipBonusPirateFrigateProjDamage	0	8235	8236	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2218	navigationComputerWarpAccuracyBonus	1	8250	8251			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2221	warpNavigationWarpAccuracyBonus	0	8262	8263			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2224	warpNavigationWarpAccuracySkillLevel	0	8272	8273			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2231	scanStrengthBonusPercentActivate	1	8294	8295	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2232	scanStrengthBonusPercentOnline	4	8294	8295	Modifies the various electronics scan strengths..		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2246	scanStrengthTargetPercentBonus	2	8321	8322			\N	0	1	73	\N	6	54	158	0	0		0	1	0	0	\N	\N	\N	\N	\N
2247	dronesMaxActiveDroneBonusModAddMaxActiveActive	1	1876	1877	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2249	shipBonusDroneMiningAmountAC2	0	8329	8330	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2250	shipBonusDroneMiningAmountGC2	0	8331	8332	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2251	commandshipMultiRelayEffect	0	6083	6084	commandshipMultiRelayEffect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2252	covertOpsAndReconOpsCloakModuleDelayBonus	0	8338	8339	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2253	covertOpsStealthBomberTargettingDelayBonus	0	8344	8345	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2254	passiveExplosiveArmorResonanceBonusGroupArmorHardener2FIXED	0	8347	8348	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2255	tractorBeamCan	2	131	131		effects.TractorBeam	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2256	shipMissilePrecisionDF2	0	8349	8350	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2257	eliteBonusInterdictorsBubbleRoF2	0	8355	8356	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2258	eliteBargeMercoxiteCrystalBonus1	0	8361	8362	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2259	eliteBargeBonusDamageCloudReduction2	0	8364	8365	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2261	titanMinmatarProjectileRoF1	0	8376	8377	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2263	titanAmarrEnergyTurretCapNeed1	0	8374	8375	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2264	titanAmarrGangCapRecharge2	0	8382	8383	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2265	titanCaldariMissileKineticDmg1	0	8384	8385	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2266	titanCaldariGangShieldHp2	0	8386	8387	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2267	titanGallenteHybridDamage1	0	8388	8389	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2268	titanGallenteGangArmorHp2	0	8390	8391	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2287	titanAmarrSkillLevel1	0	8463	8464	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2288	titanAmarrSkillLevel2	0	8466	8467	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2289	titanCaldariSkillLevel1	0	8469	8470	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2290	titanCaldariSkillLevel2	0	8472	8473	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2291	titanGallenteSkillLevel1	0	8475	8476	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2292	titanGallenteSkillLevel2	0	8478	8479	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2293	titanMinmatarSkillLevel2	0	8481	8482	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2294	titanMinmatarSkillLevel1	0	8484	8485	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2296	modifyArmorResonancePassivePostPercentPassive	0	7861	7862			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2297	modifyShieldResonancePassivePostPercentPassive	0	7982	7983			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2298	scanStrengthBonusPercentPassive	0	8294	8295	Boosts some of the scan strengths for the period of activation.	effects.ScanStrengthBonusActivate	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2302	damageControl	1	8493	8494			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	\N	\N	\N	\N
2303	energyDestabilizationNew	2	8495	8496		effects.EnergyDestabilization	\N	1	0	73	\N	6	98	\N	0	0	energyDestabilizationTEST	0	0	0	0	0	\N	\N	\N	\N
2304	energyNosferatu	2	8497	8496		effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	2	\N	\N	\N	\N
2305	eliteReconBonusEnergyNeutAmount2	0	8502	8503	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2306	eliteReconBonusEnergyNeutRange1	0	8507	8508	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2308	eliteReconBonusAssaultLauncherROF1	0	8515	8516	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2309	droneMWDBoostOnline	4	8517	8518	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2311	skillADDmaxJumpClones	0	8527	8528	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2312	disallowOffensiveActChar	0	8534	8535	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	disallowOffensiveAct	0	0	0	0	\N	\N	\N	\N	\N
2313	carrierAmarrSkillLevel1	0	8551	8552	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2314	carrierAmarrSkillLevel2	0	8555	8556	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2315	carrierAmarrSkillLevel3	0	8559	8560	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2316	carrierCaldariSkillLevel1	0	8563	8564	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2317	carrierCaldariSkillLevel2	0	8567	8568	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2318	carrierCaldariSkillLevel3	0	8571	8572	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2319	carrierGallenteSkillLevel1	0	8575	8576	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2320	carrierGallenteSkillLevel2	0	8579	8580	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2321	carrierGallenteSkillLevel3	0	8583	8584	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2322	carrierMinmatarSkillLevel1	0	8587	8588	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2323	carrierMinmatarSkillLevel2	0	8591	8592	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2324	carrierMinmatarSkillLevel3	0	8595	8596	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2325	carrierAmarrDroneMax1	0	8597	8598	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2326	carrierCaldariDroneMax1	0	8599	8600	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2327	carrierGallenteDroneMax1	0	8601	8602	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2328	carrierMinmatarDroneMax1	0	8603	8604	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2332	carrierGallenteDroneOwnDmg2	0	8615	8616	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2334	cloneJumpAcceptingTmp	1	6742	6743			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2335	titanMinmatarGangSigRadius2	0	8619	8620	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2336	titanAmarrSkillLevel3	0	8632	8633	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2337	titanAmarrSkillLevel4	0	8636	8637	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2338	titanCaldariSkillLevel3	0	8640	8641	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2339	titanCaldariSkillLevel4	0	8644	8645	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2340	titanGallenteSkillLevel3	0	8648	8649	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2341	titanGallenteSkillLevel4	0	8652	8653	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2342	titanMinmatarSkillLevel3	0	8656	8657	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2343	titanMinmatarSkillLevel4	0	8660	8661	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2344	carrierAmarrSkillLevel4	0	8669	8670	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2345	carrierCaldariSkillLevel4	0	8673	8674	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2346	carrierGallenteSkillLevel4	0	8677	8678	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2347	titanAmarrLaserDmg3	0	8679	8680	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2348	titanAmarrLeadershipModuleAmount4	0	8685	8686	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2349	titanCaldariLeadershipModuleAmount4	0	8687	8688	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2350	titanGallenteLeadershipModuleAmount4	0	8689	8690	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2351	titanMinmatarLeadershipModuleAmount4	0	8691	8692	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2352	titanCaldariLauncherRoF3	0	8693	8694	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2353	titanMinmatarProjectileDmg3	0	8695	8696	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2354	capitalRemoteArmorRepairerCapNeedBonusSkill	0	8701	8702	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2355	capitalRemoteShieldTransferCapNeedBonusSkill	0	8707	8708	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2356	capitalRemoteEnergyTransferCapNeedBonusSkill	0	8713	8714	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2359	carrierMinmatarArmor&ShieldTransferDuration2	0	8723	8724			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2360	carrierAmarrLeadershipMaxGroupActive4	0	8725	8726	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2361	carrierCaldariLeadershipMaxGroupActive4	0	8727	8728	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2362	carrierGallenteLeadershipMaxGroupActive4	0	8729	8730	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2363	carrierMinmatarLeadershipMaxGroupActive4	0	8731	8732	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2364	carrierMinmatarSkillLevel4	0	8735	8736	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2371	carrierAmarrArmorResist2	0	8749	8750			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2378	carrierCaldariShieldResist2	0	8763	8764			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2381	carrierAmarrArmor&EnergyTransferRange3	0	8773	8774			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2384	carrierCaldariShield&EnergyTransferRange3	0	8781	8782			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2387	carrierGallenteArmor&ShieldTransferRange3	0	8787	8788			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2390	carrierMinmatarArmor&ShieldTransferRange3	0	8793	8794			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2392	iceHarvesterMiningAmountBonusMultiplier	0	8800	8801	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2393	titanJumpPortalCpuNeedBonus	0	8806	8807	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2394	titanAmarrJudgmentCpuNeedBonus	0	8812	8813	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2395	jumpPortalConsumptionBonusSkill	0	8816	8817	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2402	skillSuperWeaponDmgBonus	0	8840	8841			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2403	dreadnoughtSiegeModeCpuNeedBonus	0	8844	8845	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2406	carrierFighterControlRangeBonus	0	8855	8856	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2407	interdictorBubbleProbeLauncherCpuBonus	0	8859	8860	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2408	eliteBonusCommandShipMissileKineticDamageCS1	0	8861	8862	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2409	eliteBonusInterdictorsMissileEMDamage1	0	8863	8864	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2410	cloneVatMaxJumpCloneBonusSkill	0	8869	8870	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2411	cloneVatMaxJumpCloneBonusSkillLevel	0	8873	8874	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2412	cloneVatCpuNeedBonus	0	8879	8880	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2413	snowBallLaunching	2	114	89	Launches a missile	effects.MissileDeployment	\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	\N	\N	\N	\N
2415	gangShieldBoosterAndTransporterSpeed	1	8885	8886			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2418	gangShieldBoosteAndTransporterCapacitorNeed	1	8893	8894			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2419	titanCaldariOblivionCpuNeed	0	8899	8900	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2420	titanGallenteAuroraOminaeCpuNeed	0	8905	8906	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2421	titanMinmatarFirestormCpuNeed	0	8911	8912	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2422	implantVelocityBonus	0	8917	8918	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Max Velocity Bonus	0	0	0	0	\N	\N	\N	\N	\N
2423	eliteReconHeavyMissileKineticDamage1	0	8921	8922	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2424	eliteReconLightMissileKineticDamage1	0	8925	8926	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2426	skillInterdictorEliteBonus1SkillLevel	0	8935	8936	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2427	skillInterdictorEliteBonus2SkillLevel	0	8939	8940	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2429	advancedDroneInterfacingMaxGroupDCUSkillLevel	0	8947	8948	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2430	maxVelocityMultiplier	0	8949	8950	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2431	energyManagementSkillBoostCapacitorCapacityBonus	0	8959	8960	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2432	energyManagementCapacitorBonusPostPercentCapacityLocationShipGroupCapacitorCapacityBonus	0	8961	8962	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2434	fightersDmgBonusSkills	0	8963	8964	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2435	cpuPenaltyToSuperWeapons	0	8972	8973	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2436	cpuBonusToSelf	0	8974	8975	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2437	miningYieldGangBonusFixed	0	8976	8977	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2441	gangIceHarvestingDurationBonus	1	8984	8985	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2444	minerCpuUsageMultiplyPercent2	0	8996	8997	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2445	iceMinerCpuUsagePercent	4	8998	8999	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2449	eliteeliteBonusCommandShipDroneBay1	0	9006	9007	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2451	commandShipSkillMultiplier1	0	9016	9017	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2452	commandShipSkillMultiplier2	0	9019	9020	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2453	eliteBonusCommandShipLaserOptimalCS1FIXED	0	9021	9022	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2454	shipBonusMiningDroneAmountPercentGC2	0	9023	9024	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2455	vanHelsing	1	9025	9026	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	Van Helsing	0	0	0	0	\N	\N	\N	\N	\N
2456	miningUpgradeCPUPenaltyReductionModulesRequiringMiningUpgradePercent	0	9029	9030	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2458	gangMiningDroneYieldBonus	1	9035	9036	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2465	shipBonusArmorResistAB	0	9049	9050			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2467	shipLaserDamageBonusBC2	0	9053	9054	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2468	shipHeavyLauncherROFBC1	0	9055	9056	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2469	shipAssaultLauncherROFBC1	0	9057	9058	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2473	shipBonusDroneDamageMultiplierBC1	0	9071	9072	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2478	shipBonusDroneHitpointsBC1	0	9081	9082			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2479	iceHarvestCycleTimeModulesRequiringIceHarvestingOnline	4	5165	5166	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2480	decreaseTargetSpeedForStructures	2	3489	3491		effects.ModifyTargetSpeed	\N	1	0	73	\N	6	54	\N	0	1	Decrease Target Speed	0	0	0	0	\N	\N	\N	\N	\N
2481	warpScrambleForStructure	2	294	295	Attempts to prevent the target from warping.	effects.WarpScramble	\N	1	0	505	\N	6	103	\N	0	1	Warp Scramble	0	0	0	0	1	\N	504	\N	\N
2485	implantArmorHpBonus2	0	9093	9094	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2486	armorTankingGang2	0	9095	9096	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2487	skirmishWarfareVelocityBonus2	0	9099	9100	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2488	implantVelocityBonus2	0	9101	9102	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2489	shipTrackingLinkRange1Fixed	0	9103	9104	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	shipTrackinshipTrackingLinkRange1FixedgLinkRange1	0	0	0	0	\N	\N	\N	\N	\N
2490	shipTrackingLinkRange2Group	0	9105	9106	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2491	ewSkillEcmBurstRangeBonus	0	9112	9113	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2492	ewSkillEcmBurstCapNeedBonus	0	9116	9117	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2494	eliteBonusCommandShipsMissilePrecisionCS2	0	9122	9123	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2496	eliteReconBonusHeavyLauncherROF1	0	8509	8510	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	\N	\N	\N	\N
2502	shipLauncherRofBonusMB1	0	9139	9140	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2503	shipHTTrackingBonusGB2	0	9143	9144	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2504	shipBonusHybridTrackingGF2	0	4766	4767	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2507	droneControlUnitCpuNeedBonus	0	9151	9152	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2508	gangMiningLaserDurationBonus	1	9155	9156	Automatically generated effect		0	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
2523	armorRepairAmountBonusPassive	0	9164	9165	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2524	hybridTurretTrackingBonusPassiveTrackingSpeedMultiplier	0	9168	9169	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2525	shipBonusShieldBoosterMB1	0	9173	9174	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2537	shieldCapacityPenaltyPostPercentBoosterAttribute1	0	9224	9225	Automatically generated effect	None	1400	0	0	\N	\N	\N	\N	\N	0	1	Shield Capacity Penalty	0	0	0	0	\N	None	\N	\N	1089
2540	capacitorCapacityPenaltyBoosterAttribute2	0	9234	9235	Automatically generated effect	None	1400	0	0	\N	\N	\N	\N	\N	0	1	Capacitor Capacity Penalty	0	0	0	0	\N	None	\N	\N	1090
2543	turretOptimalRangePenaltyBoosterAttribute4	0	9244	9245	Automatically generated effect	None	1391	0	0	\N	\N	\N	\N	\N	0	1	Turret Optimal Range Penalty	0	0	0	0	\N	None	\N	\N	1092
2546	explosionVelocityPenaltyBoosterAttribute5	0	9254	9255	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Missile Explosion Velocity Penalty	0	0	0	0	\N	None	\N	\N	1093
2549	shieldBoostAmpPenaltyBoosterAttribute1	0	9262	9263	Automatically generated effect	None	2104	0	0	\N	\N	\N	\N	\N	0	1	Shield Booster Penalty	0	0	0	0	\N	None	\N	\N	1089
2552	maximumVelocityPenaltyBoosterAttribute2	0	9270	9271	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Maximum Velocity Penalty	0	0	0	0	\N	None	\N	\N	1090
2555	armorHpPenaltyBoosterAttribute3	0	9280	9281	Automatically generated effect	None	1383	0	0	\N	\N	\N	\N	\N	0	1	Armor Hitpoint Penalty	0	0	0	0	\N	None	\N	\N	1091
2558	missileVelocityPenaltyBoosterAttribute5	0	9290	9291	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Missile Velocity Penalty	0	0	0	0	\N	None	\N	\N	1093
2561	eliteBonusAssaultShipMissileVelocity1	0	9300	9301	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2565	turretFalloffPenaltyBoosterAttribute4	0	9314	9315	Automatically generated effect	None	1399	0	0	\N	\N	\N	\N	\N	0	1	Turret Falloff Penalty	0	0	0	0	\N	None	\N	\N	1092
2568	turretTrackingPenaltyBoosterAttribute4	0	9324	9325	Automatically generated effect	None	1398	0	0	\N	\N	\N	\N	\N	0	1	Turret Tracking Penalty	0	0	0	0	\N	None	\N	\N	1092
2571	aoeCloudSizePenaltyBoosterAttribute5	0	9334	9335	Automatically generated effect	None	1390	0	0	\N	\N	\N	\N	\N	0	1	Missile Cloud Size Penalty	0	0	0	0	\N	None	\N	\N	1093
2576	torpedoLaunchingIsOffensive	1	114	131		effects.TorpedoDeployment	\N	1	0	\N	\N	\N	\N	\N	0	1	torpedoLaunching	0	0	0	0	0	None	\N	\N	\N
2577	armorRepairerPenaltyBoosterAttribute3	0	9302	9303	Automatically generated effect	None	80	0	0	\N	\N	\N	\N	\N	0	1	Armor Repair Penalty	0	0	0	0	\N	None	\N	\N	1091
2580	neurotoxinRecoverySkillBoostChanceBonus	0	9373	9374	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	neurotoxinRecoverySkillBoostChanceModifier	0	0	0	0	\N	None	\N	\N	\N
2589	modifyBoosterEffectChanceWithBoosterChanceBonusPostPercent	0	9403	9404			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2590	naniteControlSkillBoostBoosterAttributeModifier	0	9409	9410	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2599	modifyBoosterAttributePostPercent	0	9437	9438			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2600	shieldBoostAmplifierPassiveLocationGroup	0	9439	9440	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2602	shipBonusEmShieldResistanceCB2	0	9450	9451	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2603	shipBonusExplosiveShieldResistanceCB2	0	9452	9453	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2604	shipBonusKineticShieldResistanceCB2	0	9454	9455	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2605	shipBonusThermicShieldResistanceCB2	0	9456	9457	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2606	scanGravimetricStrengthBonus	4	9459	9460	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2607	scanRadarStrengthBonusPercentageScanStrengthBonus	4	9461	9462	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2608	scanLadarStrengthBonusPercentageScanStrengthBonus	4	9463	9464	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2609	scanMagnetometricStrengthBonusPercentageScanStrengthBonus	4	9465	9466	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2611	eliteBonusGunshipProjectileDamage1	0	9467	9468	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2612	eliteBonusGunshipProjectileDamage2	0	9469	9470	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2613	eliteBonusGunshipLaserDamage1	0	9471	9472	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2641	gangInformationWarStrengthBonus	1	9559	9560			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
2642	gangInformationWarfareRangeBonus	1	9561	9562			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
2643	massReductionBonus	4	9566	9567	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2644	increaseSignatureRadiusOnline	4	3277	3278	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2645	scanResolutionMultiplierOnline	4	3935	3408	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2646	maxTargetRangeBonus	4	2692	2693	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2647	eliteBonusHeavyGunshipHeavyMissileLaunhcerRof2	0	9570	9571	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2648	eliteBonusHeavyGunshipHeavyAssaultMissileLaunhcerRof2	0	9576	9577	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2649	eliteBonusHeavyGunshipAssaultMissileLaunhcerRof2	0	9578	9579	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2653	missileProjectionComputerBonus	1	9580	9581			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2654	skillAstrometricsMaxGroupScanningBonusSkillLevel	0	9584	9585	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2656	scanStrengthBonusSkillLevelIncrease	0	9590	9591	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2657	scanGravimetricStrengthBonusRequringAstrometrics	0	9595	9596	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2658	scanProbeSpeedBonusRequiringAstrometrics	0	9599	9600	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2659	scanMagnetometricStrengthBonusRequringAstrometrics	0	9603	9604	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2660	scanLadarStrengthBonusRequringAstrometrics	0	9607	9608	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2661	scanRadarStrengthBonusRequringAstrometrics	0	9611	9612	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2662	entityEnvironmentalEffectDamageTest	1	288	131	Triggering of an EMP wave being broadcast into space.	effects.EMPWave	\N	0	0	73	\N	\N	99	\N	0	0		0	0	0	0	2	None	\N	930	\N
2663	rigSlot	0	131	131	Must be installed into an available rig slot on a ship.		3266	0	0	\N	\N	\N	\N	\N	0	1	Rig Slot	0	0	0	0	\N	None	\N	\N	\N
2664	ewCapNeedPercentageModifier	4	5695	5696	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2670	sensorBoosterActivePercentage	1	9629	9630		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
2671	maxTargetRangePremulModifier	0	9633	9634	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2672	scanResolutionPremulModifier	0	9637	9638	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2674	shipBonusProjectileDamageBC1	0	9641	9642	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2675	shipHeavyAssaultLaunhcerROFBC1	0	9643	9644	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2682	shipCruiserSizedLauncherROFBC1	0	9664	9665			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2683	addMedSlot	4	9667	9668	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2687	shipBonusArmorRepairAmountGB2	0	9671	9672	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2688	capNeedBonusEffectLasers	0	9675	9676	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	Capacitor Need Bonus	0	0	0	0	\N	None	\N	\N	\N
2689	capNeedBonusEffectHybrids	0	9679	9680	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2690	cpuNeedBonusEffectLasers	0	9683	9684	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2691	cpuNeedBonusEffectHybrid	0	9687	9688	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2692	cpuNeedBonusEffectProjectile	0	9691	9692	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2693	falloffBonusEffectLasers	0	9695	9696	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2694	falloffBonusEffectHybrids	0	9699	9700	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2695	falloffBonusEffectProjectiles	0	9703	9704	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2696	maxRangeBonusEffectLasers	4	2972	2973	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2697	maxRangeBonusEffectHybrids	0	9705	9706	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2698	maxRangeBonusEffectProjectiles	0	9707	9708	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2699	trackingSpeedMultiplierEffectLasers	0	9709	9710	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2700	trackingSpeedMultiplierEffectHybrids	0	9712	9713	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2701	trackingSpeedMultiplierEffectProjectiles	0	9716	9717	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2702	salvagingAccessDifficultyBonusEffect	4	9722	9723	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2706	drawbackPowerNeedLasers	0	9738	9739	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2707	drawbackPowerNeedHybrids	0	9740	9741	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2708	drawbackPowerNeedProjectiles	0	9742	9743	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2709	drawbackPowerNeedLaunchers	0	9744	9745	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2710	drawbackPowerNeedGunnery	0	9746	9747	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2712	drawbackArmorHP	0	9748	9749	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2713	drawbackCPUOutput	0	9751	9752	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2714	drawbackCPUNeedLaunchers	0	9753	9754	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2715	drawbackCPUNeedGunnery	0	9755	9756	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2716	drawbackSigRad	0	9757	9758	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2717	drawbackMaxVelocity	0	9759	9760	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2718	drawbackShieldCapacity	0	9761	9762	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2719	drawbackShieldUniformity	0	9766	9767	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2720	drawbackCapacitorCapacity	0	9768	9769	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2721	drawbackPowerOutput	0	9771	9772	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2722	drawbackROFGunnery	0	9773	9774	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2723	drawbackROFLaunchers	0	9775	9776	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2724	rigDrawbackBonusEffect	0	9781	9782	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2725	rigDrawbackSkillEffect	0	9791	9792	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2726	miningClouds	2	3134	184	Mining of ore.	effects.CloudMining	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	2	None	\N	\N	\N
2727	gasCloudHarvestingMaxGroupSkillLevel	0	9795	9796	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2734	shipECMScanStrengthBonusCF	0	9809	9810			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2735	boosterArmorHpPenalty	0	9823	9824	Automatically generated effect	None	1383	0	0	\N	\N	\N	\N	\N	0	1	Armor Hitpoint Penalty	0	0	0	0	\N	None	\N	\N	1091
2736	boosterArmorRepairAmountPenalty	0	9825	9826	Automatically generated effect	None	80	0	0	\N	\N	\N	\N	\N	0	1	Armor Repairer Penalty	0	0	0	0	\N	None	\N	\N	1091
2737	boosterShieldCapacityPenalty	0	9827	9828	Automatically generated effect	None	1384	0	0	\N	\N	\N	\N	\N	0	1	Shield Capacity Penalty	0	0	0	0	\N	None	\N	\N	1089
2738	boosterShieldBoostAmountPenalty	0	9829	9830	Automatically generated effect	None	1384	0	0	\N	\N	\N	\N	\N	0	1	Shield Booster Penalty	0	0	0	0	\N	None	\N	\N	1089
2739	boosterTurretOptimalRangePenalty	0	9831	9832	Automatically generated effect	None	1391	0	0	\N	\N	\N	\N	\N	0	1	Turret Optimal Range	0	0	0	0	\N	None	\N	\N	1092
2741	boosterTurretFalloffPenalty	0	9835	9836	Automatically generated effect	None	1399	0	0	\N	\N	\N	\N	\N	0	1	Turret Falloff Penalty	0	0	0	0	\N	None	\N	\N	1093
2743	boosterMissileExplosionCloudPenalty	0	9839	9840	Automatically generated effect	None	1390	0	0	\N	\N	\N	\N	\N	0	1	Missile Explosion Cloud Penalty	0	0	0	0	\N	None	\N	\N	1093
2745	boosterCapacitorCapacityPenalty	0	9845	9846	Automatically generated effect	None	1400	0	0	\N	\N	\N	\N	\N	0	1	Capacitor Capacity Penalty	0	0	0	0	\N	None	\N	\N	1090
2746	boosterMaxVelocityPenalty	0	9847	9848	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Max Velocity Penalty	0	0	0	0	\N	None	\N	\N	1090
2747	boosterTurretTrackingPenalty	0	9849	9850	Automatically generated effect	None	1398	0	0	\N	\N	\N	\N	\N	0	1	Turret Tracking Penalty	0	0	0	0	\N	None	\N	\N	1092
2748	boosterMissileVelocityPenalty	0	9851	9852	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Missile Velocity Penalty	0	0	0	0	\N	None	\N	\N	1093
2749	boosterMissileExplosionVelocityPenalty	0	9853	9854	Automatically generated effect	None	1389	0	0	\N	\N	\N	\N	\N	0	1	Explosion Velocity Penalty	0	0	0	0	\N	None	\N	\N	1093
2750	shipBonusECMGravimetricStrengthBonusCC	0	9855	9856	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2751	shipBonusECMMagnetometricStrengthBonusCC	0	9857	9858	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2752	shipBonusECMRadarBonusCC	0	9859	9860	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2753	shipBonusECMLadarBonusCC	0	9861	9862	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2754	shipBonusECMRadarLadarBonusCC	0	9863	9864			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2755	shipBonusECMGraviMagnetoMetricBonusCC	0	9865	9866			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2756	shipBonusECMStrengthBonusCC	0	9867	9868			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2757	salvaging	2	131	131		effects.Salvaging	\N	0	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2758	boosterModifyBoosterArmorHPPenalty	0	9874	9875	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2759	boosterModifyBoosterArmorRepairAmountPenalty	0	9879	9880	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2760	boosterModifyBoosterArmorPenalties	0	9881	9882			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2761	boosterModifyBoosterShieldCapacityPenalty	0	9885	9886	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2762	boosterModifyBoosterShieldBoostAmountPenalty	0	9889	9890	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2763	boosterModifyBoosterShieldPenalty	0	9891	9892			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2764	boosterModifyBoosterCapacitorCapacitorPenalty	0	9895	9896	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2765	boosterModifyBoosterMaxVelocityPenalty	0	9899	9900	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2766	boosterModifyBoosterMaxVelocityAndCapacitorPenalty	0	9901	9902			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2767	boosterModifyBoosterAOEVelocityPenalty	0	9905	9906	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2768	boosterModifyBoosterMissileAOECloudPenalty	0	9909	9910	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	boosterModifyBoosterAOEVelocityPenalty	0	0	0	0	\N	None	\N	\N	\N
2769	boosterModifyBoosterMissileVelocity	0	9913	9914	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2770	boosterModifyBoosterTurretFalloffPenalty	0	9917	9918	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2771	boosterModifyBoosterTurretOptimalPenalty	0	9921	9922	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2772	boosterModifyBoosterTurretTrackingPenalty	0	9925	9926	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2775	boosterModifyBoosterMissileAOEPenalty	0	9931	9932			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2776	boosterModifyBoosterMissilePenalty	0	9933	9934			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2777	boosterModifyBoosterTurretTrackingOptimalPenalty	0	9935	9936			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2778	boosterModifyBoosterTurretPenalty	0	9937	9938			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2779	shipLaserCapABC	0	9939	9940	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2780	maxVelocityBonusModifier	4	3908	3909	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2783	shipBonusMiningDroneAmountPercentAC2	0	9941	9942	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2784	bcsEmDamageBonus	4	9944	9945	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	bcuEmDamageBonus	0	0	0	0	\N	None	\N	\N	\N
2785	bcuExDamageBonus	4	9947	9948	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2786	bcuThDamageBonus	4	9950	9951	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2787	bcuKnDamageBonus	4	9953	9954	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2788	bcuKnThDamageBonus	4	9955	9956			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2789	bcuEmExDamageBonus	4	9957	9958			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2790	bcuDamageBonus	4	9959	9960			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2791	boosterMissileExplosionCloudPenaltyFixed	0	9963	9964	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2792	modifyArmorResonancePostPercentPassive	0	7725	7726			\N	0	0	\N	\N	\N	\N	\N	0	0	Armor Resonance Modifier	0	0	0	0	\N	None	\N	\N	\N
2794	salvagingAccessDifficultyBonusEffectPassive	0	9722	9723	Salvaging Access Difficulty Bonus	None	0	0	0	\N	\N	\N	\N	\N	0	0	Salvaging Access Difficulty Bonus	0	0	0	0	\N	None	\N	\N	\N
2795	modifyShieldResonancePostPercentPassive	0	7755	7756			\N	0	0	\N	\N	\N	\N	\N	0	0	modifyShieldResonancePostPercent	0	0	0	0	\N	None	\N	\N	\N
2796	massReductionBonusPassive	0	9566	9567	Mass Reduction Bonus (passive)	None	0	0	0	\N	\N	\N	\N	\N	0	0	Mass Reduction Bonus	0	0	0	0	\N	None	\N	\N	\N
2797	projectileWeaponSpeedMultiplyPassive	0	654	655	Scale the projectile weapon firing speed.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2798	projectileWeaponDamageMultiplyPassive	0	667	670	Scales the damage done by all fitted projectile weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2799	missileLauncherSpeedMultiplierPassive	0	4069	4070	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2801	energyWeaponSpeedMultiplyPassive	0	681	683	Scales the rate of fire of all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0	Energy Weapon Speed Modifier	0	0	0	0	\N	None	\N	\N	\N
2802	hybridWeaponDamageMultiplyPassive	0	669	672	Scales the damage done by all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2803	energyWeaponDamageMultiplyPassive	0	668	671	Scales the damage done by all fitted energy weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0	Energy Weapon Damage Modifier	0	0	0	0	\N	None	\N	\N	\N
2804	hybridWeaponSpeedMultiplyPassive	0	682	684	Scales the rate of fire of all fitted hybrid weapons.		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2805	shipBonusLargeEnergyWeaponDamageAB2	0	9965	9966	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2806	maxRangeBonusEffectHybridsMultiplier	0	9968	9969	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2807	maxRangeBonusEffectLasersMultiplier	0	9971	9972	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2808	maxRangeBonusEffectProjectilesMultiplier	0	9974	9975	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2809	shipMissileAssaultMissileVelocityBonusCC2	0	9976	9977	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2810	eliteBonusHeavyGunshipAssaultMissileFlightTime1	0	9980	9981	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2811	cpuPenaltyToScanProbeLaunchers	0	9986	9987	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2812	caldariShipECMBurstOptimalRangeCB3	0	9988	9989	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2814	shipBonusSurveyProbeExplosionDelaySkillSurveyCF	0	10000	10001	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2817	shipBonusSurveyProbeExplosionDelaySkillSurveyMF2	0	10002	10003	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	shipBonusSurveyProbeExplosionDelaySkillSurveyCF	0	0	0	0	\N	None	\N	\N	\N
2818	shipBonusSurveyProbeExplosionDelaySkillSurveyGF2	0	10004	10005	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	shipBonusSurveyProbeExplosionDelaySkillSurveyCF	0	0	0	0	\N	None	\N	\N	\N
2819	shipBonusSurveyProbeExplosionDelaySkillSurveyCovertOps2	0	10006	10007	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2820	maxScanDeviationSelfSkillModifier	0	10012	10013	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2821	maxScanDeviationModifierRequireingAstrometrics	0	10016	10017	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2822	commandBonus2MultiplyWithCommandBonus	0	10022	10023	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2823	gangInformationSensorDisruptorMaxTargetingRangeStrengthBonus	0	10026	10027	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2824	gangInformationSensorDisruptorScanResStrengthBonus	1	10030	10031	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2825	gangInformationSensorDisruptorTrackingDisruptorTrackingSpeedBonus	1	10034	10035	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2826	gangInformationSensorDisruptorTrackingDisruptorMaxRangeBonus	1	10038	10039	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2827	gangInformationTargetPainterSigRadBonus	1	10042	10043	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2828	gangInformationSensorDisruptorBonus	0	10044	10045			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2829	gangInformationTrackingDisruptorBonus	1	10046	10047			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2830	gangInformationTrackingSensorDisruptorBonus	0	10048	10049			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2831	gangInformationTrackingSensorDisruptorTargetPainterBonus	0	10050	10051			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2832	shieldBoosterDurationBonus	0	10054	10055	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2833	gangInformationSensorTrackingDisruptorTargetPainter	0	10050	10051			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2834	gangInformationAllEWARStrengthBonuses	1	10056	10057			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
2835	shipMissileVelocityPirateFactionHeavyAssault	0	10058	10059	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2836	eliteBonusInterdictorsInterdictionSphereLauncherReactivationDelay2	0	10064	10065	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2837	armorHPBonusAdd	4	10069	10070	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2838	shipShieldEmExplosiveResistanceCBC2	0	10071	10072			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2839	shipShieldKineticThermalResistanceCBC2	0	10073	10074			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2840	shipShieldResistanceCBC2	0	10075	10076			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2841	shipBonusHeavyMissileKineticDamageBC1	0	10077	10078	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2842	shipBonusHeavyAssaultMissileKineticDamageBC1	0	10081	10082	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2843	shipBonusStandardMissileKineticDamageBC1	0	10083	10084	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2844	shipBonusHeavyAssaultStandardMissileKineticDamageBC1	0	10085	10086			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2845	shipBonusCruiserSizedMissileKineticDamageBC1	0	10087	10088			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2846	skillBoostTrackingSpeedBonus	0	10091	10092	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2847	trackingSpeedBonusPassiveRequiringGunneryTrackingSpeedBonus	0	6248	6249	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2848	accessDifficultyBonusModifierRequiringArchaelogy	0	10099	10100	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2849	accessDifficultyBonusModifierRequiringHacking	0	10105	10106	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2850	durationBonusForGroupAfterburner	0	10109	10110	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2851	missileDMGBonusPassive	0	3657	3658	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2852	maxTargetingRangeBonusPremulPassive	0	840	841	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2853	cloakingTargetingDelayBonusLRSMCloakingPassive	0	10112	10113	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2854	scanResolutionBonusMultiplierPreMulPassive	0	3398	3399	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2855	eliteReconBonusHeavyAssaultLauncherROF1	0	10115	10116	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2856	setCanCloak	1	10122	10123	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2857	cynosuralGeneration	1	10124	10125			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2858	cloneJumpAccepting	1	10124	10125			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2859	modifyMaxVelocityOfShipOnline	4	3908	3909	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2861	agilityMultiplierOnTarget	2	566	567	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2862	testStasisWebifierEffect	2	10126	10127			\N	1	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2863	agilityBonusOnTargetPercentage	2	10130	10131	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	agilityBonusOnTarget	0	0	0	0	\N	None	\N	\N	\N
2864	newTestStasisWebifierEffect	2	10132	10133			\N	1	0	73	\N	6	54	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2865	velocityBonusOnline	4	8917	8918	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	1	Max Velocity Bonus	0	0	0	0	\N	None	\N	\N	\N
2866	biologyTimeBonusFixed	0	10138	10139	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2867	sentryDroneDamageBonus	0	10144	10145	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2868	armorDamageAmountBonusCapitalArmorRepairers	0	10146	10147	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2869	droneStasisWebifyingBonus	0	10154	10155	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2870	defenderMissileVelocityBonus	0	10160	10161	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	defenderMissileVelocity	0	0	0	0	\N	None	\N	\N	\N
2871	defenderMissileVelocityBonus2	0	2215	2216	Broken generic defender velocity boost		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2872	missileVelocityBonusDefender	0	10164	10165	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	missileBonusVelocityDefender	0	0	0	0	\N	None	\N	\N	\N
2873	missileEMDmgBonusCruise	0	10169	10170	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2874	missileExplosiveDmgBonusCruise	0	10173	10174	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2875	missileKineticDmgBonusCruise	0	10177	10178	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2876	missileThermalDmgBonusCruise	0	10181	10182	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2877	missileEMDmgBonusCruise2	0	10183	10184	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2878	missileExplosiveDmgBonusCruise2	0	10185	10186	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2879	missileKineticDmgBonusCruise2	0	10187	10188	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2880	missileThermalDmgBonusCruise2	0	10189	10190	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2881	missileEMDmgBonusCruise3	0	10191	10192	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2882	missileExplosiveDmgBonusCruise3	0	10193	10194	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2883	missileKineticDmgBonusCruise3	0	10195	10196	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2884	missileThermalDmgBonusCruise3	0	10197	10198	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2885	gasHarvestingCycleTimeModulesRequiringGasCloudHarvesting	0	10203	10204	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2886	setMaxLockedTargets	0	9127	9128	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2887	missileEMDmgBonusRocket	0	10207	10208	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2888	missileExplosiveDmgBonusRocket	0	10211	10212	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2889	missileKineticDmgBonusRocket	0	10215	10216	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2890	missileThermalDmgBonusRocket	0	10219	10220	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2891	missileEMDmgBonusStandard	0	10223	10224	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2892	missileExplosiveDmgBonusStandard	0	10227	10228	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2893	missileKineticDmgBonusStandard	0	10229	10230	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2894	missileThermalDmgBonusStandard	0	10231	10232	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2895	missileEMDmgBonusFOF	0	10237	10238	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2896	missileExplosiveDmgBonusFOF	0	10241	10242	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2897	missileKineticDmgBonusFOF	0	10245	10246	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2898	missileThermalDmgBonusFOF	0	10249	10250	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2899	missileEMDmgBonusHeavy	0	10253	10254	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2900	missileExplosiveDmgBonusHeavy	0	10255	10256	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2901	missileKineticDmgBonusHeavy	0	10257	10258	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2902	missileThermalDmgBonusHeavy	0	10261	10262	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2903	missileEMDmgBonusHAM	0	10265	10266	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2904	missileExplosiveDmgBonusHAM	0	10269	10270	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2905	missileKineticDmgBonusHAM	0	10271	10272	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2906	missileThermalDmgBonusHAM	0	10275	10276	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2907	missileEMDmgBonusTorpedo	0	10279	10280	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2908	missileExplosiveDmgBonusTorpedo	0	10283	10284	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2909	missileKineticDmgBonusTorpedo	0	10287	10288	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2910	missileThermalDmgBonusTorpedo	0	10291	10292	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2911	dataminerModuleDurationReduction	0	10297	10298	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2912	energyDestabilizationNewForStructure	2	8495	8496		effects.EnergyDestabilization	\N	1	0	73	\N	\N	98	\N	0	0	energyDestabilizationTEST	0	0	0	0	0	None	\N	\N	\N
2913	remoteEcmBurst	2	131	471		effects.RemoteECM	\N	0	0	73	\N	6	54	\N	0	0		0	0	1	0	\N	None	\N	\N	\N
2915	warpScrambleSelfSiegeModeWarpStatus	4	10309	10310	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	warpScrambleSelf	0	0	0	0	\N	None	\N	\N	\N
2918	posStructureControlAmountBonus	0	10331	10332	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2919	triageModeWarpScrambleSelf	1	10309	10310	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	warpScrambleSelf	0	0	0	0	\N	None	\N	\N	\N
2924	triageModeMaxVelocityBonus	1	3488	3490	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2925	triageModeSitDown	1	10348	10349	TriageMode: WarpScrambleSelf + MaxVelocityBonus		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2928	triageModeArmorAmount	1	10359	10360	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2929	triageModeArmorDuration	1	6703	6704	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2931	triageModeShieldAmount	1	6694	6695	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2932	triageModeShieldDuration	1	10365	10366	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2933	triageModeSiegeTankArmor	1	10363	10364			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2934	triageModeSiegeTankShield	1	10367	10368			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2935	triageModeSiegeTank	1	10369	10370			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2936	triageModeLogisticsArmorAmount	1	10376	10377	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2937	triageModeLogisticsArmorDuration	1	10378	10379	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2938	triageModeLogisticsArmor	1	10380	10381			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2939	triageModeLogisticsShieldAmount	1	10387	10388	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2940	triageModeLogisticsShieldDuration	1	10389	10390	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2941	triageModeLogisticsShield	1	10391	10392			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2943	triageModeSensorEWCapNeedBonusECM	1	10397	10398	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2944	triageModeSensorEWCapNeedBonusRSD	1	10401	10402	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2945	triageModeSensorEWCapNeedBonusTD	1	10405	10406	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2946	triageModeSensorEWCapNeedBonusTP	1	10409	10410	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2947	triageModeSensorEWCapNeedBonusECMandRSD	1	10411	10412			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2948	triageModeSensorEWCapNeedBonusTDandTP	1	10413	10414			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2949	triageModeSensorEWCapNeedBonus	1	10415	10416			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2950	triageModeSensorPropJamCapNeedBonus	1	10417	10418	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2951	triageModeSensorCapNeedBonus	1	10419	10420			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2953	triageModeSensorScanResolutionMultiplier	1	3398	3399	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2956	triageModeSiegeTankAndSitDown	1	10425	10426			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2959	triageModeDroneBonus	1	10434	10435	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2967	skillTriageModuleConsumptionQuantityBonus	0	10459	10460	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2968	triageModeCpuBonus	0	10465	10466	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2971	bombLaunching	1	114	89	Launches a missile	effects.MissileDeployment	\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
2974	skillRemoteECMDurationBonusSkillLevel	0	10487	10488	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2976	projECMCpuNeedBonusEffect	0	10493	10494	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2977	skillRemoteHullRepairSystemsCapNeedBonus	0	10499	10500	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2979	skillRemoteHullRepairSystemsCapNeedBonus	0	10508	10509	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2980	skillCapitalRemoteHullRepairSystemsCapNeedBonus	0	10511	10512	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2982	skillRemoteECMDurationBonus	0	10480	10481	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2983	triageModeLogisticsHullAmount	1	10527	10528	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2984	triageModeLogisticsHullDuration	1	10531	10532	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2985	triageModeLogisticsEnergyAmount	1	10535	10536	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2986	triageModeLogisticsEnergyDuration	1	10539	10540	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2987	triageModeLogisticsEnergy	1	10541	10542			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2988	triageModeLogisticsHull	1	10543	10544			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2989	triageModeLogisticsEnergyAndHull	1	10545	10546			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2990	triageModeLogisticsArmorAndShield	1	10393	10394			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2991	triageModeLogistics	1	10547	10548			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
2992	triageModeSensorMaxLockedTargetsBonus	1	798	800	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
2994	triageModeSensorTargeting	1	10549	10550			\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3001	overloadRofBonus	5	10567	10568	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3002	overloadSelfDurationBonus	5	10571	10572	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3003	energyDestabilizationForStructure	2	286	131	Drains power from the target.	effects.EnergyDestabilization	\N	1	0	73	\N	\N	98	\N	0	0		0	0	0	0	2	None	\N	\N	\N
3004	setGlobalPool	0	10577	10578	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3014	skillBombDeploymentSpeedBonus	0	10615	10616	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3015	eliteBonusStealhBomberBombDeploymentCpu	0	10621	10622	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3016	covertOpsAgilityBonus2	0	10623	10624	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3024	eliteBonusCoverOpsBombExplosiveDmg1	0	10652	10653	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3025	overloadSelfDamageBonus	5	10654	10655	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3026	eliteBonusCoverOpsBombKineticDmg1	0	10656	10657	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3027	eliteBonusCoverOpsBombThermalDmg1	0	10658	10659	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3028	eliteBonusCoverOpsBombEmDmg1	0	10660	10661	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3029	overloadSelfEmHardeningBonus	5	10663	10664	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3030	overloadSelfThermalHardeningBonus	5	10666	10667	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	overloadSelfEmHardeningBonus	1	0	0	0	\N	None	\N	\N	\N
3031	overloadSelfExplosiveHardeningBonus	5	10669	10670	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	overloadSelfEmHardeningBonus	1	0	0	0	\N	None	\N	\N	\N
3032	overloadSelfKineticHardeningBonus	5	10672	10673	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	overloadSelfEmHardeningBonus	1	0	0	0	\N	None	\N	\N	\N
3035	overloadSelfHardeningInvulnerabilityBonus	5	10678	10679			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3036	skillBombDeploymentModuleReactivationDelayBonus	0	10682	10683	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3037	missileDamageMultiplierCruiseEmBonus	0	10684	10685	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3038	missileDamageMultiplierCruiseThermalBonus	0	10686	10687	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3039	missileDamageMultiplierCruiseKineticBonus	0	10688	10689	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3040	missileDamageMultiplierCruiseExplosiveBonus	0	10690	10691	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3041	remoteHullRepair	2	131	131	Targeted (remote) Hull Repair effect.	effects.RemoteArmourRepair	\N	0	1	73	\N	6	54	\N	0	0		0	0	0	0	2	None	\N	\N	\N
3042	triageModeSensor	1	10692	10693			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3043	triageModeLogisticsAndSensor	1	10694	10695			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3044	triageModeLogisticsAndSensorAndDrone	1	10696	10697			\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3045	triageModeEffectWithoutECMBurst	1	10698	10699	Boost armor/shield logistics and tank, sensor boost, disallow EW, reduce max active drones and force the ship to sit down.	effects.TriageMode	\N	0	0	73	\N	6	\N	\N	0	0	triageModeEffect	0	0	0	0	\N	None	\N	\N	\N
3046	modifyMaxVelocityOfShipPassive	0	3908	3909	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3047	structureHPMultiplyPassive	0	494	495			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3050	carrierMinmatarArmor&ShieldAmount	0	10706	10707			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3052	cpuPenaltyToBombLaunchers	0	10708	10709	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3053	cpuPenaltyToProjectedECM	0	10712	10713	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3055	triageModeSensorEWCapNeedBonusECMBurstECMBurst	1	10718	10719	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3056	triageModeSensorEWCapNeedBonusECMBurstRemoteECMBurst	1	10724	10725	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3057	triageModeSensorEWCapNeedBonusECMBurst	1	10726	10727			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3060	siegeModeEffectMaxTargetPenality	1	10731	10732	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3061	heatDamageBonus	0	10735	10736	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3062	siegeModeEffect	1	10737	10738		effects.SiegeMode	\N	0	0	73	\N	\N	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
3063	controlTowerGenericOutsideStructureResistanceBonus	0	8493	8494			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3064	controlTowerGenericHullEmResistanceBonusCynoGenerator	0	10743	10744	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3065	controlTowerGenericHullExplosiveResistanceBonusCynoGenerator	0	10747	10748	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3066	controlTowerGenericHullKineticResistanceBonusCynoGenerator	0	10751	10752	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3067	controlTowerGenericHullThermicResistanceBonusCynoGenerator	0	10755	10756	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3068	controlTowerGenericHullThermicResistanceBonusCynoJammer	0	10761	10762	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3069	controlTowerGenericHullKineticResistanceBonusCynoJammer	0	10765	10766	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3070	controlTowerGenericHullExplosiveResistanceBonusCynoJammer	0	10769	10770	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3071	controlTowerGenericHullEmResistanceBonusCynoJammer	0	10773	10774	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3072	controlTowerGenericHullEmResistanceBonusEcm	0	10777	10778	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3073	controlTowerGenericHullExplosiveResistanceBonusEcm	0	10781	10782	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3074	controlTowerGenericHullKineticResistanceBonusEcm	0	10785	10786	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3075	controlTowerGenericHullThermicResistanceBonusEcm	0	10789	10790	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3076	controlTowerGenericHullThermicResistanceBonusEnergyNeutralizer	0	10795	10796	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3077	controlTowerGenericHullKineticResistanceBonusEnergyNeutralizer	0	10799	10800	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3078	controlTowerGenericHullExplosiveResistanceBonusEnergyNeutralizer	0	10803	10804	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3079	controlTowerGenericHullEmResistanceBonusEnergyNeutralizer	0	10807	10808	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3080	controlTowerGenericHullEmResistanceBonusJumpPortal	0	10813	10814	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3081	controlTowerGenericHullExplosiveResistanceBonusJumpPortal	0	10817	10818	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3082	controlTowerGenericHullKineticResistanceBonusJumpPortal	0	10821	10822	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3083	controlTowerGenericHullThermicResistanceBonusJumpPortal	0	10825	10826	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3084	controlTowerGenericHullThermicResistanceBonusHybrid	0	10829	10830	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3085	controlTowerGenericHullKineticResistanceBonusHybrid	0	10833	10834	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3086	controlTowerGenericHullExplosiveResistanceBonusHybrid	0	10837	10838	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3087	controlTowerGenericHullEmResistanceBonusHybrid	0	10841	10842	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3088	controlTowerGenericHullEmResistanceBonusLaser	0	10845	10846	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3089	controlTowerGenericHullExplosiveResistanceBonusLaser	0	10849	10850	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3090	controlTowerGenericHullKineticResistanceBonusLaser	0	10853	10854	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3091	controlTowerGenericHullThermicResistanceBonusLaser	0	10857	10858	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3092	controlTowerGenericHullThermicResistanceBonusMissile	0	10861	10862	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3093	controlTowerGenericHullKineticResistanceBonusMissile	0	10865	10866	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3094	controlTowerGenericHullExplosiveResistanceBonusMissile	0	10869	10870	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3095	controlTowerGenericHullEmResistanceBonusMissile	0	10873	10874	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3096	controlTowerGenericHullEmResistanceBonusProjectile	0	10877	10878	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3097	controlTowerGenericHullExplosiveResistanceBonusProjectile	0	10881	10882	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3098	controlTowerGenericHullKineticResistanceBonusProjectile	0	10885	10886	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3099	controlTowerGenericHullThermicResistanceBonusProjectile	0	10889	10890	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3100	controlTowerGenericHullThermicResistanceBonusSensorDampener	0	10895	10896	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3101	controlTowerGenericHullKineticResistanceBonusSensorDampener	0	10899	10900	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3102	controlTowerGenericHullExplosiveResistanceBonusSensorDampener	0	10903	10904	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3103	controlTowerGenericHullEmResistanceBonusSensorDampener	0	10907	10908	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3104	controlTowerGenericHullEmResistanceBonusStasis	0	10913	10914	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3105	controlTowerGenericHullExplosiveResistanceBonusStasis	0	10917	10918	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3106	controlTowerGenericHullKineticResistanceBonusStasis	0	10921	10922	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3107	controlTowerGenericHullThermicResistanceBonusStasis	0	10925	10926	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3108	controlTowerGenericHullThermicResistanceBonusScrambler	0	10931	10932	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3109	controlTowerGenericHullKineticResistanceBonusScrambler	0	10935	10936	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3110	controlTowerGenericHullExplosiveResistanceBonusScrambler	0	10939	10940	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3111	controlTowerGenericHullEmResistanceBonusScrambler	0	10943	10944	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3112	controlTowerGenericHullE&EResistanceBonusCynoGenerator	0	10945	10946			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3113	controlTowerGenericHullE&EResistanceBonusCynoJammer	0	10947	10948			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3114	controlTowerGenericHullE&EResistanceBonusEcm	0	10949	10950			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullE&EResistanceBonusCynoEcm	0	0	0	0	\N	None	\N	\N	\N
3115	controlTowerGenericHullE&EResistanceBonusEnergyNeutralizer	0	10951	10952			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullE&EResistanceBonusCynoEnergyNeutralizer	0	0	0	0	\N	None	\N	\N	\N
3116	controlTowerGenericHullE&EResistanceBonusHybrid	0	10953	10954			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullE&EResistanceBonusCynoEnergyHybrid	0	0	0	0	\N	None	\N	\N	\N
3117	controlTowerGenericHullE&EResistanceBonusJumpPortal	0	10955	10956			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullE&EResistanceBonusCynoEnergyJumpPortal	0	0	0	0	\N	None	\N	\N	\N
3118	controlTowerGenericHullE&EResistanceBonusLaser	0	10957	10958			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullE&EResistanceBonusCynoEnergyLaser	0	0	0	0	\N	None	\N	\N	\N
3119	controlTowerGenericHullE&EResistanceBonusMissile	0	10959	10960			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3120	controlTowerGenericHullE&EResistanceBonusProjectile	0	10961	10962			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3121	controlTowerGenericHullE&EResistanceBonusScrambler	0	10963	10964			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3122	controlTowerGenericHullE&EResistanceBonusSensorDampener	0	10965	10966			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3123	controlTowerGenericHullE&EResistanceBonusStasis	0	10967	10968			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3124	controlTowerGenericHullK&TResistanceBonusCynoGenerator	0	10969	10970			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3125	controlTowerGenericHullK&TResistanceBonusCynoJammer	0	10971	10972			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3126	controlTowerGenericHullK&TResistanceBonusEcm	0	10973	10974			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3127	controlTowerGenericHullK&TResistanceBonusEnergyNeutralizer	0	10975	10976			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3128	controlTowerGenericHullK&TResistanceBonusHybrd	0	10977	10978			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3129	controlTowerGenericHullK&TResistanceBonusJump	0	10979	10980			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3130	controlTowerGenericHullK&TResistanceBonusLaser	0	10981	10982			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3131	controlTowerGenericHullK&TResistanceBonusMissile	0	10983	10984			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3133	controlTowerGenericHullK&TResistanceBonusProjectile	0	10985	10986			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3134	controlTowerGenericHullK&TResistanceBonusScrambler	0	10987	10988			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3135	controlTowerGenericHullK&TResistanceBonusSenDamp	0	10989	10990			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3136	controlTowerGenericHullK&TResistanceBonusStasis	0	10991	10992			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3137	controlTowerGenericHullResistanceBonusCynoGenerator	0	10993	10994			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3138	controlTowerGenericHullResistanceBonusCynoJammer	0	10995	10996			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3139	controlTowerGenericHullResistanceBonusEcm	0	10997	10998			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3140	controlTowerGenericHullResistanceBonusEnergyNeutralizer	0	10999	11000			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3141	controlTowerGenericHullResistanceBonusHybrid	0	11001	11002			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3142	controlTowerGenericHullResistanceBonusJumpPortal	0	11003	11004			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3143	controlTowerGenericHullResistanceBonusLaser	0	11005	11006			\N	0	0	\N	\N	\N	\N	\N	0	0	controlTowerGenericHullResistanceBonusJLaser	0	0	0	0	\N	None	\N	\N	\N
3144	controlTowerGenericHullResistanceBonusMissile	0	11007	11008			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3145	controlTowerGenericHullResistanceBonusProjectile	0	11009	11010			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3146	controlTowerGenericHullResistanceBonusScrambler	0	11011	11012			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3148	controlTowerGenericHullResistanceBonusSensorDampener	0	11013	11014			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3149	controlTowerGenericHullResistanceBonusStasis	0	11015	11016			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3150	controlTowerGenericHullResistanceBonusCG&CGJ	0	11017	11018			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3151	controlTowerGenericHullResistanceBonusCG&CGJ&ECM	0	11019	11020			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3152	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN	0	11021	11022			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3153	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H	0	11023	11024			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3154	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP	0	11025	11026			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3155	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP&L	0	11027	11028			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3156	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP&L&M	0	11029	11030			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3157	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP&L&M&P	0	11031	11032			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3158	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP&L&M&P&SC	0	11033	11034			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3159	controlTowerGenericHullResistanceBonusCG&CGJ&ECM&EN&H&JP&L&M&P&SC&SD	0	11035	11036			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3160	controlTowerGenericHullResistanceBonus	0	11037	11038			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3161	sensorBoostTargetedHostileKali2Test	2	3525	3526		effects.ElectronicAttributeModifyTarget	\N	0	0	73	\N	\N	54	158	0	0	sensorBoostTargetedHostile	0	1	0	0	1	None	\N	\N	\N
3162	triageModeEffect	1	11039	11040	Boost armor/shield logistics and tank, sensor boost, disallow EW, reduce max active drones and force the ship to sit down.	effects.TriageMode	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3164	gangArmorRepairCapReducerProjected	1	11049	11050	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3165	gangArmorRepairCapReducerSelfAndProjected	1	11051	11052		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3166	gangArmorRepairSpeedAmplifierProjected	1	11055	11056	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3167	gangArmorRepairSpeedAmplifierSelfAndProjected	1	11057	11058		effects.ElectronicAttributeModifyActivate	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3168	remoteArmorPowerNeedBonusEffect	0	11065	11066	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3169	shieldTransportCpuNeedBonusEffect	0	11069	11070	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3171	energyTransferPowerNeedBonusEffect	0	11077	11078	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3172	droneArmorDamageBonusEffect	0	11082	11083	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3173	droneShieldBonusBonusEffect	0	11084	11085	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3174	overloadSelfRangeBonus	5	11090	11091	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3175	overloadSelfSpeedBonus	5	11095	11096	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3182	overloadSelfECMStrenghtBonus	5	11120	11121			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3189	overloadSelfECCMStrenghtBonus	5	11144	11145			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3191	increaseSignatureRadiusPassive	0	3277	3278	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3192	signatureRadiusMultiplierPassive	0	11152	11153	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3193	cloakingSignatureRadiusMultiplierMultiplierActive	1	11159	11160	Automatically generated effect	None	0	0	0	73	\N	\N	\N	\N	0	0	None	1	0	0	0	\N	None	\N	\N	\N
3195	thermodynamicsSkillLevel	0	11169	11170	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3196	thermodynamicsSkillDamageBonus	0	11172	11173	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3197	overloadSelfArmorDamageAmount	5	11178	11179	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3198	overloadSelfShieldBonus	5	11183	11184	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3200	overloadSelfArmorDamageAmountDurationBonus	5	11189	11190			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3201	overloadSelfShieldBonusDurationBonus	5	11191	11192			\N	0	0	\N	\N	\N	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3202	dronesMaxActiveDroneBonusModAddMaxActiveLocationCharOnline	4	1876	1877	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	dronesMaxActiveDroneBonusModAddMaxActiveDronesLocationChar	0	0	0	0	\N	None	\N	\N	\N
3205	eliteBonusCoverOpsCruiseKineticDmg1	0	11193	11194	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3209	droneDurabilityShieldCapBonus2	0	7678	7679	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3210	droneDurabilityArmorHPBonus2	0	7680	7681	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3212	missileSkillFoFAoeCloudSizeBonus	0	11212	11213	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3213	shipHeavyAssaultMissileEmDmgAC1	0	11214	11215	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3214	shipHeavyAssaultMissileThermalDmgAC1	0	11216	11217	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3215	shipHeavyAssaultMissileKineticDmgAC1	0	11218	11219	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3216	shipHeavyAssaultMissileExplosiveDmgAC1	0	11220	11221	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3219	eliteBonusHeavyGunshipMissileEmDmg2	0	11226	11227	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3223	eliteBonusHeavyGunshipMass1	0	11228	11229	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3224	eliteBonusHeavyGunshipCapRecharge1	0	11230	11231	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3225	eliteBonusCommandShipCapRecharge1	0	11232	11233	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3226	shipHeavyAssaultMissileEmDmgBC2	0	11234	11235	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3227	shipHeavyAssaultMissileThermalDmgBC2	0	11236	11237	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3228	shipHeavyAssaultMissileKineticDmgBC2	0	11238	11239	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3229	shipHeavyAssaultMissileExplosiveDmgBC2	0	11240	11241	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3230	shipRocketEmDmgDF1	0	11242	11243	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3231	shipRocketThermalDmgDF1	0	11244	11245	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3232	shipRocketKineticDmgDF1	0	11246	11247	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3233	shipRocketExplosiveDmgDF1	0	11248	11249	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3234	shipRocketExplosiveDmgAF	0	11250	11251	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3235	shipRocketKineticDmgAF	0	11252	11253	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3236	shipRocketThermalDmgAF	0	11254	11255	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3237	shipRocketEmDmgAF	0	11256	11257	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3238	shipMissileVelocityDF2	0	11258	11259	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3239	shipMissileAoeVelocityDF2	0	11260	11261	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3240	eliteBonusInterdictorsMissileVelocity1	0	11262	11263	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3241	eliteBonusGunshipArmorEmResistance1	0	11264	11265	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3242	eliteBonusGunshipArmorThermalResistance1	0	11266	11267	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3243	eliteBonusGunshipArmorKineticResistance1	0	11268	11269	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3244	eliteBonusGunshipArmorExplosiveResistance1	0	11270	11271	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3245	shipArmorExplosiveResistance2AF	0	11272	11273	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3246	shipArmorKineticResistance2AF	0	11274	11275	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3247	shipArmorThermalResistance2AF	0	11276	11277	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3248	shipArmorEmResistance2AF	0	11278	11279	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3249	shipCapRecharge2AF	0	3283	3284	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3250	leech	2	131	131		effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3253	tacticalShieldManipulationBonus	0	11288	11289	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0	tacticalShieldManipulation	0	0	0	0	\N	None	\N	\N	\N
3254	tacticalShieldManipulationBonus2	0	11291	11292	Automatically generated effect		0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3255	massBonusTarget	2	11301	11302	Automatically generated effect	None	0	1	0	73	\N	6	54	158	0	0		0	0	0	0	\N	None	\N	\N	\N
3260	industrialCoreCommandBonusEffectiveAdd	1	11324	11325	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3261	shipCommandBonusEffectiveMultiplierOreCapital2	0	11330	11331	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3262	oreCapitalShipSkillMultiplier1	0	11340	11341	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3263	oreCapitalShipSkillMultiplier2	0	11344	11345	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3264	skillIndustrialReconfigurationConsumptionQuantityBonus	0	11350	11351	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3265	industrialReconfigurationCpuNeedBonus	0	11354	11355	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3267	shipConsumptionQuantityBonusIndustrialReconfigurationORECapital1	0	11359	11360	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3268	miningDirectorBonusCommandBonusEffective	0	11361	11362	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3278	industrialCoreSurveyScannerBonus	1	11401	11402	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3279	industrialCoreCargoScannerBonus	1	11405	11406	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3280	industrialCoreScannerBonus	1	11407	11408			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3281	industrialCoreScannerAndCommandBonus	1	11409	11410			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3282	industrialCoreEffectOLD	1	11411	11412		effects.SiegeMode	\N	0	0	73	\N	6	\N	\N	0	0	industrialCoreEffect	0	0	0	0	\N	None	\N	\N	\N
3283	tractorBeamCpuNeedBonus	0	11417	11418	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3291	gangMiningLaserMaxRangeBonus	1	11442	11443	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3292	gangIceHarvesterMaxRangeBonus	1	11446	11447	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3294	gangGasCloudHarvestingMaxRangeBonus	1	11451	11453	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3295	gangMiningLaserAndIceHarvesterMaxRangeBonus	1	11454	11455			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3296	gangMiningLaserAndIceHarvesterAndGasCloudHarvesterMaxRangeBonus	1	11456	11457			\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3297	shipEnergyNeutralizerTransferAmountBonusAB	0	11458	11459	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3298	shipEnergyNeutralizerTransferAmountBonusAC	0	11460	11461	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3299	shipEnergyNeutralizerTransferAmountBonusAF	0	11462	11463	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3300	gangGasHarvesterDurationBonus	1	11466	11467	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3301	gangIceHarvesterAndMiningLaserDurationBonus	1	11468	11469	gangIceHarvesterAndMiningLaserRangeBonus		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3302	gangGasHarvesterAndIceHarvesterAndMiningLaserDurationBonus	1	11470	11471	gangGasHarvesterAndIceHarvesterAndMiningLaserDurationBonus		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3303	gangGasHarvesterCapNeedBonus	1	11474	11475	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3304	gangIceHarvesterCapNeedBonus	1	11478	11479	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3305	gangMiningLaserCapacitorNeed	1	11482	11483	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3306	gangGasHarvesterAndIceHarvesterCapNeedBonus	1	11484	11485	gangGasHarvesterAndIceHarvesterCapNeedBonus		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3307	gangGasHarvesterAndIceHarvesterAndMiningLaserCapNeedBonus	1	11486	11487	gangGasHarvesterAndIceHarvesterAndMiningLaserCapNeedBonus		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3308	oreCapitalShipShieldTransferRange	0	11490	11491	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3311	oreCapitalShipSkillMultiplier3	0	11503	11504	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3313	cloneVatMaxJumpCloneBonusSkillNew	0	11509	11510	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3316	shipMissileHeavyVelocityBC2	0	9645	9646	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3317	shipMissileHeavyAssaultVelocityBC2	0	9651	9652	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3321	shipBonusORECapShipDroneDmgBonus	0	11529	11530	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3322	shipBonusORECapShipDroneShieldHPBonus	0	11531	11532	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3323	shipBonusORECapShipDroneArmorHPBonus	0	11533	11534	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3324	shipBonusORECapShipDroneHPBonus	0	11535	11536	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3325	shipBonusORECapShipDroneArmorHPAndShieldHPBonus	0	11537	11538	shipBonusORECapShipDroneArmorHPAndShieldHPBonus		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3326	shipBonusORECapShipDroneArmorHPAndShieldHPAndHpBonus	0	11539	11540	shipBonusORECapShipDroneArmorHPAndShieldHPAndHpBonus		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3327	oreCapitalShipSkillMultiplier4	0	11543	11544	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3330	eliteBonusCommandShipArmorRepairAmount1	0	11547	11548	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3331	eliteBonusCommandShipArmorHP1	0	11549	11550	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3332	leechNpc	2	8497	8496		effects.EnergyVampire	\N	1	0	73	\N	\N	91	\N	0	0		0	0	0	0	2	None	\N	\N	\N
3333	leech2	2	131	131			\N	0	0	\N	\N	\N	\N	\N	0	1	leech	0	0	0	0	\N	None	\N	\N	\N
3334	shipArmorEmResistanceGC2	0	11554	11555	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3335	shipArmorEmResistanceMC2	0	11556	11557	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3336	shipArmorExplosiveResistanceMC2	0	11558	11559	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3337	shipArmorExplosiveResistanceGC2	0	11560	11561	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3338	shipArmorKineticResistanceGC2	0	11562	11563	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3339	shipArmorKineticResistanceMC2	0	11564	11565	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3340	shipArmorThermalResistanceMC2	0	11566	11567	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3341	shipArmorThermalResistanceGC2	0	11568	11569	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3342	eliteBonusHeavyInterdictorsHybridFalloff1	0	11570	11571	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3343	eliteBonusHeavyInterdictorsProjectileFalloff1	0	11572	11573	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3344	heavyInterdictorsSkillMultiplier1	0	11582	11583	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3345	heavyInterdictorsSkillMultiplier2	0	11586	11587	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3346	eliteBonusHeavyInterdictorLaserRof	0	11588	11589	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3347	shipShieldEmResistanceMC2	0	11590	11591	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3348	shipShieldExplosiveResistanceMC2	0	11592	11593	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3349	shipShieldKineticResistanceMC2	0	11594	11595	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3350	shipShieldThermalResistanceMC2	0	11596	11597	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3351	shipMissileAssaultMissileRofCC	0	11598	11599	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3352	shipMissileHeavyMissileRofCC	0	11600	11601	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3353	shipMissileHeavyAssaultMissileRofCC	0	11602	11603	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3355	eliteBonusHeavyInterdictorHeavyMissileVelocityBonus1	0	11606	11607	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3356	eliteBonusHeavyInterdictorHeavyAssaultMissileVelocityBonus	0	11608	11609	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3357	eliteBonusHeavyInterdictorLightMissileVelocityBonus	0	11610	11611	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3358	electronicAttackShipsSkillMultiplier1	0	11617	11618	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3359	electronicAttackShipsSkillMultiplier2	0	11621	11622	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3360	amarrShipEwWeaponDisruptionMaxRangeAF2	0	11623	11624	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3361	amarrShipEwWeaponDisruptionTrackingAF2	0	11625	11626	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3362	eliteBonusElectronicAttackShipEnergyNeutRange1	0	11627	11628	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3363	eliteBonusElectronicAttackShipEnergyVampireRange1	0	11629	11630	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3364	eliteBonusElectronicAttackShipEnergyEmissionCapNeed2	0	11631	11632	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3366	shipRemoteSensorDampenerCapNeedGF	0	11635	11636	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3367	eliteBonusElectronicAttackShipWarpScramblerMaxRange1	0	11637	11638	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3369	eliteBonusElectronicAttackShipECMOptimalRange1	0	11641	11642	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3370	eliteBonusElectronicAttackShipStasisWebMaxRange1	0	11643	11644	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3371	eliteBonusElectronicAttackShipWarpScramblerCapNeed2	0	11647	11648	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3372	eliteBonusElectronicAttackShipRocketVelocity2	0	11649	11650	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3373	eliteBonusElectronicAttackShipStandardMissileVelocity2	0	11651	11652	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3374	eliteBonusElectronicAttackShipSignatureRadius2	0	11653	11654	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3379	implantHardwiringABcapacitorNeed	0	11675	11676	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3380	warpDisruptSphere	1	131	131		effects.WarpDisruptFieldGenerating	\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3381	droneDamageBonusOnline	4	11681	11682	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3382	droneArmorHPBonusOnline	4	11683	11684	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3383	droneShieldHPBonusOnline	4	11685	11686	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3384	droneHPBonusOnline	4	11687	11688	droneHPBonusActivation		\N	0	0	\N	\N	\N	\N	\N	0	0	droneHPBonusActivation	0	0	0	0	\N	None	\N	\N	\N
3385	droneDamageAndHPBonusOnline	4	11689	11690	droneDamageAndHPActivation		\N	0	0	\N	\N	\N	\N	\N	0	0	droneDamageAndHPActivation	0	0	0	0	\N	None	\N	\N	\N
3386	cpuPenaltyToOmnipotent	0	11695	11696	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3392	eliteBonusBlackOpsLargeEnergyTurretTracking1	0	11718	11719	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3396	eliteBonusBlackOpsECMGravimetricStrengthBonus1	0	11732	11733	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3397	eliteBonusBlackOpsECMLadarStrengthBonus1	0	11734	11735	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3398	eliteBonusBlackOpsECMMagnetometricStrengthBonus1	0	11736	11737	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3399	eliteBonusBlackOpsECMRadarStrengthBonus1	0	11738	11739	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3400	eliteBonusBlackOpsDroneMWDSpeedBonus1	0	11740	11741	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3403	eliteBonusBlackOpsCloakVelocity2	0	11754	11755	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3404	blackOpsSkillMultiplier1	0	11758	11759	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3405	blackOpsSkillMultiplier2	0	11761	11762	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3406	eliteBonusBlackOpsMaxVelocity1	0	11763	11764	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3407	testTowerHPMutator	1	11771	11772	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3408	violatorsSkillMultiplier1	0	11780	11781	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3409	violatorsSkillMultiplier2	0	11784	11785	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3415	eliteBonusViolatorsLargeEnergyTurretDamageRole1	0	11804	11805	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3416	eliteBonusViolatorsLargeHybridTurretDamageRole1	0	11806	11807	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3417	eliteBonusViolatorsLargeProjectileTurretDamageRole1	0	11808	11809	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3421	shipCapNeedBonusAB2	0	11818	11819	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3423	eliteBonusViolatorsLargeEnergyTurretTracking1	0	11820	11821	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3424	eliteBonusViolatorsLargeHybridTurretTracking1	0	11822	11823	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3425	eliteBonusViolatorsLargeProjectileTurretTracking1	0	11824	11825	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3426	eliteBonusViolatorsStasisWebSpeedFactor2	0	11828	11829	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3427	eliteBonusViolatorsTractorBeamMaxRangeRole2	0	11834	11835	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3429	eliteBonusViolatorsCruiseMissileEMDamageRole1	0	11840	11841	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3430	eliteBonusViolatorsCruiseMissileThermalDamageRole1	0	11842	11843	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3431	eliteBonusViolatorsCruiseMissileKineticDamageRole1	0	11844	11845	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3432	eliteBonusViolatorsCruiseMissileExplosiveDamageRole1	0	11846	11847	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3433	eliteBonusViolatorsTorpedoExplosiveDamageRole1	0	11848	11849	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3434	eliteBonusViolatorsTorpedoKineticDamageRole1	0	11850	11851	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3435	eliteBonusViolatorsTorpedoThermalDamageRole1	0	11852	11853	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3436	eliteBonusViolatorsTorpedoEMDamageRole1	0	11854	11855	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3437	shipBonusTorpedoKineticDamageCB	0	11856	11857	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3438	shipBonusCruiseMissileKineticDamageCB	0	11858	11859	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3439	eliteBonusViolatorsEwTargetPainting1	0	11860	11861	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3440	eliteBonusViolatorsCruiseMissileAoeVelocity2	0	11862	11863	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3441	eliteBonusViolatorsTorpedoAoeVelocity2	0	11866	11867	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3447	shipBonusPTFalloffMB1	0	11881	11882	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3448	eliteBonusViolatorsArmorDamageAmount2	0	11883	11884	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3449	eliteBonusViolatorsShieldBonus2	0	11885	11886	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3450	shipBonusStasisWebSpeedFactorGB2	0	11887	11888	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3451	shipBonusStasisWebSpeedFactorAB	0	11889	11890	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3452	shipBonusAoeVelocityCruiseMissileCB2	0	11891	11892	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3453	shipBonusAoeVelocityTorpedoCB2	0	11893	11894	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3454	warpDisruptionFieldMassBonusPercentageOnline	4	11224	11225	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3455	warpDisruptionFieldAfterburnerSpeedFactorOnline	4	11895	11896	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3456	warpDisruptionFieldAfterburnerSpeedBoostFactorOnline	4	11901	11902	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3458	warpDisruptionFieldAfterburnerOnline	4	11912	11913	warpDisruptionFieldAfterburnerOnline		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3459	warpDisruptionFieldAfterburnerAndMassOnline	4	11914	11915	warpDisruptionFieldAfterburnerAndMassOnline		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3460	warpDisruptionFieldAfterburnerAndMassAndVelocityOnline	4	11916	11917	warpDisruptionFieldAfterburnerAndMassAndVelocityOnline		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3461	warpDisruptionFieldEffectOnline	4	11918	11919	warpDisruptionFieldEffectOnline		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3466	eliteBonusElectronicAttackShipRechargeRate2	0	11931	11932	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3467	eliteBonusElectronicAttackShipCapacitorCapacity2	0	11933	11934	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3468	eliteBonusHeavyInterdictorsWarpDisruptFieldGeneratorWarpScrambleRange2	0	11942	11943	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3469	testMiningTargetDurationBonus	2	11947	11948	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3470	shipBonusMWDCapNeedGC2	0	11950	11951	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3472	shipBonusMWDCapNeedMC	1	11956	11957	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3473	eliteBonusViolatorsTractorBeamMaxTractorVelocityRole3	0	11960	11961	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3476	shipBonusMWDCapNeedMF	0	11962	11963	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3477	shipBonusMWDCapNeedMB	0	11964	11965	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3478	shipLaserDamagePirateBattleship	0	11966	11967	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3479	shipRofBonusCB	0	11968	11969	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3480	shipTrackingBonusAB	0	11970	11971	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3481	shipBonusLargeEnergyTurretDamageCB2	0	11972	11973	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3482	warpDisruptFieldGeneratorCpuBonus	0	11976	11977	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3483	shipBonusMediumEnergyTurretDamagePirateFaction	0	11978	11979	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3484	shipBonusMediumEnergyTurretTrackingAC2	0	4376	4377	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3485	shipBonusMediumEnergyTurretDamageCC2	0	11980	11981	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3486	shipBonusSmallEnergyTurretDamageCF2	0	11982	11983	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3487	shipBonusSmallEnergyTurretDamagePirateFaction	0	5241	5242	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3489	shipBonusSmallEnergyTurretTracking2AF	0	11986	11987	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3491	rorqualSpeedFactorIndustrialCore	1	11990	11991	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3492	industrialCoreEffect	1	11992	11993		effects.SiegeMode	\N	0	0	73	\N	6	\N	\N	0	0	rorqualIndustrialCoreSitDownAndCommandBonus	0	0	0	0	\N	None	\N	\N	\N
3493	rorqualCargoScanRangeBonus	0	11405	11406	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3494	rorqualSurveyScannerRangeBonus	0	11401	11402	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3495	shipCapPropulsionJamming	0	11996	11997	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3496	setBonusThukker	0	12003	12004	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3498	setBonusSisters	0	12019	12020	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3499	setBonusSyndicate	0	12025	12026	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3500	miningLaserMaxRangeBonus	0	12029	12030	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3501	stripMinerMaxRangeBonus	0	12035	12036	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3507	frequencyMiningLaserMaxRangeBonus	0	12052	12053	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3508	gasHarvesterMaxRangeBonus	0	12054	12055	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3509	miningLaserAndFrequencyMiningLaserMaxRangeBonus	0	12056	12057			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3510	miningLaserAndFrequencyMiningLaserAndStripMinerMaxRangeBonus	0	12058	12059			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3511	miningLaserAndFrequencyMiningLaserAndStripMinerAndGasHarvesterMaxRangeBonus	0	12060	12061			\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3513	setBonusMordus	0	12070	12071	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3514	Interceptor2WarpScrambleRange	0	12072	12073	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3519	weaponUpgradesCpuNeedBonusPostPercentCpuLocationShipModulesRequiringBombLauncher	0	12078	12079	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3520	skillAdvancedWeaponUpgradesPowerNeedBonusBombLaunchers	0	12093	12094	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3521	skillNaniteOperationRepairCost	0	12099	12100	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3522	skillNaniteOperationRepairCostLevel	0	12103	12104	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3523	skillNaniteInterfacingRepairTime	0	12109	12110	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3524	skillNaniteInterfacingRepairTimeLevel	0	12113	12114	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3526	cynosuralTheoryConsumptionBonus	0	12122	12123	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3527	skillConsumptionQuantityBonusPercentageSkillLevel	0	12126	12127	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3528	drawbackCapacitorRecharge	0	12129	12130	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3529	testMiningLaserTargetVeldsparDurationBonus	2	12135	12136	Automatically generated effect	None	0	0	0	73	\N	6	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3530	eliteBonusBlackOpsAgiliy1	0	12145	12146	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3531	covertCynosuralFieldGeneratorCpuNeedBonus	0	12151	12152	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3532	skillJumpDriveConsumptionAmountBonusPercentage	0	12154	12155	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3537	scriptTrackingMaxRangeMultiplier	0	12175	12176	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3538	scriptTrackingTrackingSpeedMultiplier	0	12177	12178	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3539	scriptSensorBoosterMaxTargetRangeMultiplierBonusAdditive	0	12183	12184	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3540	scriptSensorBoosterScanResolutionMultiplierBonusAdditive	0	12186	12187	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3541	targetEnergyWeaponMaxRangeBonusHostile	2	12191	12192	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3542	targetEnergyWeaponTrackingSpeedBonusHostile	2	12195	12196	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3543	targetHybridWeaponTrackingSpeedBonusHostile	2	12200	12201	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3544	targetHybridWeaponMaxRangeBonusHostile	2	12204	12205	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3545	targetProjectileWeaponMaxRangeBonusHostile	2	12209	12210	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3546	targetProjectileWeaponTrackingSpeedBonusHostile	2	12213	12214	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3547	targetProjectileWeaponMaxRangeAndTrackingSpeedBonusHostile	2	12215	12216	targetProjectileWeaponMaxRangeAndTrackingSpeedBonusHostile		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3548	targetHybridWeaponMaxRangeAndTrackingSpeedBonusHostile	2	12217	12218	targetHybridWeaponMaxRangeAndTrackingSpeedBonusHostile		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3549	targetEnergyWeaponMaxRangeAndTrackingSpeedBonusHostile	2	12219	12220	targetEnergyWeaponMaxRangeAndTrackingSpeedBonusHostile		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3550	targetEnergyWeaponAndHybridWeaponMaxRangeAndTrackingSpeedBonusHostile	2	12221	12222	targetEnergyWeaponAndHybridWeaponMaxRangeAndTrackingSpeedBonusHostile		\N	1	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3552	targetTurretWeaponMaxRangeAndTrackingSpeedBonusHostile	2	12223	12224	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration. Both modifiers are percentage based.	effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	None	\N	\N	\N
3553	targetGunneryMaxRangeBonusHostile	2	12228	12229	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3554	targetGunneryTrackingSpeedBonusHostile	2	12232	12233	Automatically generated effect	None	0	1	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3555	targetGunneryMaxRangeAndTrackingSpeedBonusHostile	2	12234	12235	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration. Both modifiers are percentage based.	effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	None	\N	\N	\N
3556	targetGunneryMaxRangeAndTrackingSpeedBonusAssistance	2	12234	12235	Modifies maximum turret weapon range and tracking speed on the active target for the length of the duration. Both modifiers are percentage based.	effects.TurretWeaponRangeTrackingSpeedMultiplyTarget	\N	0	1	73	\N	6	54	158	0	0		0	1	0	0	1	None	\N	\N	\N
3557	gunneryMaxRangeBonus	1	12236	12237	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3558	gunneryTrackingSpeedBonus	1	12240	12241	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3559	gunneryMaxRangeAndTrackingSpeedBonus	1	12242	12243	Modifies maximum turret weapon range and tracking speed for the length of the duration.	effects.TurretWeaponRangeTrackingSpeedMultiplyActivate	\N	0	0	73	\N	6	\N	\N	0	0		1	0	0	0	\N	None	\N	\N	\N
3560	ewSkillTrackingDisruptionMaxRangeBonus	0	12246	12247	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3561	ewSkillTrackingDisruptionTrackingSpeedBonus	0	12250	12251	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3562	shipBonusEwWeaponDisruptionMaxRangeBonusAC1	0	12252	12253	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3563	shipBonusEwWeaponDisruptionMaxRangeBonusAF2	0	12254	12255	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3564	shipBonusEwWeaponDisruptionMaxRangeBonusAF1	0	12256	12257	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3565	shipBonusEwWeaponDisruptionTrackingSpeedBonusAF1	0	12258	12259	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3566	shipBonusEwWeaponDisruptionTrackingSpeedBonusAF2	0	12260	12261	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3567	shipBonusEwWeaponDisruptionTrackingSpeedBonusAC1	0	12262	12263	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3568	eliteBonusLogisticsTrackingLinkMaxRangeBonus1	0	12266	12267	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3569	eliteBonusLogisticsTrackingLinkMaxRangeBonus2	0	12268	12269	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3570	eliteBonusLogisticsTrackingLinkTrackingSpeedBonus2	0	12272	12273	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3571	eliteBonusLogisticsTrackingLinkTrackingSpeedBonus1	0	12274	12275	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3572	shipBonusTrackingLinkTrackingSpeedBonusMC1	0	12276	12277	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3573	shipBonusTrackingLinkMaxRangeBonusMC1	0	12278	12279	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3574	sensorBoosterMaxTargetRangeBonusActive	1	9627	9628	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3575	sensorBoosterScanResolutionBonusActive	1	3427	3428	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3577	targetScanResolutionRangeBonusAssistance	2	3427	3428	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3580	targetScanResolutionBonusAssistance	2	12281	12282	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3582	targetMaxTargetRangeBonusAssistance	2	12283	12284	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3583	targetMaxTargetRangeAndScanResolutionBonusAssistance	2	12285	12286	targetMaxTargetRangeAndScanResolutionBonusAssistance	effects.ElectronicAttributeModifyTarget	\N	0	1	73	\N	6	54	158	0	0		0	1	0	0	1	None	\N	\N	\N
3584	targetMaxTargetRangeAndScanResolutionBonusHostile	2	12285	12286	targetMaxTargetRangeAndScanResolutionBonusHostile	effects.ElectronicAttributeModifyTarget	\N	1	0	73	\N	6	54	158	0	0		0	1	0	0	1	None	\N	\N	\N
3586	ewSkillSignalSuppressionScanResolutionBonus	0	12293	12294	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3587	shipBonusEwRemoteSensorDampenerMaxTargetRangeBonusGC2	0	12297	12298	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3588	shipBonusEwRemoteSensorDampenerMaxTargetRangeBonusGF2	0	12299	12300	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3589	shipBonusEwRemoteSensorDampenerScanResolutionBonusGF2	0	12301	12302	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3590	shipBonusEwRemoteSensorDampenerScanResolutionBonusGC2	0	12303	12304	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3591	ewSkillSignalSuppressionMaxTargetRangeBonus	0	12305	12306	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3592	eliteBonusJumpFreighterHullHP1	0	12311	12312	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3593	eliteBonusJumpFreighterJumpDriveConsumptionAmount2	0	12313	12314	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3595	jumpFreightersSkillMultiplier1	0	12321	12322	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3596	jumpFreightersSkillMultiplier2	0	12325	12326	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3597	scriptSensorBoosterScanResolutionBonusBonus	0	12333	12334	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3598	scriptSensorBoosterMaxTargetRangeBonusBonus	0	12336	12337	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3599	scriptTrackingComputerTrackingSpeedBonusBonus	0	12340	12341	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3600	scriptTrackingComputerMaxRangeBonusBonus	0	12344	12345	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3601	scriptWarpDisruptionFieldGeneratorSetDisallowInEmpireSpace	0	12348	12349	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3602	scriptDurationBonus	0	12352	12353	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3603	eliteBonusHeavyInterdictorsWarpDisruptFieldGeneratorWarpScrambleRangeScript2	0	12360	12361	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3604	targetSetWarpScrambleStatusHidden	2	12365	12366	Sets the warpScrambleStatus of the target using hidden attributes.	effects.WarpScramble	0	1	0	73	\N	1319	1317	\N	0	0	jumpScramble	0	0	0	0	1	None	\N	\N	\N
3607	commandMultiplierInformationWarfareSpecialistHidden	0	12379	12380	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3608	squadronCommandHidden	0	12383	12384	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3609	informationWarfareMindlinkHidden	0	12386	12387	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3611	commandBonusECMMultiplyWithCommandBonusHidden	0	12397	12398	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3612	commandBonusRSDMultiplyWithCommandBonusHidden	0	12401	12402	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3613	commandBonusTDMultiplyWithCommandBonusHidden	0	12405	12406	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3614	commandBonusTPMultiplyWithCommandBonusHidden	0	12409	12410	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3615	scriptWarpDisruptionFieldGeneratorSetScriptCapacitorNeedHidden	0	12412	12413	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3617	scriptSignatureRadiusBonusBonus	0	12420	12421	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3618	scriptMassBonusPercentageBonus	0	12426	12427	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3619	scriptSpeedBoostFactorBonusBonus	0	12432	12433	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3620	scriptSpeedFactorBonusBonus	0	12438	12439	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3621	eliteBonusCommandShipInfoHiddenCS2	0	12440	12441	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3629	gangInformationWarfareSuperiorityRSDScanResolutionBonus	1	12466	12467	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3630	gangInformationWarfareSuperiorityRSDMaxTargetRangeBonus	1	12470	12471	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3631	gangInformationWarfareSuperiorityRSD	1	12472	12473	gangInformationWarfareSuperiorityRSD		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3632	gangInformationWarfareSuperiorityTDMaxRangeBonus	1	12476	12477	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3633	gangInformationWarfareSuperiorityTDTrackingSpeedBonus	1	12480	12481	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3634	gangInformationWarfareSuperiorityTD	1	12482	12483	gangInformationWarfareSuperiorityTD		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3635	gangInformationWarfareSuperiorityTP	1	12484	12485	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3637	gangInformationWarfareSuperiorityTDAndTP	1	12488	12489	gangInformationWarfareSuperiorityTDAndTP		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3639	gangInformationWarfareSuperiorityECMGravimetric	1	12492	12493	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3640	gangInformationWarfareSuperiorityECMLadar	1	12494	12495	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3641	gangInformationWarfareSuperiorityECMMagnetometric	1	12496	12497	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3642	gangInformationWarfareSuperiorityECMRadar	1	12498	12499	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3643	gangInformationWarfareSuperiorityECMGravimetricAndLadar	1	12500	12501	gangInformationWarfareSuperiorityECMGravimetricAndLadar		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3644	gangInformationWarfareSuperiorityECMMagnetometricAndRadar	1	12502	12503	gangInformationWarfareSuperiorityECMMagnetometricAndRadar		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3645	gangInformationWarfareSuperiorityECM	1	12504	12505	gangInformationWarfareSuperiorityECM		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3646	gangInformationWarfareSuperiorityECMAndRSD	1	12506	12507	gangInformationWarfareSuperiorityECMAndRSD		\N	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3647	gangInformationWarfareSuperiority	1	12508	12509	gangInformationWarfareSuperiority		\N	0	0	73	\N	6	\N	\N	0	0		0	0	0	0	0	None	\N	\N	\N
3648	scriptWarpScrambleRangeBonus	0	12514	12515	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3649	eliteBonusViolatorsLargeEnergyTurretDamage1	0	12516	12517	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3650	ewGroupRsdMaxRangeBonus	0	12520	12521	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3651	ewGroupTpMaxRangeBonus	0	12524	12525	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3652	ewGroupTdMaxRangeBonus	0	12528	12529	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3653	ewGroupEcmBurstMaxRangeBonus	0	12532	12533	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3654	setBonusOre	0	12536	12537	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3655	gunneryMaxRangeBonusOnline	4	12236	12237	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3656	gunneryTrackingSpeedBonusOnline	4	12240	12241	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3657	shipScanResolutionBonusOnline	4	3427	3428	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3659	shipMaxTargetRangeBonusOnline	4	9627	9628	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3660	shipMaxLockedTargetsBonusAddOnline	4	798	800	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3661	targetDroneBandwidthMultiplier	2	12542	12543	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
3662	scanRadarStrengthBonusScannerProbeGroup	0	12548	12549	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3663	scanLadarStrengthBonusScannerProbeGroup	0	12552	12553	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3664	scanGravimetricStrengthBonusScannerProbeGroup	0	12556	12557	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3665	scanMagnetometricStrengthBonusScannerProbeGroup	0	12560	12561	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0		0	0	0	0	\N	None	\N	\N	\N
3666	testColinScanner	0	12562	12563	Automatically generated effect	None	0	0	0	\N	\N	\N	\N	\N	0	0	None	0	0	0	0	\N	None	\N	\N	\N
\.


--
-- Name: dgmEffects dgmEffects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."dgmEffects"
    ADD CONSTRAINT "dgmEffects_pkey" PRIMARY KEY ("effectID");


--
-- PostgreSQL database dump complete
--

\unrestrict 8T27MLJ1whzAut7mz2Rv8cDI7D2rsKiLYPblSDXm4A0uYCczYebx51UwVYuUbY2

