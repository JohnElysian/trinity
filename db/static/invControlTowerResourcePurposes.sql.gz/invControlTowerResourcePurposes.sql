--
-- PostgreSQL database dump
--

\restrict U025CLglpvMbI8C1JtlurnWefnacTcdcs60rOWf0Hh8F95U6NBSaqI5ZPrz8hMd

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invControlTowerResourcePurposes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invControlTowerResourcePurposes" (
    purpose integer NOT NULL,
    "purposeText" text
);


--
-- Data for Name: invControlTowerResourcePurposes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invControlTowerResourcePurposes" (purpose, "purposeText") FROM stdin;
1	Online
2	Power
3	CPU
4	Reinforce
\.


--
-- Name: invControlTowerResourcePurposes invControlTowerResourcePurposes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invControlTowerResourcePurposes"
    ADD CONSTRAINT "invControlTowerResourcePurposes_pkey" PRIMARY KEY (purpose);


--
-- PostgreSQL database dump complete
--

\unrestrict U025CLglpvMbI8C1JtlurnWefnacTcdcs60rOWf0Hh8F95U6NBSaqI5ZPrz8hMd

