-- agtOfferDetails: Trinity 1.0 static data (tools/trinity_static.py)
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

CREATE TABLE public."agtOfferDetails" (
    "contentID" integer,
    "loyaltyPointCost" integer,
    "agentTypeID1" integer,
    "agentQuantity1" integer,
    "agentTypeID2" integer,
    "agentQuantity2" integer,
    "agentTypeID3" integer,
    "agentQuantity3" integer,
    "agentTypeID4" integer,
    "agentQuantity4" integer,
    "agentTypeID5" integer,
    "agentQuantity5" integer,
    "charTypeID1" integer,
    "charQuantity1" integer,
    "charTypeID2" integer,
    "charQuantity2" integer,
    "charTypeID3" integer,
    "charQuantity3" integer,
    "charTypeID4" integer,
    "charQuantity4" integer,
    "charTypeID5" integer,
    "charQuantity5" integer,
    "contentName" text
);

COPY public."agtOfferDetails" ("contentID", "loyaltyPointCost", "agentTypeID1", "agentQuantity1", "agentTypeID2", "agentQuantity2", "agentTypeID3", "agentQuantity3", "agentTypeID4", "agentQuantity4", "agentTypeID5", "agentQuantity5", "charTypeID1", "charQuantity1", "charTypeID2", "charQuantity2", "charTypeID3", "charQuantity3", "charTypeID4", "charQuantity4", "charTypeID5", "charQuantity5", "contentName") FROM stdin;
4676	1000000	28746	1	\N	\N	\N	\N	\N	\N	\N	\N	3829	1	\N	\N	\N	\N	\N	\N	\N	\N	Duplicate Offer
3837	800000	17738	1	\N	\N	\N	\N	\N	\N	\N	\N	29	80000000	\N	\N	\N	\N	\N	\N	\N	\N	Machariel
3887	800000	17920	1	\N	\N	\N	\N	\N	\N	\N	\N	29	80000000	\N	\N	\N	\N	\N	\N	\N	\N	Bhaalgorn
3937	800000	17918	1	\N	\N	\N	\N	\N	\N	\N	\N	29	80000000	\N	\N	\N	\N	\N	\N	\N	\N	Rattlesnake
4007	800000	17736	1	\N	\N	\N	\N	\N	\N	\N	\N	29	80000000	\N	\N	\N	\N	\N	\N	\N	\N	Nightmare
4054	800000	17740	1	\N	\N	\N	\N	\N	\N	\N	\N	29	80000000	\N	\N	\N	\N	\N	\N	\N	\N	Vindicator
3441	600000	17726	1	\N	\N	\N	\N	\N	\N	\N	\N	642	1	17793	1	\N	\N	\N	\N	\N	\N	Apocalypse Navy Issue
3521	600000	17636	1	\N	\N	\N	\N	\N	\N	\N	\N	638	1	17643	1	\N	\N	\N	\N	\N	\N	Raven Navy Issue
3615	600000	17728	1	\N	\N	\N	\N	\N	\N	\N	\N	641	1	17850	1	\N	\N	\N	\N	\N	\N	Megathron Navy Issue
3697	600000	17732	1	\N	\N	\N	\N	\N	\N	\N	\N	639	1	17814	1	\N	\N	\N	\N	\N	\N	Tempest Fleet Issue
4294	500000	17727	1	\N	\N	\N	\N	\N	\N	\N	\N	29	200000000	\N	\N	\N	\N	\N	\N	\N	\N	Apocalypse Navy Issue Blueprint
4295	500000	17727	1	\N	\N	\N	\N	\N	\N	\N	\N	18679	1	17260	1	17211	1	12550	5	12551	10	Apocalypse Navy Issue Blueprint
4317	500000	17637	1	\N	\N	\N	\N	\N	\N	\N	\N	29	200000000	\N	\N	\N	\N	\N	\N	\N	\N	Raven Navy Issue Blueprint
4318	500000	17637	1	\N	\N	\N	\N	\N	\N	\N	\N	17295	1	17639	1	17244	1	17206	10	12545	10	Raven Navy Issue Blueprint
4339	500000	17729	1	\N	\N	\N	\N	\N	\N	\N	\N	29	200000000	\N	\N	\N	\N	\N	\N	\N	\N	Megathron Navy Issue Blueprint
4340	500000	17729	1	\N	\N	\N	\N	\N	\N	\N	\N	17291	1	17216	2	17267	1	17271	1	\N	\N	Megathron Navy Issue Blueprint
4357	500000	17733	1	\N	\N	\N	\N	\N	\N	\N	\N	29	200000000	\N	\N	\N	\N	\N	\N	\N	\N	Tempest Fleet Issue Blueprint
4358	500000	17733	1	\N	\N	\N	\N	\N	\N	\N	\N	17305	1	17192	5	15645	1	17196	5	\N	\N	Tempest Fleet Issue Blueprint
4382	400000	17739	1	\N	\N	\N	\N	\N	\N	\N	\N	29	100000000	\N	\N	\N	\N	\N	\N	\N	\N	Machariel Blueprint
4385	400000	17921	1	\N	\N	\N	\N	\N	\N	\N	\N	29	100000000	\N	\N	\N	\N	\N	\N	\N	\N	Bhaalgorn Blueprint
4388	400000	17919	1	\N	\N	\N	\N	\N	\N	\N	\N	29	100000000	\N	\N	\N	\N	\N	\N	\N	\N	Rattlesnake Blueprint
4391	400000	17737	1	\N	\N	\N	\N	\N	\N	\N	\N	29	100000000	\N	\N	\N	\N	\N	\N	\N	\N	Nightmare Blueprint
4394	400000	17741	1	\N	\N	\N	\N	\N	\N	\N	\N	29	100000000	\N	\N	\N	\N	\N	\N	\N	\N	Vindicator Blueprint
4759	321300	28795	1	\N	\N	\N	\N	\N	\N	\N	\N	13233	1	29	214200000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Omega
4765	321300	28819	1	\N	\N	\N	\N	\N	\N	\N	\N	25545	1	29	214200000	\N	\N	\N	\N	\N	\N	Low-grade Edge Omega
4771	321300	28807	1	\N	\N	\N	\N	\N	\N	\N	\N	22534	1	29	214200000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Omega
4777	321300	28801	1	\N	\N	\N	\N	\N	\N	\N	\N	13240	1	29	214200000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Omega
4783	321300	28813	1	\N	\N	\N	\N	\N	\N	\N	\N	27187	1	29	214200000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Omega
4019	267750	20509	1	\N	\N	\N	\N	\N	\N	\N	\N	19550	1	29	267750000	\N	\N	\N	\N	\N	\N	Slave Omega
4066	267750	19556	1	\N	\N	\N	\N	\N	\N	\N	\N	16003	1	29	267750000	\N	\N	\N	\N	\N	\N	Snake Omega
3943	267750	20161	1	\N	\N	\N	\N	\N	\N	\N	\N	16248	1	29	267750000	\N	\N	\N	\N	\N	\N	Crystal Omega
3899	267750	19539	1	\N	\N	\N	\N	\N	\N	\N	\N	27121	1	29	267750000	\N	\N	\N	\N	\N	\N	Talisman Omega
3843	267750	20508	1	\N	\N	\N	\N	\N	\N	\N	\N	27130	1	29	267750000	\N	\N	\N	\N	\N	\N	Halo Omega
3836	240000	17720	1	\N	\N	\N	\N	\N	\N	\N	\N	29	15000000	\N	\N	\N	\N	\N	\N	\N	\N	Cynabal
3696	240000	17713	1	\N	\N	\N	\N	\N	\N	\N	\N	622	1	17816	1	\N	\N	\N	\N	\N	\N	Stabber Fleet Issue
3886	240000	17922	1	\N	\N	\N	\N	\N	\N	\N	\N	29	15000000	\N	\N	\N	\N	\N	\N	\N	\N	Ashimmu
3936	240000	17715	1	\N	\N	\N	\N	\N	\N	\N	\N	29	15000000	\N	\N	\N	\N	\N	\N	\N	\N	Gila
3614	240000	17843	1	\N	\N	\N	\N	\N	\N	\N	\N	626	1	17849	1	\N	\N	\N	\N	\N	\N	Vexor Navy Issue
3520	240000	17634	1	\N	\N	\N	\N	\N	\N	\N	\N	621	1	17646	1	\N	\N	\N	\N	\N	\N	Caracal Navy Issue
3440	240000	17709	1	\N	\N	\N	\N	\N	\N	\N	\N	625	1	17794	1	\N	\N	\N	\N	\N	\N	Augoror Navy Issue
4006	240000	17718	1	\N	\N	\N	\N	\N	\N	\N	\N	29	15000000	\N	\N	\N	\N	\N	\N	\N	\N	Phantasm
4053	240000	17722	1	\N	\N	\N	\N	\N	\N	\N	\N	29	15000000	\N	\N	\N	\N	\N	\N	\N	\N	Vigilant
4572	240000	15892	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15613	128	15614	211	\N	\N	\N	\N	Republic Fleet Warp Disruptor Blueprint
4573	240000	15894	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15613	128	15614	211	\N	\N	\N	\N	Republic Fleet Warp Scrambler Blueprint
4561	180000	15756	5	\N	\N	\N	\N	\N	\N	\N	\N	29	72000000	15614	15	15615	66	15669	98	\N	\N	Republic Fleet 100MN MicroWarpdrive Blueprint
3542	180000	17498	1	\N	\N	\N	\N	\N	\N	\N	\N	578	1	29	72000000	15593	15	15594	66	15673	98	Caldari Navy Invulnerability Field
4775	170100	28799	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	113400000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Epsilon
4781	170100	28811	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	113400000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Epsilon
4769	170100	28805	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	113400000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Epsilon
4763	170100	28817	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	113400000	\N	\N	\N	\N	\N	\N	Low-grade Edge Epsilon
4758	170100	28793	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	113400000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Epsilon
4379	168750	15948	5	\N	\N	\N	\N	\N	\N	\N	\N	29	67500000	15631	12	15632	62	15661	92	\N	\N	Ammatar Navy Large EMP Smartbomb Blueprint
4360	168750	15940	5	\N	\N	\N	\N	\N	\N	\N	\N	29	67500000	15614	12	15615	62	15669	92	\N	\N	Republic Fleet Large Proton Smartbomb Blueprint
4343	168750	15956	5	\N	\N	\N	\N	\N	\N	\N	\N	29	67500000	15656	12	15605	62	15604	92	\N	\N	Gallente Navy Large Plasma Smartbomb Blueprint
4323	168750	15932	5	\N	\N	\N	\N	\N	\N	\N	\N	29	67500000	15593	12	15594	62	15673	92	\N	\N	Caldari Navy Large Graviton Smartbomb Blueprint
4298	168750	15964	5	\N	\N	\N	\N	\N	\N	\N	\N	29	67500000	15631	12	15632	62	15661	92	\N	\N	Amarr Navy Large EMP Smartbomb Blueprint
4546	151875	15906	5	\N	\N	\N	\N	\N	\N	\N	\N	29	60750000	15593	13	15594	55	15673	83	\N	\N	Caldari Navy Shield Boost Amplifier Blueprint
4293	150000	17710	1	\N	\N	\N	\N	\N	\N	\N	\N	18657	1	16189	1	16183	5	15981	5	16181	5	Augoror Navy Issue Blueprint
4297	150000	15886	5	\N	\N	\N	\N	\N	\N	\N	\N	29	60000000	15631	10	15632	55	15661	82	\N	\N	Amarr Navy Heavy Nosferatu Blueprint
4316	150000	17635	1	\N	\N	\N	\N	\N	\N	\N	\N	17630	1	17251	1	12542	30	12543	20	17209	20	Caracal Navy Issue Blueprint
4338	150000	17844	1	\N	\N	\N	\N	\N	\N	\N	\N	17293	1	17270	1	17217	10	12539	5	17218	8	Vexor Navy Issue Blueprint
4356	150000	17714	1	\N	\N	\N	\N	\N	\N	\N	\N	17817	1	15641	1	15623	30	15672	30	16001	30	Stabber Fleet Issue Blueprint
4373	150000	15880	5	\N	\N	\N	\N	\N	\N	\N	\N	29	60000000	15631	10	15632	55	15661	82	\N	\N	Ammatar Navy Heavy Nosferatu Blueprint
4563	144000	15752	5	\N	\N	\N	\N	\N	\N	\N	\N	29	57600000	15613	381	15614	635	\N	\N	\N	\N	Republic Fleet 10MN MicroWarpdrive Blueprint
4017	141750	20505	1	\N	\N	\N	\N	\N	\N	\N	\N	9956	1	29	141750000	\N	\N	\N	\N	\N	\N	Slave Epsilon
4064	141750	19555	1	\N	\N	\N	\N	\N	\N	\N	\N	9956	1	29	141750000	\N	\N	\N	\N	\N	\N	Snake Epsilon
3941	141750	20160	1	\N	\N	\N	\N	\N	\N	\N	\N	9956	1	29	141750000	\N	\N	\N	\N	\N	\N	Crystal Epsilon
3897	141750	19538	1	\N	\N	\N	\N	\N	\N	\N	\N	9956	1	29	141750000	\N	\N	\N	\N	\N	\N	Talisman Epsilon
3841	141750	20504	1	\N	\N	\N	\N	\N	\N	\N	\N	9956	1	29	141750000	\N	\N	\N	\N	\N	\N	Halo Epsilon
4551	135000	15769	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15656	10	15605	49	15604	74	\N	\N	Gallente Navy 100MN MicroWarpdrive Blueprint
4446	135000	15682	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15593	10	15594	49	15673	74	\N	\N	Caldari Navy Ballistic Control System Blueprint
4447	135000	15676	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15592	358	15593	595	\N	\N	\N	\N	Caldari Navy Co-Processor Blueprint
4376	135000	15799	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15631	10	15632	49	15661	74	\N	\N	Ammatar Navy Heavy Energy Neutralizer Blueprint
4378	135000	15946	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15630	358	15631	595	\N	\N	\N	\N	Ammatar Navy Medium EMP Smartbomb Blueprint
4361	135000	15938	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15613	358	15614	595	\N	\N	\N	\N	Republic Fleet Medium Proton Smartbomb Blueprint
4344	135000	15954	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15602	358	15656	595	\N	\N	\N	\N	Gallente Navy Medium Plasma Smartbomb Blueprint
4324	135000	15930	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15592	358	15593	595	\N	\N	\N	\N	Caldari Navy Medium Graviton Smartbomb Blueprint
4299	135000	15962	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15630	358	15631	595	\N	\N	\N	\N	Amarr Navy Medium EMP Smartbomb Blueprint
4570	135000	15908	5	\N	\N	\N	\N	\N	\N	\N	\N	29	54000000	15614	10	15615	49	15669	74	\N	\N	Republic Fleet Shield Boost Amplifier Blueprint
4301	120000	15884	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15630	318	15631	529	\N	\N	\N	\N	Amarr Navy Medium Nosferatu Blueprint
4296	120000	15805	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15631	10	15632	43	15661	66	\N	\N	Amarr Navy Heavy Energy Neutralizer Blueprint
4372	120000	15878	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15630	318	15631	529	\N	\N	\N	\N	Ammatar Navy Medium Nosferatu Blueprint
4456	120000	15678	5	\N	\N	\N	\N	\N	\N	\N	\N	29	48000000	15602	318	15656	529	\N	\N	\N	\N	Gallente Navy Co-Processor Blueprint
4565	108000	15748	5	\N	\N	\N	\N	\N	\N	\N	\N	29	43200000	15610	538	15992	673	16000	808	\N	\N	Republic Fleet 1MN MicroWarpdrive Blueprint
4553	108000	15765	5	\N	\N	\N	\N	\N	\N	\N	\N	29	43200000	15602	285	15656	477	\N	\N	\N	\N	Gallente Navy 10MN MicroWarpdrive Blueprint
4375	108000	15797	5	\N	\N	\N	\N	\N	\N	\N	\N	29	43200000	15630	285	15631	477	\N	\N	\N	\N	Ammatar Navy Medium Energy Neutralizer Blueprint
4377	101250	15942	5	\N	\N	\N	\N	\N	\N	\N	\N	29	40500000	15628	504	15629	631	15660	758	\N	\N	Ammatar Navy Small EMP Smartbomb Blueprint
4363	101250	15936	5	\N	\N	\N	\N	\N	\N	\N	\N	29	40500000	15610	504	15992	631	16000	758	\N	\N	Republic Fleet Small Proton Smartbomb Blueprint
4303	101250	15958	5	\N	\N	\N	\N	\N	\N	\N	\N	29	40500000	15628	504	15629	631	15660	758	\N	\N	Amarr Navy Small EMP Smartbomb Blueprint
4327	101250	15926	5	\N	\N	\N	\N	\N	\N	\N	\N	29	40500000	15590	504	15994	631	16002	758	\N	\N	Caldari Navy Small Graviton Smartbomb Blueprint
4345	101250	15950	5	\N	\N	\N	\N	\N	\N	\N	\N	29	40500000	15599	504	15600	631	15601	758	\N	\N	Gallente Navy Small Plasma Smartbomb Blueprint
4337	100000	17844	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Vexor Navy Issue Blueprint
4315	100000	17635	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Caracal Navy Issue Blueprint
4292	100000	17710	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Augoror Navy Issue Blueprint
4355	100000	17714	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Stabber Fleet Issue Blueprint
4300	96000	15803	5	\N	\N	\N	\N	\N	\N	\N	\N	29	38400000	15630	255	15631	423	\N	\N	\N	\N	Amarr Navy Medium Energy Neutralizer Blueprint
4757	94500	28792	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	63000000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Delta
4762	94500	28816	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	63000000	\N	\N	\N	\N	\N	\N	Low-grade Edge Delta
4768	94500	28804	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	63000000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Delta
4774	94500	28798	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	63000000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Delta
4780	94500	28810	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	63000000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Delta
4305	90000	15882	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15628	448	15629	562	15660	673	\N	\N	Amarr Navy Small Nosferatu Blueprint
4320	90000	15819	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15593	7	15594	33	15673	49	\N	\N	Caldari Navy 350mm Railgun Blueprint
4322	90000	16063	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15593	7	15594	33	15673	49	\N	\N	Caldari Navy Cruise Missile Launcher Blueprint
4342	90000	15839	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15656	7	15605	33	15604	49	\N	\N	Gallente Navy 350mm Railgun Blueprint
4371	90000	15876	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15628	448	15629	562	15660	673	\N	\N	Ammatar Navy Small Nosferatu Blueprint
4438	90000	15811	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15631	7	15632	33	15661	49	\N	\N	Amarr Navy Heat Sink Blueprint
4462	90000	15896	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15656	7	15605	33	15604	49	\N	\N	Gallente Navy Magnetic Field Stabilizer Blueprint
4476	90000	15807	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15614	7	15615	33	15669	49	\N	\N	Republic Fleet Gyrostabilizer Blueprint
4494	90000	15809	5	\N	\N	\N	\N	\N	\N	\N	\N	29	36000000	15631	7	15632	33	15661	49	\N	\N	Ammatar Navy Heat Sink Blueprint
4013	85000	22124	1	\N	\N	\N	\N	\N	\N	\N	\N	13256	1	29	85000000	\N	\N	\N	\N	\N	\N	Low-grade Slave Omega
4060	85000	22130	1	\N	\N	\N	\N	\N	\N	\N	\N	13237	1	29	85000000	\N	\N	\N	\N	\N	\N	Low-grade Snake Omega
3849	85000	22118	1	\N	\N	\N	\N	\N	\N	\N	\N	10244	1	29	85000000	\N	\N	\N	\N	\N	\N	Low-grade Halo Omega
3893	85000	22137	1	\N	\N	\N	\N	\N	\N	\N	\N	13265	1	29	85000000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Omega
3949	85000	22112	1	\N	\N	\N	\N	\N	\N	\N	\N	13263	1	29	85000000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Omega
4374	81000	15795	5	\N	\N	\N	\N	\N	\N	\N	\N	29	32400000	15628	403	15629	504	15660	607	\N	\N	Ammatar Navy Small Energy Neutralizer Blueprint
4381	80000	17721	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Cynabal Blueprint
4384	80000	17923	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Ashimmu Blueprint
4387	80000	17716	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Gila Blueprint
4390	80000	17719	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Phantasm Blueprint
4393	80000	17723	1	\N	\N	\N	\N	\N	\N	\N	\N	29	20000000	\N	\N	\N	\N	\N	\N	\N	\N	Vigilant Blueprint
4052	80000	17928	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5000000	\N	\N	\N	\N	\N	\N	\N	\N	Daredevil
4005	80000	17924	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5000000	\N	\N	\N	\N	\N	\N	\N	\N	Succubus
3935	80000	17930	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5000000	\N	\N	\N	\N	\N	\N	\N	\N	Worm
3885	80000	17926	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5000000	\N	\N	\N	\N	\N	\N	\N	\N	Cruor
3835	80000	17932	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5000000	\N	\N	\N	\N	\N	\N	\N	\N	Dramiel
3754	80000	15891	1	\N	\N	\N	\N	\N	\N	\N	\N	3242	1	29	32000000	15613	43	15614	70	\N	\N	Republic Fleet Warp Disruptor
3755	80000	15893	1	\N	\N	\N	\N	\N	\N	\N	\N	447	1	29	32000000	15613	43	15614	70	\N	\N	Republic Fleet Warp Scrambler
3519	80000	17619	1	\N	\N	\N	\N	\N	\N	\N	\N	603	1	17647	1	\N	\N	\N	\N	\N	\N	Caldari Navy Hookbill
3439	80000	17703	1	\N	\N	\N	\N	\N	\N	\N	\N	597	1	17795	1	\N	\N	\N	\N	\N	\N	Amarr Navy Slicer
3695	80000	17812	1	\N	\N	\N	\N	\N	\N	\N	\N	587	1	17815	1	\N	\N	\N	\N	\N	\N	Republic Fleet Firetail
3613	80000	17841	1	\N	\N	\N	\N	\N	\N	\N	\N	593	1	17848	1	\N	\N	\N	\N	\N	\N	Gallente Navy Comet
4109	79375	19686	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' AX-2
4110	79375	19687	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' CX-2
4111	79375	19688	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' LX-2
4112	79375	19689	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' MX-2
4113	79375	19690	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' SX-2
4124	79375	16003	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' CY-2
4125	79375	16004	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' AY-2
4126	79375	16005	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' DY-2
4127	79375	16006	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' GY-2
4129	79375	16009	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' MY-2
4135	79375	27110	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' EY-2
4142	79375	19691	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G2-Alpha
4143	79375	19692	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G2-Beta
4144	79375	19693	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G2-Delta
4145	79375	19694	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G2-Epsilon
4146	79375	19695	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G2-Gamma
4156	79375	19547	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET1000
4157	79375	19548	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET2000
4158	79375	19549	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET3000
4159	79375	19550	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET5000
4161	79375	19685	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET4000
4172	79375	19696	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGA1000
4173	79375	19697	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGC1000
4174	79375	19698	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGL1000
4175	79375	19699	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGM1000
4176	79375	19700	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGS1000
4187	79375	24636	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMC1000
4188	79375	24637	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZML1000
4189	79375	24638	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMM1000
4190	79375	24639	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMS1000
4191	79375	24640	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMA1000
4198	79375	16249	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KZA2000
4207	79375	16245	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KUA2000
4208	79375	16246	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KVA2000
4209	79375	16247	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KXA2000
4210	79375	16248	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KYA2000
4201	79375	24642	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KTA1000
4223	79375	27243	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMD2000
4225	79375	27245	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZME2000
4227	79375	27247	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMF2000
4229	79375	27250	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMH2000
4231	79375	27252	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMN2000
4233	79375	27254	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMR2000
4235	79375	27256	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMT2000
4237	79375	27258	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMU2000
4245	79375	27116	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CC8
4247	79375	27118	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CR8
4250	79375	27121	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EE8
4251	79375	27122	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EP8
4253	79375	27124	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' GU8
4255	79375	27126	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' PG8
4265	79375	27128	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KLB-75
4267	79375	27130	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KNB-75
4269	79375	27142	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KMB-75
4272	79375	27225	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KOB-75
4274	79375	27227	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KPB-75
4276	79375	27230	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KQB-75
4278	79375	27232	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KRB-75
4280	79375	27234	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KSB-75
4411	79375	27184	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' K60
4407	79375	27179	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' I60
4409	79375	27181	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' J60
4414	79375	27267	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' CI-2
4416	79375	27239	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' ZA-2
4419	79375	22535	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HX-2
4401	79375	27171	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' F60
4402	79375	27174	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' H60
4289	79375	27148	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' WA-2
4282	79375	27236	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KTB-75
4285	79375	25546	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' YA-2
4287	79375	25548	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' XA-2
4422	79375	27150	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HY-2
4425	79375	22571	1	\N	\N	\N	\N	\N	\N	\N	\N	29	31750000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Yeti' BX-2
4535	79375	27165	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPE-2
4503	79375	27112	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' FY-2
4505	79375	27114	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' HY-2
4510	79375	27190	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPF-2
4512	79375	27192	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPG-2
4521	79375	27268	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Draftsman' GI-2
4514	79375	27194	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPH-2
4528	79375	27158	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPA-2
4529	79375	27159	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPB-2
4531	79375	27161	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPC-2
4533	79375	27163	1	\N	\N	\N	\N	\N	\N	\N	\N	29	79375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPD-2
4475	78750	15684	5	\N	\N	\N	\N	\N	\N	\N	\N	29	31500000	15614	5	15615	29	15669	43	\N	\N	Republic Fleet Control System Blueprint
4359	78750	17486	5	\N	\N	\N	\N	\N	\N	\N	\N	29	31500000	15614	5	15615	29	15669	43	\N	\N	Republic Fleet Cruise Missile Launcher Blueprint
4063	78750	19554	1	\N	\N	\N	\N	\N	\N	\N	\N	9943	1	29	78750000	\N	\N	\N	\N	\N	\N	Snake Delta
4016	78750	20503	1	\N	\N	\N	\N	\N	\N	\N	\N	9943	1	29	78750000	\N	\N	\N	\N	\N	\N	Slave Delta
3840	78750	20502	1	\N	\N	\N	\N	\N	\N	\N	\N	9943	1	29	78750000	\N	\N	\N	\N	\N	\N	Halo Delta
3896	78750	19537	1	\N	\N	\N	\N	\N	\N	\N	\N	9943	1	29	78750000	\N	\N	\N	\N	\N	\N	Talisman Delta
3940	78750	20159	1	\N	\N	\N	\N	\N	\N	\N	\N	9943	1	29	78750000	\N	\N	\N	\N	\N	\N	Crystal Delta
4304	72000	15801	5	\N	\N	\N	\N	\N	\N	\N	\N	29	28800000	15628	359	15629	448	15660	539	\N	\N	Amarr Navy Small Energy Neutralizer Blueprint
4341	72000	15842	5	\N	\N	\N	\N	\N	\N	\N	\N	29	28800000	15602	190	15656	318	\N	\N	\N	\N	Gallente Navy 200mm Railgun Blueprint
4319	72000	15822	5	\N	\N	\N	\N	\N	\N	\N	\N	29	28800000	15592	190	15593	318	\N	\N	\N	\N	Caldari Navy 200mm Railgun Blueprint
4555	72000	15760	5	\N	\N	\N	\N	\N	\N	\N	\N	29	28800000	15599	359	15600	448	15601	539	\N	\N	Gallente Navy 1MN MicroWarpdrive Blueprint
4325	67500	15928	5	\N	\N	\N	\N	\N	\N	\N	\N	29	27000000	15590	630	15994	528	16002	420	\N	\N	Caldari Navy Micro Graviton Smartbomb Blueprint
4302	67500	15960	5	\N	\N	\N	\N	\N	\N	\N	\N	29	27000000	15628	630	15629	528	15660	420	\N	\N	Amarr Navy Micro EMP Smartbomb Blueprint
3434	65000	10217	1	\N	\N	\N	\N	\N	\N	\N	\N	29	65000000	\N	\N	\N	\N	\N	\N	\N	\N	Ocular Filter - Improved
3437	65000	10226	1	\N	\N	\N	\N	\N	\N	\N	\N	29	65000000	\N	\N	\N	\N	\N	\N	\N	\N	Social Adaptation Chip - Improved
3415	65000	10222	1	\N	\N	\N	\N	\N	\N	\N	\N	29	65000000	\N	\N	\N	\N	\N	\N	\N	\N	Cybernetic Subprocessor - Improved
3428	65000	10209	1	\N	\N	\N	\N	\N	\N	\N	\N	29	65000000	\N	\N	\N	\N	\N	\N	\N	\N	Memory Augmentation - Improved
3431	65000	10213	1	\N	\N	\N	\N	\N	\N	\N	\N	29	65000000	\N	\N	\N	\N	\N	\N	\N	\N	Neural Boost - Improved
3560	60750	15897	1	\N	\N	\N	\N	\N	\N	\N	\N	10840	1	29	24300000	15593	7	15594	22	15673	33	Caldari Navy X-Large Shield Booster
3699	60000	15755	1	\N	\N	\N	\N	\N	\N	\N	\N	12054	1	29	24000000	15614	7	15615	21	15669	33	Republic Fleet 100MN MicroWarpdrive
4557	60000	17561	5	\N	\N	\N	\N	\N	\N	\N	\N	29	24000000	15602	7	15605	21	15604	33	\N	\N	Gallente Navy Stasis Webifier Blueprint
4560	60000	15758	5	\N	\N	\N	\N	\N	\N	\N	\N	29	24000000	15614	7	15615	21	15669	33	\N	\N	Republic Fleet 100MN Afterburner Blueprint
4547	60000	17501	5	\N	\N	\N	\N	\N	\N	\N	\N	29	24000000	15593	7	15594	21	15673	33	\N	\N	Caldari Navy Stasis Webifier Blueprint
4432	60000	17529	5	\N	\N	\N	\N	\N	\N	\N	\N	29	24000000	15631	7	15632	21	15661	33	\N	\N	Amarr Navy Capacitor Power Relay Blueprint
4782	56700	28812	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	37800000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Gamma
4776	56700	28800	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	37800000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Gamma
4770	56700	28806	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	37800000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Gamma
4764	56700	28818	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	37800000	\N	\N	\N	\N	\N	\N	Low-grade Edge Gamma
4756	56700	28794	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	37800000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Gamma
4603	56250	28545	1	\N	\N	\N	\N	\N	\N	\N	\N	3993	1	29	22500000	15631	5	15632	20	15661	31	Khanid Navy Large EMP Smartbomb
3648	56250	15955	1	\N	\N	\N	\N	\N	\N	\N	\N	3987	1	29	22500000	15656	5	15605	20	15604	31	Gallente Navy Large Plasma Smartbomb
3544	56250	15931	1	\N	\N	\N	\N	\N	\N	\N	\N	3981	1	29	22500000	15593	5	15594	20	15673	31	Caldari Navy Large Graviton Smartbomb
3468	56250	15963	1	\N	\N	\N	\N	\N	\N	\N	\N	3993	1	29	22500000	15631	5	15632	20	15661	31	Amarr Navy Large EMP Smartbomb
3813	56250	15947	1	\N	\N	\N	\N	\N	\N	\N	\N	3993	1	29	22500000	15631	5	15632	20	15661	31	Ammatar Navy Large EMP Smartbomb
3733	56250	15939	1	\N	\N	\N	\N	\N	\N	\N	\N	3977	1	29	22500000	15614	5	15615	20	15669	31	Republic Fleet Large Proton Smartbomb
3756	54000	15901	1	\N	\N	\N	\N	\N	\N	\N	\N	10840	1	29	21600000	15614	4	15615	19	15669	30	Republic Fleet X-Large Shield Booster
4481	54000	15966	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15610	270	15992	336	16000	404	\N	\N	Republic Fleet Tracking Enhancer Blueprint
4558	54000	15793	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15599	270	15600	336	15601	404	\N	\N	Gallente Navy Tracking Computer Blueprint
4559	54000	15968	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15599	270	15600	336	15601	404	\N	\N	Gallente Navy Tracking Link Blueprint
4556	54000	17521	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15599	270	15600	336	15601	404	\N	\N	Gallente Navy Sensor Booster Blueprint
4326	54000	16066	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15590	270	15994	336	16002	404	\N	\N	Caldari Navy Rocket Launcher Blueprint
4571	54000	15966	5	\N	\N	\N	\N	\N	\N	\N	\N	29	21600000	15610	270	15992	336	16000	404	\N	\N	Republic Fleet Tracking Enhancer Blueprint
4602	50625	28544	1	\N	\N	\N	\N	\N	\N	\N	\N	3538	1	29	20250000	15631	3	15632	18	15661	28	Khanid Navy Large Armor Repairer
3803	50625	15743	1	\N	\N	\N	\N	\N	\N	\N	\N	3538	1	29	20250000	15631	3	15632	18	15661	28	Ammatar Navy Large Armor Repairer
3467	50625	17546	1	\N	\N	\N	\N	\N	\N	\N	\N	3538	1	29	20250000	15631	3	15632	18	15661	28	Amarr Navy Large Armor Repairer
3545	50625	15900	1	\N	\N	\N	\N	\N	\N	\N	\N	10838	1	29	20250000	15593	3	15594	18	15673	28	Caldari Navy Large Shield Booster
3552	50625	15905	1	\N	\N	\N	\N	\N	\N	\N	\N	11561	1	29	20250000	15593	3	15594	18	15673	28	Caldari Navy Shield Boost Amplifier
3465	50000	15885	1	\N	\N	\N	\N	\N	\N	\N	\N	12261	1	29	20000000	15631	7	15632	18	15661	27	Amarr Navy Heavy Nosferatu
3806	50000	15879	1	\N	\N	\N	\N	\N	\N	\N	\N	12261	1	29	20000000	15631	7	15632	18	15661	27	Ammatar Navy Heavy Nosferatu
4336	50000	17842	1	\N	\N	\N	\N	\N	\N	\N	\N	17272	1	17263	1	12538	5	12537	10	17219	10	Gallente Navy Comet Blueprint
4314	50000	17620	1	\N	\N	\N	\N	\N	\N	\N	\N	17623	1	17624	1	14292	1	17251	1	18655	1	Caldari Navy Hookbill Blueprint
4291	50000	17704	1	\N	\N	\N	\N	\N	\N	\N	\N	17743	1	17239	1	12533	5	12548	5	12547	10	Amarr Navy Slicer Blueprint
4354	50000	17813	1	\N	\N	\N	\N	\N	\N	\N	\N	17230	1	17221	1	17222	1	12528	30	17190	30	Republic Fleet Firetail Blueprint
4562	48000	15754	5	\N	\N	\N	\N	\N	\N	\N	\N	29	19200000	15613	128	15614	211	\N	\N	\N	\N	Republic Fleet 10MN Afterburner Blueprint
3701	48000	15751	1	\N	\N	\N	\N	\N	\N	\N	\N	12052	1	29	19200000	15613	128	15614	211	\N	\N	Republic Fleet 10MN MicroWarpdrive
3842	47250	20506	1	\N	\N	\N	\N	\N	\N	\N	\N	9942	1	29	47250000	\N	\N	\N	\N	\N	\N	Halo Gamma
3942	47250	20158	1	\N	\N	\N	\N	\N	\N	\N	\N	9942	1	29	47250000	\N	\N	\N	\N	\N	\N	Crystal Gamma
3898	47250	19536	1	\N	\N	\N	\N	\N	\N	\N	\N	9942	1	29	47250000	\N	\N	\N	\N	\N	\N	Talisman Gamma
4362	47250	17489	5	\N	\N	\N	\N	\N	\N	\N	\N	29	18900000	15610	235	15992	294	16000	354	\N	\N	Republic Fleet Rocket Launcher Blueprint
4018	47250	20507	1	\N	\N	\N	\N	\N	\N	\N	\N	9942	1	29	47250000	\N	\N	\N	\N	\N	\N	Slave Gamma
4065	47250	19553	1	\N	\N	\N	\N	\N	\N	\N	\N	9942	1	29	47250000	\N	\N	\N	\N	\N	\N	Snake Gamma
3947	45000	22110	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	45000000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Epsilon
4011	45000	22122	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	45000000	\N	\N	\N	\N	\N	\N	Low-grade Slave Epsilon
4058	45000	22128	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	45000000	\N	\N	\N	\N	\N	\N	Low-grade Snake Epsilon
4550	45000	15771	5	\N	\N	\N	\N	\N	\N	\N	\N	29	18000000	15656	5	15605	17	15604	24	\N	\N	Gallente Navy 100MN Afterburner Blueprint
3891	45000	22135	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	45000000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Epsilon
3847	45000	22116	1	\N	\N	\N	\N	\N	\N	\N	\N	14299	1	29	45000000	\N	\N	\N	\N	\N	\N	Low-grade Halo Epsilon
3809	45000	15798	1	\N	\N	\N	\N	\N	\N	\N	\N	12269	1	29	18000000	15631	5	15632	17	15661	24	Ammatar Navy Heavy Energy Neutralizer
3812	45000	15945	1	\N	\N	\N	\N	\N	\N	\N	\N	3953	1	29	18000000	15630	120	15631	198	\N	\N	Ammatar Navy Medium EMP Smartbomb
3746	45000	15907	1	\N	\N	\N	\N	\N	\N	\N	\N	11561	1	29	18000000	15614	5	15615	17	15669	24	Republic Fleet Shield Boost Amplifier
3738	45000	15937	1	\N	\N	\N	\N	\N	\N	\N	\N	3937	1	29	18000000	15613	120	15614	198	\N	\N	Republic Fleet Medium Proton Smartbomb
3734	45000	15904	1	\N	\N	\N	\N	\N	\N	\N	\N	10838	1	29	18000000	15614	5	15615	17	15669	24	Republic Fleet Large Shield Booster
3647	45000	15746	1	\N	\N	\N	\N	\N	\N	\N	\N	3538	1	29	18000000	15656	5	15605	17	15604	24	Gallente Navy Large Armor Repairer
3655	45000	15953	1	\N	\N	\N	\N	\N	\N	\N	\N	3947	1	29	18000000	15602	120	15656	198	\N	\N	Gallente Navy Medium Plasma Smartbomb
3617	45000	15768	1	\N	\N	\N	\N	\N	\N	\N	\N	12054	1	29	18000000	15656	5	15605	17	15604	24	Gallente Navy 100MN MicroWarpdrive
3473	45000	15961	1	\N	\N	\N	\N	\N	\N	\N	\N	3953	1	29	18000000	15630	120	15631	198	\N	\N	Amarr Navy Medium EMP Smartbomb
3547	45000	15929	1	\N	\N	\N	\N	\N	\N	\N	\N	3941	1	29	18000000	15592	120	15593	198	\N	\N	Caldari Navy Medium Graviton Smartbomb
3530	45000	15681	1	\N	\N	\N	\N	\N	\N	\N	\N	12274	1	29	18000000	15593	5	15594	17	15673	24	Caldari Navy Ballistic Control System
3533	45000	15675	1	\N	\N	\N	\N	\N	\N	\N	\N	3887	1	29	18000000	15592	120	15593	198	\N	\N	Caldari Navy Co-Processor
4606	45000	28550	1	\N	\N	\N	\N	\N	\N	\N	\N	3953	1	29	18000000	15630	120	15631	198	\N	\N	Khanid Navy Medium EMP Smartbomb
4592	45000	28563	1	\N	\N	\N	\N	\N	\N	\N	\N	12274	1	29	18000000	15631	5	15632	17	15661	24	Khanid Navy Ballistic Control System
4680	45000	28748	1	\N	\N	\N	\N	\N	\N	\N	\N	12108	1	29	30000000	\N	\N	\N	\N	\N	\N	ORE Deep Core Mining Laser
4681	45000	28754	1	\N	\N	\N	\N	\N	\N	\N	\N	17482	1	29	30000000	\N	\N	\N	\N	\N	\N	ORE Strip Miner
4678	45000	28739	1	\N	\N	\N	\N	\N	\N	\N	\N	1539	1	29	30000000	\N	\N	\N	\N	\N	\N	Thukker Power Diagnostic System
4690	45000	28770	1	\N	\N	\N	\N	\N	\N	\N	\N	12200	1	29	30000000	\N	\N	\N	\N	\N	\N	Syndicate Mobile Large Warp Disruptor
4699	45000	28776	1	\N	\N	\N	\N	\N	\N	\N	\N	1353	1	29	30000000	\N	\N	\N	\N	\N	\N	Syndicate Reactor Control Unit
4548	42000	15890	5	\N	\N	\N	\N	\N	\N	\N	\N	29	16800000	15592	111	15593	185	\N	\N	\N	\N	Caldari Navy Warp Disruptor Blueprint
4549	42000	15888	5	\N	\N	\N	\N	\N	\N	\N	\N	29	16800000	15592	111	15593	185	\N	\N	\N	\N	Caldari Navy Warp Scrambler Blueprint
3548	40500	15899	1	\N	\N	\N	\N	\N	\N	\N	\N	10836	1	29	16200000	15592	108	15593	178	\N	\N	Caldari Navy Medium Shield Booster
3470	40500	17547	1	\N	\N	\N	\N	\N	\N	\N	\N	3528	1	29	16200000	15630	108	15631	178	\N	\N	Amarr Navy Medium Armor Repairer
3802	40500	15742	1	\N	\N	\N	\N	\N	\N	\N	\N	3528	1	29	16200000	15630	108	15631	178	\N	\N	Ammatar Navy Medium Armor Repairer
4605	40500	28549	1	\N	\N	\N	\N	\N	\N	\N	\N	3528	1	29	16200000	15630	108	15631	178	\N	\N	Khanid Navy Medium Armor Repairer
4595	40000	28561	1	\N	\N	\N	\N	\N	\N	\N	\N	3887	1	29	16000000	15630	105	15631	177	\N	\N	Khanid Navy Co-Processor
3805	40000	15877	1	\N	\N	\N	\N	\N	\N	\N	\N	12257	1	29	16000000	15630	105	15631	177	\N	\N	Ammatar Navy Medium Nosferatu
3475	40000	15883	1	\N	\N	\N	\N	\N	\N	\N	\N	12257	1	29	16000000	15630	105	15631	177	\N	\N	Amarr Navy Medium Nosferatu
3464	40000	15804	1	\N	\N	\N	\N	\N	\N	\N	\N	12269	1	29	16000000	15631	5	15632	14	15661	22	Amarr Navy Heavy Energy Neutralizer
3634	40000	15677	1	\N	\N	\N	\N	\N	\N	\N	\N	3887	1	29	16000000	15602	106	15656	177	\N	\N	Gallente Navy Co-Processor
3732	39375	17492	1	\N	\N	\N	\N	\N	\N	\N	\N	3538	1	29	15750000	15614	3	15615	15	15669	21	Republic Fleet Large Armor Repairer
4738	37800	28791	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	25200000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Beta
4761	37800	28815	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	25200000	\N	\N	\N	\N	\N	\N	Low-grade Edge Beta
4767	37800	28803	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	25200000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Beta
4773	37800	28797	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	25200000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Beta
4779	37800	28809	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	25200000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Beta
4691	36000	28772	1	\N	\N	\N	\N	\N	\N	\N	\N	12199	1	29	24000000	\N	\N	\N	\N	\N	\N	Syndicate Mobile Medium Warp Disruptor
4679	36000	28750	1	\N	\N	\N	\N	\N	\N	\N	\N	483	1	29	24000000	\N	\N	\N	\N	\N	\N	ORE Miner
4693	36000	28788	1	\N	\N	\N	\N	\N	\N	\N	\N	25266	1	29	24000000	\N	\N	\N	\N	\N	\N	Syndicate Gas Cloud Harvester
4682	36000	28752	1	\N	\N	\N	\N	\N	\N	\N	\N	16278	1	29	24000000	\N	\N	\N	\N	\N	\N	ORE Ice Harvester
3739	36000	15903	1	\N	\N	\N	\N	\N	\N	\N	\N	10836	1	29	14400000	15613	95	15614	159	\N	\N	Republic Fleet Medium Shield Booster
3808	36000	15796	1	\N	\N	\N	\N	\N	\N	\N	\N	12265	1	29	14400000	15630	95	15631	159	\N	\N	Ammatar Navy Medium Energy Neutralizer
3654	36000	15745	1	\N	\N	\N	\N	\N	\N	\N	\N	3528	1	29	14400000	15602	95	15656	159	\N	\N	Gallente Navy Medium Armor Repairer
3707	36000	15747	1	\N	\N	\N	\N	\N	\N	\N	\N	434	1	29	14400000	15610	179	15992	224	16000	270	Republic Fleet 1MN MicroWarpdrive
3619	36000	15764	1	\N	\N	\N	\N	\N	\N	\N	\N	12052	1	29	14400000	15602	95	15656	159	\N	\N	Gallente Navy 10MN MicroWarpdrive
3489	36000	15860	1	\N	\N	\N	\N	\N	\N	\N	\N	464	1	29	14400000	15631	3	15632	14	15661	19	Amarr Navy Tachyon Beam Laser
4552	36000	15767	5	\N	\N	\N	\N	\N	\N	\N	\N	29	14400000	15602	95	15656	159	\N	\N	\N	\N	Gallente Navy 10MN Afterburner Blueprint
4564	36000	15750	5	\N	\N	\N	\N	\N	\N	\N	\N	29	14400000	15610	179	15992	224	16000	270	\N	\N	Republic Fleet 1MN Afterburner Blueprint
4321	36000	15791	5	\N	\N	\N	\N	\N	\N	\N	\N	29	14400000	15590	179	15994	224	16002	270	\N	\N	Caldari Navy Cloaking Device Blueprint
4495	33750	17503	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Ammatar Navy Armor EM Hardener Blueprint
4496	33750	17505	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Ammatar Navy Armor Explosive Hardener Blueprint
4497	33750	17507	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Ammatar Navy Armor Kinetic Hardener Blueprint
4498	33750	17509	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Ammatar Navy Armor Thermic Hardener Blueprint
4452	33750	17833	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15656	2	15605	13	15604	18	\N	\N	Gallente Navy Armor EM Hardener Blueprint
4453	33750	17835	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15656	2	15605	13	15604	18	\N	\N	Gallente Navy Armor Explosive Hardener Blueprint
4454	33750	17837	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15656	2	15605	13	15604	18	\N	\N	Gallente Navy Armor Kinetic Hardener Blueprint
4455	33750	17839	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15656	2	15605	13	15604	18	\N	\N	Gallente Navy Armor Thermic Hardener Blueprint
4428	33750	15712	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Amarr Navy Armor EM Hardener Blueprint
4429	33750	15710	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Amarr Navy Armor Explosive Hardener Blueprint
4430	33750	15708	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Amarr Navy Armor Kinetic Hardener Blueprint
4431	33750	15706	5	\N	\N	\N	\N	\N	\N	\N	\N	29	13500000	15631	2	15632	13	15661	18	\N	\N	Amarr Navy Armor Thermic Hardener Blueprint
3554	33750	15925	1	\N	\N	\N	\N	\N	\N	\N	\N	1551	1	29	13500000	15590	168	15994	210	16002	253	Caldari Navy Small Graviton Smartbomb
3486	33750	15957	1	\N	\N	\N	\N	\N	\N	\N	\N	1563	1	29	13500000	15628	168	15629	210	15660	253	Amarr Navy Small EMP Smartbomb
3662	33750	15949	1	\N	\N	\N	\N	\N	\N	\N	\N	1557	1	29	13500000	15599	168	15600	210	15601	253	Gallente Navy Small Plasma Smartbomb
3810	33750	15941	1	\N	\N	\N	\N	\N	\N	\N	\N	1563	1	29	13500000	15628	168	15629	210	15660	253	Ammatar Navy Small EMP Smartbomb
3749	33750	15935	1	\N	\N	\N	\N	\N	\N	\N	\N	1547	1	29	13500000	15610	168	15992	210	16000	253	Republic Fleet Small Proton Smartbomb
4611	33750	28557	1	\N	\N	\N	\N	\N	\N	\N	\N	1563	1	29	13500000	15628	168	15629	210	15660	253	Khanid Navy Small EMP Smartbomb
3474	32000	15802	1	\N	\N	\N	\N	\N	\N	\N	\N	12265	1	29	12800000	15630	85	15631	141	\N	\N	Amarr Navy Medium Energy Neutralizer
3737	31500	17493	1	\N	\N	\N	\N	\N	\N	\N	\N	3528	1	29	12600000	15613	83	15614	139	\N	\N	Republic Fleet Medium Armor Repairer
3839	31500	20500	1	\N	\N	\N	\N	\N	\N	\N	\N	9941	1	29	31500000	\N	\N	\N	\N	\N	\N	Halo Beta
3895	31500	19535	1	\N	\N	\N	\N	\N	\N	\N	\N	9941	1	29	31500000	\N	\N	\N	\N	\N	\N	Talisman Beta
3939	31500	20157	1	\N	\N	\N	\N	\N	\N	\N	\N	9941	1	29	31500000	\N	\N	\N	\N	\N	\N	Crystal Beta
4062	31500	19551	1	\N	\N	\N	\N	\N	\N	\N	\N	9941	1	29	31500000	\N	\N	\N	\N	\N	\N	Snake Beta
4015	31500	20501	1	\N	\N	\N	\N	\N	\N	\N	\N	9941	1	29	31500000	\N	\N	\N	\N	\N	\N	Slave Beta
3801	30375	15741	1	\N	\N	\N	\N	\N	\N	\N	\N	523	1	29	12150000	15628	151	15629	190	15660	227	Ammatar Navy Small Armor Repairer
3484	30375	17548	1	\N	\N	\N	\N	\N	\N	\N	\N	523	1	29	12150000	15628	151	15629	190	15660	227	Amarr Navy Small Armor Repairer
3555	30375	15898	1	\N	\N	\N	\N	\N	\N	\N	\N	399	1	29	12150000	15590	151	15994	190	16002	227	Caldari Navy Small Shield Booster
4610	30375	28556	1	\N	\N	\N	\N	\N	\N	\N	\N	523	1	29	12150000	15628	151	15629	190	15660	227	Khanid Navy Small Armor Repairer
3553	30000	16067	1	\N	\N	\N	\N	\N	\N	\N	\N	503	1	29	12000000	15593	2	15594	10	15673	17	Caldari Navy Siege Missile Launcher
3534	30000	16062	1	\N	\N	\N	\N	\N	\N	\N	\N	13320	1	29	12000000	15593	2	15594	10	15673	17	Caldari Navy Cruise Missile Launcher
3536	30000	15814	1	\N	\N	\N	\N	\N	\N	\N	\N	572	1	29	12000000	15593	2	15594	10	15673	17	Caldari Navy Dual 250mm Railgun
3523	30000	15817	1	\N	\N	\N	\N	\N	\N	\N	\N	574	1	29	12000000	15593	2	15594	10	15673	17	Caldari Navy 425mm Railgun
3524	30000	15818	1	\N	\N	\N	\N	\N	\N	\N	\N	12354	1	29	12000000	15593	2	15594	10	15673	17	Caldari Navy 350mm Railgun
3488	30000	15881	1	\N	\N	\N	\N	\N	\N	\N	\N	530	1	29	12000000	15628	149	15629	188	15660	224	Amarr Navy Small Nosferatu
3477	30000	15863	1	\N	\N	\N	\N	\N	\N	\N	\N	463	1	29	12000000	15631	2	15632	10	15661	17	Amarr Navy Mega Beam Laser
3478	30000	15862	1	\N	\N	\N	\N	\N	\N	\N	\N	462	1	29	12000000	15631	2	15632	10	15661	17	Amarr Navy Mega Pulse Laser
3461	30000	15810	1	\N	\N	\N	\N	\N	\N	\N	\N	2363	1	29	12000000	15631	2	15632	10	15661	17	Amarr Navy Heat Sink
3449	30000	15874	1	\N	\N	\N	\N	\N	\N	\N	\N	461	1	29	12000000	15631	2	15632	10	15661	17	Amarr Navy Dual Heavy Beam Laser
3450	30000	15873	1	\N	\N	\N	\N	\N	\N	\N	\N	460	1	29	12000000	15631	2	15632	10	15661	17	Amarr Navy Dual Heavy Pulse Laser
3657	30000	15825	1	\N	\N	\N	\N	\N	\N	\N	\N	573	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy Neutron Blaster Cannon
3646	30000	15829	1	\N	\N	\N	\N	\N	\N	\N	\N	575	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy Ion Blaster Cannon
3652	30000	15895	1	\N	\N	\N	\N	\N	\N	\N	\N	9944	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy Magnetic Field Stabilizer
3626	30000	15838	1	\N	\N	\N	\N	\N	\N	\N	\N	12354	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy 350mm Railgun
3627	30000	15837	1	\N	\N	\N	\N	\N	\N	\N	\N	574	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy 425mm Railgun
3636	30000	15834	1	\N	\N	\N	\N	\N	\N	\N	\N	572	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy Dual 250mm Railgun
3637	30000	15833	1	\N	\N	\N	\N	\N	\N	\N	\N	571	1	29	12000000	15656	2	15605	10	15604	17	Gallente Navy Electron Blaster Cannon
3804	30000	15875	1	\N	\N	\N	\N	\N	\N	\N	\N	530	1	29	12000000	15628	149	15629	188	15660	224	Ammatar Navy Small Nosferatu
3799	30000	15858	1	\N	\N	\N	\N	\N	\N	\N	\N	460	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Dual Heavy Pulse Laser
3800	30000	15859	1	\N	\N	\N	\N	\N	\N	\N	\N	461	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Dual Heavy Beam Laser
3822	30000	15808	1	\N	\N	\N	\N	\N	\N	\N	\N	2363	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Heat Sink
3728	30000	15806	1	\N	\N	\N	\N	\N	\N	\N	\N	520	1	29	12000000	15614	2	15615	10	15669	17	Republic Fleet Gyrostabilizer
3786	30000	15845	1	\N	\N	\N	\N	\N	\N	\N	\N	464	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Tachyon Beam Laser
3788	30000	15847	1	\N	\N	\N	\N	\N	\N	\N	\N	462	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Mega Pulse Laser
3789	30000	15848	1	\N	\N	\N	\N	\N	\N	\N	\N	463	1	29	12000000	15631	2	15632	10	15661	17	Ammatar Navy Mega Beam Laser
4471	30000	15720	5	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	15614	2	15615	10	15669	17	\N	\N	Republic Fleet Armor EM Hardener Blueprint
4472	30000	15718	5	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	15614	2	15615	10	15669	17	\N	\N	Republic Fleet Armor Explosive Hardener Blueprint
4473	30000	15716	5	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	15614	2	15615	10	15669	17	\N	\N	Republic Fleet Armor Kinetic Hardener Blueprint
4474	30000	15714	5	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	15614	2	15615	10	15669	17	\N	\N	Republic Fleet Armor Thermic Hardener Blueprint
4335	30000	17842	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Navy Comet Blueprint
4290	30000	17704	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Amarr Navy Slicer Blueprint
4313	30000	17620	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Caldari Navy Hookbill Blueprint
4353	30000	17813	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Republic Fleet Firetail Blueprint
4778	28350	28808	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	18900000	\N	\N	\N	\N	\N	\N	Low-grade Virtue Alpha
4772	28350	28796	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	18900000	\N	\N	\N	\N	\N	\N	Low-grade Nomad Alpha
4760	28350	28814	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	18900000	\N	\N	\N	\N	\N	\N	Low-grade Edge Alpha
4766	28350	28802	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	18900000	\N	\N	\N	\N	\N	\N	Low-grade Harvest Alpha
4737	28350	28790	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	18900000	\N	\N	\N	\N	\N	\N	Low-grade Centurion Alpha
4698	27000	28780	1	\N	\N	\N	\N	\N	\N	\N	\N	11279	1	29	18000000	\N	\N	\N	\N	\N	\N	Syndicate 1600mm Reinforced Steel Plates
4692	27000	28774	1	\N	\N	\N	\N	\N	\N	\N	\N	12198	1	29	18000000	\N	\N	\N	\N	\N	\N	Syndicate Mobile Small Warp Disruptor
4677	27000	28744	1	\N	\N	\N	\N	\N	\N	\N	\N	3839	1	29	18000000	\N	\N	\N	\N	\N	\N	Thukker Large Shield Extender
4669	27000	28729	1	\N	\N	\N	\N	\N	\N	\N	\N	1948	1	29	18000000	\N	\N	\N	\N	\N	\N	Legion ECM Ion Field Projector
4670	27000	28733	1	\N	\N	\N	\N	\N	\N	\N	\N	1958	1	29	18000000	\N	\N	\N	\N	\N	\N	Legion ECM Phase Inverter
4671	27000	28735	1	\N	\N	\N	\N	\N	\N	\N	\N	1955	1	29	18000000	\N	\N	\N	\N	\N	\N	Legion ECM Spatial Destabilizer
4672	27000	28737	1	\N	\N	\N	\N	\N	\N	\N	\N	1956	1	29	18000000	\N	\N	\N	\N	\N	\N	Legion ECM White Noise Generator
4433	27000	15730	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Amarr Navy Energized Adaptive Nano Membrane Blueprint
4434	27000	15728	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Amarr Navy Energized Magnetic Membrane Blueprint
4435	27000	15726	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Amarr Navy Energized Reactive Membrane Blueprint
4436	27000	15724	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Amarr Navy Energized Reflective Membrane Blueprint
4437	27000	15722	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Amarr Navy Energized Thermic Membrane Blueprint
4554	27000	15762	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15599	135	15600	168	15601	202	\N	\N	Gallente Navy 1MN Afterburner Blueprint
4542	27000	15916	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15592	71	15593	119	\N	\N	\N	\N	Caldari Navy Explosion Dampening Amplifier Blueprint
4543	27000	15914	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15592	71	15593	119	\N	\N	\N	\N	Caldari Navy Heat Dissipation Amplifier Blueprint
4544	27000	15912	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15592	71	15593	119	\N	\N	\N	\N	Caldari Navy Kinetic Deflection Amplifier Blueprint
4545	27000	15910	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15592	71	15593	119	\N	\N	\N	\N	Caldari Navy Magnetic Scattering Amplifier Blueprint
4489	27000	17537	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Ammatar Navy Energized Adaptive Nano Membrane Blueprint
4490	27000	17539	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Ammatar Navy Energized Magnetic Membrane Blueprint
4491	27000	17541	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Ammatar Navy Energized Reactive Membrane Blueprint
4492	27000	17543	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Ammatar Navy Energized Reflective Membrane Blueprint
4493	27000	17545	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10800000	15630	71	15631	119	\N	\N	\N	\N	Ammatar Navy Energized Thermic Membrane Blueprint
3750	27000	15902	1	\N	\N	\N	\N	\N	\N	\N	\N	399	1	29	10800000	15610	135	15992	168	16000	202	Republic Fleet Small Shield Booster
3807	27000	15794	1	\N	\N	\N	\N	\N	\N	\N	\N	533	1	29	10800000	15628	135	15629	168	15660	202	Ammatar Navy Small Energy Neutralizer
3623	27000	15759	1	\N	\N	\N	\N	\N	\N	\N	\N	434	1	29	10800000	15599	135	15600	168	15601	202	Gallente Navy 1MN MicroWarpdrive
3661	27000	15744	1	\N	\N	\N	\N	\N	\N	\N	\N	523	1	29	10800000	15599	135	15600	168	15601	202	Gallente Navy Small Armor Repairer
3704	26250	16048	1	\N	\N	\N	\N	\N	\N	\N	\N	498	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet 1400mm Howitzer Artillery
3747	26250	17490	1	\N	\N	\N	\N	\N	\N	\N	\N	503	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet Siege Missile Launcher
3715	26250	16057	1	\N	\N	\N	\N	\N	\N	\N	\N	496	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet 800mm Repeating Artillery
3722	26250	15683	1	\N	\N	\N	\N	\N	\N	\N	\N	12274	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet Ballistic Control System
3723	26250	17485	1	\N	\N	\N	\N	\N	\N	\N	\N	13320	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet Cruise Missile Launcher
3725	26250	16059	1	\N	\N	\N	\N	\N	\N	\N	\N	494	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet Dual 425mm Autocannon
3726	26250	16060	1	\N	\N	\N	\N	\N	\N	\N	\N	495	1	29	10500000	15614	2	15615	10	15669	14	Republic Fleet Dual 650mm Repeating Artillery
4538	26250	15787	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10500000	15631	2	15632	10	15661	14	\N	\N	Amarr Navy Heavy Capacitor Booster Blueprint
4577	26250	15779	5	\N	\N	\N	\N	\N	\N	\N	\N	29	10500000	15631	2	15632	10	15661	14	\N	\N	Ammatar Navy Heavy Capacitor Booster Blueprint
4010	25000	22121	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	25000000	\N	\N	\N	\N	\N	\N	Low-grade Slave Delta
4057	25000	22127	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	25000000	\N	\N	\N	\N	\N	\N	Low-grade Snake Delta
3946	25000	22109	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	25000000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Delta
3890	25000	22134	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	25000000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Delta
3846	25000	22115	1	\N	\N	\N	\N	\N	\N	\N	\N	14298	1	29	25000000	\N	\N	\N	\N	\N	\N	Low-grade Halo Delta
4697	24300	28786	1	\N	\N	\N	\N	\N	\N	\N	\N	11299	1	29	16200000	\N	\N	\N	\N	\N	\N	Syndicate 800mm Reinforced Steel Plates
4576	24000	15777	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15630	63	15631	106	\N	\N	\N	\N	Ammatar Navy Medium Capacitor Booster Blueprint
4601	24000	28565	1	\N	\N	\N	\N	\N	\N	\N	\N	20138	1	29	9600000	15630	63	15631	106	\N	\N	Khanid Navy Heavy Assault Missile Launcher
4616	24000	28377	1	\N	\N	\N	\N	\N	\N	\N	\N	20138	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy Heavy Assault Missile Launcher
3795	24000	15854	1	\N	\N	\N	\N	\N	\N	\N	\N	456	1	29	9600000	15630	63	15631	106	\N	\N	Ammatar Navy Focused Medium Pulse Laser
3796	24000	15855	1	\N	\N	\N	\N	\N	\N	\N	\N	457	1	29	9600000	15630	63	15631	106	\N	\N	Ammatar Navy Focused Medium Beam Laser
3787	24000	15846	1	\N	\N	\N	\N	\N	\N	\N	\N	455	1	29	9600000	15630	63	15631	106	\N	\N	Ammatar Navy Quad Beam Laser
3792	24000	15851	1	\N	\N	\N	\N	\N	\N	\N	\N	458	1	29	9600000	15630	63	15631	106	\N	\N	Ammatar Navy Heavy Pulse Laser
3793	24000	15852	1	\N	\N	\N	\N	\N	\N	\N	\N	459	1	29	9600000	15630	63	15631	106	\N	\N	Ammatar Navy Heavy Beam Laser
3635	24000	15835	1	\N	\N	\N	\N	\N	\N	\N	\N	567	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy Dual 150mm Railgun
3643	24000	15832	1	\N	\N	\N	\N	\N	\N	\N	\N	566	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy Heavy Electron Blaster
3644	24000	15831	1	\N	\N	\N	\N	\N	\N	\N	\N	569	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy Heavy Ion Blaster
3645	24000	15830	1	\N	\N	\N	\N	\N	\N	\N	\N	568	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy Heavy Neutron Blaster
3624	24000	15841	1	\N	\N	\N	\N	\N	\N	\N	\N	12344	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy 200mm Railgun
3625	24000	15840	1	\N	\N	\N	\N	\N	\N	\N	\N	570	1	29	9600000	15602	63	15656	106	\N	\N	Gallente Navy 250mm Railgun
3462	24000	15867	1	\N	\N	\N	\N	\N	\N	\N	\N	459	1	29	9600000	15630	63	15631	106	\N	\N	Amarr Navy Heavy Beam Laser
3466	24000	15866	1	\N	\N	\N	\N	\N	\N	\N	\N	458	1	29	9600000	15630	63	15631	106	\N	\N	Amarr Navy Heavy Pulse Laser
3458	24000	15870	1	\N	\N	\N	\N	\N	\N	\N	\N	457	1	29	9600000	15630	63	15631	106	\N	\N	Amarr Navy Focused Medium Beam Laser
3459	24000	15869	1	\N	\N	\N	\N	\N	\N	\N	\N	456	1	29	9600000	15630	63	15631	106	\N	\N	Amarr Navy Focused Medium Pulse Laser
3487	24000	15800	1	\N	\N	\N	\N	\N	\N	\N	\N	533	1	29	9600000	15628	119	15629	149	15660	180	Amarr Navy Small Energy Neutralizer
3481	24000	15861	1	\N	\N	\N	\N	\N	\N	\N	\N	455	1	29	9600000	15630	63	15631	106	\N	\N	Amarr Navy Quad Beam Laser
3525	24000	15820	1	\N	\N	\N	\N	\N	\N	\N	\N	570	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy 250mm Railgun
3526	24000	15821	1	\N	\N	\N	\N	\N	\N	\N	\N	12344	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy 200mm Railgun
3529	24000	16061	1	\N	\N	\N	\N	\N	\N	\N	\N	1875	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy Assault Missile Launcher
3535	24000	15815	1	\N	\N	\N	\N	\N	\N	\N	\N	567	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy Dual 150mm Railgun
3541	24000	16064	1	\N	\N	\N	\N	\N	\N	\N	\N	501	1	29	9600000	15592	63	15593	106	\N	\N	Caldari Navy Heavy Missile Launcher
4539	24000	15785	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15630	63	15631	106	\N	\N	\N	\N	Amarr Navy Medium Capacitor Booster Blueprint
4566	24000	15924	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15613	63	15614	106	\N	\N	\N	\N	Republic Fleet Explosion Dampening Amplifier Blueprint
4567	24000	15922	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15613	63	15614	106	\N	\N	\N	\N	Republic Fleet Heat Dissipation Amplifier Blueprint
4568	24000	15920	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15613	63	15614	106	\N	\N	\N	\N	Republic Fleet Kinetic Deflection Amplifier Blueprint
4569	24000	15918	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15613	63	15614	106	\N	\N	\N	\N	Republic Fleet Magnetic Scattering Amplifier Blueprint
4457	24000	15740	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15602	63	15656	106	\N	\N	\N	\N	Gallente Navy Energized Adaptive Nano Membrane Blueprint
4458	24000	15738	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15602	63	15656	106	\N	\N	\N	\N	Gallente Navy Energized Magnetic Membrane Blueprint
4459	24000	15736	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15602	63	15656	106	\N	\N	\N	\N	Gallente Navy Energized Reactive Membrane Blueprint
4460	24000	15734	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15602	63	15656	106	\N	\N	\N	\N	Gallente Navy Energized Reflective Membrane Blueprint
4461	24000	15732	5	\N	\N	\N	\N	\N	\N	\N	\N	29	9600000	15602	63	15656	106	\N	\N	\N	\N	Gallente Navy Energized Thermic Membrane Blueprint
4061	23625	19540	1	\N	\N	\N	\N	\N	\N	\N	\N	9899	1	29	23625000	\N	\N	\N	\N	\N	\N	Snake Alpha
4014	23625	20499	1	\N	\N	\N	\N	\N	\N	\N	\N	9899	1	29	23625000	\N	\N	\N	\N	\N	\N	Slave Alpha
3838	23625	20498	1	\N	\N	\N	\N	\N	\N	\N	\N	9899	1	29	23625000	\N	\N	\N	\N	\N	\N	Halo Alpha
3748	23625	17494	1	\N	\N	\N	\N	\N	\N	\N	\N	523	1	29	9450000	15610	117	15992	147	16000	177	Republic Fleet Small Armor Repairer
3894	23625	19534	1	\N	\N	\N	\N	\N	\N	\N	\N	9899	1	29	23625000	\N	\N	\N	\N	\N	\N	Talisman Alpha
3938	23625	20121	1	\N	\N	\N	\N	\N	\N	\N	\N	9899	1	29	23625000	\N	\N	\N	\N	\N	\N	Crystal Alpha
3740	22500	15933	1	\N	\N	\N	\N	\N	\N	\N	\N	3897	1	29	9000000	15610	210	15992	176	16000	140	Republic Fleet Micro Proton Smartbomb
3811	22500	15943	1	\N	\N	\N	\N	\N	\N	\N	\N	3913	1	29	9000000	15628	210	15629	176	15660	140	Ammatar Navy Micro EMP Smartbomb
3549	22500	15927	1	\N	\N	\N	\N	\N	\N	\N	\N	3901	1	29	9000000	15590	210	15994	176	16002	140	Caldari Navy Micro Graviton Smartbomb
3480	22500	15959	1	\N	\N	\N	\N	\N	\N	\N	\N	3913	1	29	9000000	15628	210	15629	176	15660	140	Amarr Navy Micro EMP Smartbomb
3656	22500	15951	1	\N	\N	\N	\N	\N	\N	\N	\N	3907	1	29	9000000	15599	210	15600	176	15601	140	Gallente Navy Micro Plasma Smartbomb
3702	22500	16047	1	\N	\N	\N	\N	\N	\N	\N	\N	497	1	29	9000000	15614	5	15615	8	15669	12	Republic Fleet 1200mm Artillery
4675	21600	28746	1	\N	\N	\N	\N	\N	\N	\N	\N	3829	1	29	14400000	\N	\N	\N	\N	\N	\N	Thukker Medium Shield Extender
4696	21600	28784	1	\N	\N	\N	\N	\N	\N	\N	\N	11297	1	29	14400000	\N	\N	\N	\N	\N	\N	Syndicate 400mm Reinforced Steel Plates
4574	21000	15789	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8400000	15631	1	15632	7	15661	12	\N	\N	Ammatar Navy Cap Recharger Blueprint
3709	21000	16051	1	\N	\N	\N	\N	\N	\N	\N	\N	490	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet 220mm Autocannon
3712	21000	16054	1	\N	\N	\N	\N	\N	\N	\N	\N	491	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet 425mm Autocannon
3713	21000	16055	1	\N	\N	\N	\N	\N	\N	\N	\N	492	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet 650mm Artillery
3714	21000	16056	1	\N	\N	\N	\N	\N	\N	\N	\N	493	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet 720mm Howitzer Artillery
3724	21000	16058	1	\N	\N	\N	\N	\N	\N	\N	\N	489	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet Dual 180mm Autocannon
3721	21000	17484	1	\N	\N	\N	\N	\N	\N	\N	\N	1875	1	29	8400000	15613	55	15614	93	\N	\N	Republic Fleet Assault Missile Launcher
4537	21000	17527	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8400000	15631	1	15632	7	15661	12	\N	\N	Amarr Navy Cap Recharger Blueprint
4439	20250	15692	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Amarr Navy Magnetic Plating Blueprint
4440	20250	15690	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Amarr Navy Reactive Plating Blueprint
4441	20250	15688	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Amarr Navy Reflective Plating Blueprint
4442	20250	15686	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Amarr Navy Thermic Plating Blueprint
4427	20250	15694	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Amarr Navy Adaptive Nano Plating Blueprint
4485	20250	17513	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Ammatar Navy Magnetic Plating Blueprint
4486	20250	17515	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Ammatar Navy Adaptive Nano Plating Blueprint
4487	20250	17517	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Ammatar Navy Reactive Plating Blueprint
4488	20250	17519	5	\N	\N	\N	\N	\N	\N	\N	\N	29	8100000	15628	100	15629	126	15660	152	\N	\N	Ammatar Navy Reflective Plating Blueprint
4383	20000	17927	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Cruor Blueprint
4380	20000	17933	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Dramiel Blueprint
4392	20000	17929	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Daredevil Blueprint
4389	20000	17925	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Succubus Blueprint
4386	20000	17931	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Worm Blueprint
3832	20000	17510	1	\N	\N	\N	\N	\N	\N	\N	\N	1445	1	29	8000000	15631	2	15632	7	15661	11	Ammatar Navy Capacitor Power Relay
3698	20000	15757	1	\N	\N	\N	\N	\N	\N	\N	\N	12066	1	29	8000000	15614	2	15615	7	15669	11	Republic Fleet 100MN Afterburner
3663	20000	17559	1	\N	\N	\N	\N	\N	\N	\N	\N	526	1	29	8000000	15656	2	15605	7	15604	11	Gallente Navy Stasis Webifier
3448	20000	17528	1	\N	\N	\N	\N	\N	\N	\N	\N	1445	1	29	8000000	15631	2	15632	7	15661	11	Amarr Navy Capacitor Power Relay
3557	20000	17500	1	\N	\N	\N	\N	\N	\N	\N	\N	526	1	29	8000000	15593	2	15594	7	15673	11	Caldari Navy Stasis Webifier
4594	20000	28532	1	\N	\N	\N	\N	\N	\N	\N	\N	1445	1	29	8000000	15631	2	15632	7	15661	11	Khanid Navy Capacitor Power Relay
4612	20000	28514	1	\N	\N	\N	\N	\N	\N	\N	\N	526	1	29	8000000	15631	2	15632	7	15661	11	Khanid Navy Stasis Webifier
4695	18900	28782	1	\N	\N	\N	\N	\N	\N	\N	\N	11295	1	29	12600000	\N	\N	\N	\N	\N	\N	Syndicate 200mm Reinforced Steel Plates
4609	18000	28511	1	\N	\N	\N	\N	\N	\N	\N	\N	10629	1	29	7200000	15628	89	15629	112	15660	135	Khanid Navy Rocket Launcher
4575	18000	15773	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15628	89	15629	112	15660	135	\N	\N	Ammatar Navy Small Capacitor Booster Blueprint
3551	18000	16065	1	\N	\N	\N	\N	\N	\N	\N	\N	10629	1	29	7200000	15590	89	15994	112	16002	135	Caldari Navy Rocket Launcher
3556	18000	16068	1	\N	\N	\N	\N	\N	\N	\N	\N	499	1	29	7200000	15590	89	15994	112	16002	135	Caldari Navy Standard Missile Launcher
3522	18000	15816	1	\N	\N	\N	\N	\N	\N	\N	\N	561	1	29	7200000	15590	89	15994	112	16002	135	Caldari Navy 75mm Railgun
3527	18000	15823	1	\N	\N	\N	\N	\N	\N	\N	\N	565	1	29	7200000	15590	89	15994	112	16002	135	Caldari Navy 150mm Railgun
3528	18000	15824	1	\N	\N	\N	\N	\N	\N	\N	\N	10678	1	29	7200000	15590	89	15994	112	16002	135	Caldari Navy 125mm Railgun
3460	18000	15868	1	\N	\N	\N	\N	\N	\N	\N	\N	450	1	29	7200000	15628	89	15629	112	15660	135	Amarr Navy Gatling Pulse Laser
3476	18000	15864	1	\N	\N	\N	\N	\N	\N	\N	\N	453	1	29	7200000	15628	89	15629	112	15660	135	Amarr Navy Medium Pulse Laser
3471	18000	15865	1	\N	\N	\N	\N	\N	\N	\N	\N	454	1	29	7200000	15628	89	15629	112	15660	135	Amarr Navy Medium Beam Laser
3451	18000	15872	1	\N	\N	\N	\N	\N	\N	\N	\N	452	1	29	7200000	15628	89	15629	112	15660	135	Amarr Navy Dual Light Beam Laser
3452	18000	15871	1	\N	\N	\N	\N	\N	\N	\N	\N	451	1	29	7200000	15628	89	15629	112	15660	135	Amarr Navy Dual Light Pulse Laser
3665	18000	15792	1	\N	\N	\N	\N	\N	\N	\N	\N	1977	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Tracking Computer
3666	18000	15967	1	\N	\N	\N	\N	\N	\N	\N	\N	2103	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Tracking Link
3660	18000	17520	1	\N	\N	\N	\N	\N	\N	\N	\N	1973	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Sensor Booster
3649	18000	15828	1	\N	\N	\N	\N	\N	\N	\N	\N	562	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Light Electron Blaster
3650	18000	15827	1	\N	\N	\N	\N	\N	\N	\N	\N	563	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Light Ion Blaster
3651	18000	15826	1	\N	\N	\N	\N	\N	\N	\N	\N	564	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy Light Neutron Blaster
3628	18000	15836	1	\N	\N	\N	\N	\N	\N	\N	\N	561	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy 75mm Railgun
3620	18000	15844	1	\N	\N	\N	\N	\N	\N	\N	\N	10678	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy 125mm Railgun
3621	18000	15843	1	\N	\N	\N	\N	\N	\N	\N	\N	565	1	29	7200000	15599	89	15600	112	15601	135	Gallente Navy 150mm Railgun
3794	18000	15853	1	\N	\N	\N	\N	\N	\N	\N	\N	450	1	29	7200000	15628	89	15629	112	15660	135	Ammatar Navy Gatling Pulse Laser
3753	18000	15965	1	\N	\N	\N	\N	\N	\N	\N	\N	1998	1	29	7200000	15610	89	15992	112	16000	135	Republic Fleet Tracking Enhancer
3797	18000	15856	1	\N	\N	\N	\N	\N	\N	\N	\N	451	1	29	7200000	15628	89	15629	112	15660	135	Ammatar Navy Dual Light Pulse Laser
3798	18000	15857	1	\N	\N	\N	\N	\N	\N	\N	\N	452	1	29	7200000	15628	89	15629	112	15660	135	Ammatar Navy Dual Light Beam Laser
3790	18000	15849	1	\N	\N	\N	\N	\N	\N	\N	\N	453	1	29	7200000	15628	89	15629	112	15660	135	Ammatar Navy Medium Pulse Laser
3791	18000	15850	1	\N	\N	\N	\N	\N	\N	\N	\N	454	1	29	7200000	15628	89	15629	112	15660	135	Ammatar Navy Medium Beam Laser
4470	18000	15704	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15610	89	15992	112	16000	135	\N	\N	Republic Fleet Adaptive Nano Plating Blueprint
4451	18000	17550	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15599	89	15600	112	15601	135	\N	\N	Gallente Navy Adaptive Nano Plating Blueprint
4463	18000	17552	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15599	89	15600	112	15601	135	\N	\N	Gallente Navy Magnetic Plating Blueprint
4464	18000	17554	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15599	89	15600	112	15601	135	\N	\N	Gallente Navy Reactive Plating Blueprint
4465	18000	17556	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15599	89	15600	112	15601	135	\N	\N	Gallente Navy Reflective Plating Blueprint
4466	18000	17558	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15599	89	15600	112	15601	135	\N	\N	Gallente Navy Thermic Plating Blueprint
4477	18000	15702	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15610	89	15992	112	16000	135	\N	\N	Republic Fleet Magnetic Plating Blueprint
4478	18000	15700	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15610	89	15992	112	16000	135	\N	\N	Republic Fleet Reactive Plating Blueprint
4479	18000	15698	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15610	89	15992	112	16000	135	\N	\N	Republic Fleet Reflective Plating Blueprint
4480	18000	15696	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15610	89	15992	112	16000	135	\N	\N	Republic Fleet Thermic Plating Blueprint
4541	18000	15781	5	\N	\N	\N	\N	\N	\N	\N	\N	29	7200000	15628	89	15629	112	15660	135	\N	\N	Amarr Navy Small Capacitor Booster Blueprint
4694	16200	28778	1	\N	\N	\N	\N	\N	\N	\N	\N	11293	1	29	10800000	\N	\N	\N	\N	\N	\N	Syndicate 100mm Reinforced Steel Plates
4673	16200	28740	1	\N	\N	\N	\N	\N	\N	\N	\N	11563	1	29	10800000	\N	\N	\N	\N	\N	\N	Thukker Micro Auxiliary Power Core
4674	16200	28742	1	\N	\N	\N	\N	\N	\N	\N	\N	377	1	29	10800000	\N	\N	\N	\N	\N	\N	Thukker Small Shield Extender
3741	16000	15813	1	\N	\N	\N	\N	\N	\N	\N	\N	2603	1	29	6400000	15613	43	15614	70	\N	\N	Republic Fleet Nanofiber Structure
3742	16000	15812	1	\N	\N	\N	\N	\N	\N	\N	\N	1244	1	29	6400000	15613	43	15614	70	\N	\N	Republic Fleet Overdrive Injector
3700	16000	15753	1	\N	\N	\N	\N	\N	\N	\N	\N	12056	1	29	6400000	15613	43	15614	70	\N	\N	Republic Fleet 10MN Afterburner
3703	15750	16046	1	\N	\N	\N	\N	\N	\N	\N	\N	484	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet 125mm Autocannon
3705	15750	16049	1	\N	\N	\N	\N	\N	\N	\N	\N	485	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet 150mm Autocannon
3708	15750	16050	1	\N	\N	\N	\N	\N	\N	\N	\N	486	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet 200mm Autocannon
3710	15750	16052	1	\N	\N	\N	\N	\N	\N	\N	\N	487	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet 250mm Artillery
3711	15750	16053	1	\N	\N	\N	\N	\N	\N	\N	\N	488	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet 280mm Howitzer Artillery
3751	15750	17491	1	\N	\N	\N	\N	\N	\N	\N	\N	499	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet Standard Missile Launcher
3745	15750	17488	1	\N	\N	\N	\N	\N	\N	\N	\N	10629	1	29	6300000	15610	78	15992	98	16000	118	Republic Fleet Rocket Launcher
3892	15000	22136	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	15000000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Gamma
3848	15000	22117	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	15000000	\N	\N	\N	\N	\N	\N	Low-grade Halo Gamma
3616	15000	15770	1	\N	\N	\N	\N	\N	\N	\N	\N	12066	1	29	6000000	15656	5	15605	5	15604	8	Gallente Navy 100MN Afterburner
4499	15000	16547	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Financial Connections
4500	15000	16551	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Trade Connections
4395	15000	16546	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Bureaucratic Connections
4396	15000	16550	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Labor Connections
4397	15000	16552	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	High Tech Connections
4012	15000	22123	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	15000000	\N	\N	\N	\N	\N	\N	Low-grade Slave Gamma
3948	15000	22111	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	15000000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Gamma
4059	15000	22129	1	\N	\N	\N	\N	\N	\N	\N	\N	14296	1	29	15000000	\N	\N	\N	\N	\N	\N	Low-grade Snake Gamma
4102	15000	16549	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Military Connections
4103	15000	16548	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10000000	\N	\N	\N	\N	\N	\N	\N	\N	Political Connections
4683	14400	28758	1	\N	\N	\N	\N	\N	\N	\N	\N	17938	1	29	9600000	\N	\N	\N	\N	\N	\N	Sisters Scan Probe Launcher
4684	14400	28756	1	\N	\N	\N	\N	\N	\N	\N	\N	18639	1	29	9600000	\N	\N	\N	\N	\N	\N	Sisters Recon Probe Launcher
4614	14000	28516	1	\N	\N	\N	\N	\N	\N	\N	\N	3242	1	29	5600000	15630	38	15631	61	\N	\N	Khanid Navy Warp Disruptor
4615	14000	28518	1	\N	\N	\N	\N	\N	\N	\N	\N	447	1	29	5600000	15630	38	15631	61	\N	\N	Khanid Navy Warp Scrambler
3558	14000	15889	1	\N	\N	\N	\N	\N	\N	\N	\N	3242	1	29	5600000	15592	38	15593	61	\N	\N	Caldari Navy Warp Disruptor
3559	14000	15887	1	\N	\N	\N	\N	\N	\N	\N	\N	447	1	29	5600000	15592	38	15593	61	\N	\N	Caldari Navy Warp Scrambler
3532	12000	15790	1	\N	\N	\N	\N	\N	\N	\N	\N	11370	1	29	4800000	15590	59	15994	74	16002	91	Caldari Navy Cloaking Device
3438	12000	10225	1	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	\N	\N	\N	\N	\N	\N	\N	\N	Social Adaptation Chip - Standard
3435	12000	10216	1	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	\N	\N	\N	\N	\N	\N	\N	\N	Ocular Filter - Standard
3432	12000	10212	1	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	\N	\N	\N	\N	\N	\N	\N	\N	Neural Boost - Standard
3429	12000	10208	1	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	\N	\N	\N	\N	\N	\N	\N	\N	Memory Augmentation - Standard
3416	12000	10221	1	\N	\N	\N	\N	\N	\N	\N	\N	29	12000000	\N	\N	\N	\N	\N	\N	\N	\N	Cybernetic Subprocessor - Standard
3618	12000	15766	1	\N	\N	\N	\N	\N	\N	\N	\N	12056	1	29	4800000	15602	31	15656	53	\N	\N	Gallente Navy 10MN Afterburner
3706	12000	15749	1	\N	\N	\N	\N	\N	\N	\N	\N	439	1	29	4800000	15610	59	15992	74	16000	91	Republic Fleet 1MN Afterburner
4540	12000	15783	5	\N	\N	\N	\N	\N	\N	\N	\N	29	4800000	15628	114	15629	93	15660	72	\N	\N	Amarr Navy Micro Capacitor Booster Blueprint
3630	11250	17832	1	\N	\N	\N	\N	\N	\N	\N	\N	11301	1	29	4500000	15656	2	15605	4	15604	6	Gallente Navy Armor EM Hardener
3631	11250	17834	1	\N	\N	\N	\N	\N	\N	\N	\N	11303	1	29	4500000	15656	2	15605	4	15604	6	Gallente Navy Armor Explosive Hardener
3632	11250	17836	1	\N	\N	\N	\N	\N	\N	\N	\N	11305	1	29	4500000	15656	2	15605	4	15604	6	Gallente Navy Armor Kinetic Hardener
3633	11250	17838	1	\N	\N	\N	\N	\N	\N	\N	\N	11277	1	29	4500000	15656	2	15605	4	15604	6	Gallente Navy Armor Thermic Hardener
3443	11250	15711	1	\N	\N	\N	\N	\N	\N	\N	\N	11301	1	29	4500000	15631	2	15632	4	15661	6	Amarr Navy Armor EM Hardener
3444	11250	15709	1	\N	\N	\N	\N	\N	\N	\N	\N	11303	1	29	4500000	15631	2	15632	4	15661	6	Amarr Navy Armor Explosive Hardener
3445	11250	15707	1	\N	\N	\N	\N	\N	\N	\N	\N	11305	1	29	4500000	15631	2	15632	4	15661	6	Amarr Navy Armor Kinetic Hardener
3446	11250	15705	1	\N	\N	\N	\N	\N	\N	\N	\N	11277	1	29	4500000	15631	2	15632	4	15661	6	Amarr Navy Armor Thermic Hardener
3540	11250	17497	1	\N	\N	\N	\N	\N	\N	\N	\N	2295	1	29	4500000	15593	2	15594	4	15673	6	Caldari Navy Heat Dissipation Field
3550	11250	17499	1	\N	\N	\N	\N	\N	\N	\N	\N	2293	1	29	4500000	15593	2	15594	4	15673	6	Caldari Navy Photon Scattering Field
3531	11250	17495	1	\N	\N	\N	\N	\N	\N	\N	\N	2291	1	29	4500000	15593	2	15594	4	15673	6	Caldari Navy Ballistic Deflection Field
3538	11250	17496	1	\N	\N	\N	\N	\N	\N	\N	\N	2289	1	29	4500000	15593	2	15594	4	15673	6	Caldari Navy Explosion Dampening Field
3828	11250	17502	1	\N	\N	\N	\N	\N	\N	\N	\N	11301	1	29	4500000	15631	2	15632	4	15661	6	Ammatar Navy Armor EM Hardener
3829	11250	17504	1	\N	\N	\N	\N	\N	\N	\N	\N	11303	1	29	4500000	15631	2	15632	4	15661	6	Ammatar Navy Armor Explosive Hardener
3830	11250	17506	1	\N	\N	\N	\N	\N	\N	\N	\N	11305	1	29	4500000	15631	2	15632	4	15661	6	Ammatar Navy Armor Kinetic Hardener
3831	11250	17508	1	\N	\N	\N	\N	\N	\N	\N	\N	11277	1	29	4500000	15631	2	15632	4	15661	6	Ammatar Navy Armor Thermic Hardener
4588	11250	28522	1	\N	\N	\N	\N	\N	\N	\N	\N	11301	1	29	4500000	15631	2	15632	4	15661	6	Khanid Navy Armor EM Hardener
4589	11250	28524	1	\N	\N	\N	\N	\N	\N	\N	\N	11303	1	29	4500000	15631	2	15632	4	15661	6	Khanid Navy Armor Explosive Hardener
4590	11250	28526	1	\N	\N	\N	\N	\N	\N	\N	\N	11305	1	29	4500000	15631	2	15632	4	15661	6	Khanid Navy Armor Kinetic Hardener
4591	11250	28528	1	\N	\N	\N	\N	\N	\N	\N	\N	11277	1	29	4500000	15631	2	15632	4	15661	6	Khanid Navy Armor Thermic Hardener
4507	10875	27186	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPF-1
4508	10875	27187	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPG-1
4509	10875	27188	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPH-1
4522	10875	27152	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPA-1
4523	10875	27153	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPB-1
4524	10875	27154	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPC-1
4525	10875	27155	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPD-1
4526	10875	27156	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPE-1
4516	10875	27196	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPW-1
4517	10875	27197	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPX-1
4518	10875	27198	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPY-1
4519	10875	27260	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPZ-1
4520	10875	27265	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Draftsman' GI-1
4501	10875	13241	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' FY-1
4502	10875	13242	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' HY-1
4424	10875	22570	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Yeti' BX-1
4398	10875	27167	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' F50
4399	10875	27169	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' H50
4404	10875	27176	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' J50
4405	10875	27177	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' I50
4406	10875	27178	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' K50
4418	10875	22534	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HX-1
4421	10875	27149	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HY-1
4415	10875	27238	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' ZA-1
4413	10875	27264	1	\N	\N	\N	\N	\N	\N	\N	\N	29	4350000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' CI-1
4288	10875	27147	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' WA-1
4286	10875	25547	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' XA-1
4271	10875	27224	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KTB-50
4284	10875	25545	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' YA-1
4104	10875	9957	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' AX-1
4105	10875	13219	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' LX-1
4106	10875	13222	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' MX-1
4107	10875	13225	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' SX-1
4108	10875	13244	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' CX-1
4128	10875	16008	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' MY-1
4119	10875	13237	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' CY-1
4120	10875	13238	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' DY-1
4121	10875	13239	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' EY-1
4122	10875	13240	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' AY-1
4123	10875	13243	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' GY-1
4257	10875	10244	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KNB-50
4258	10875	13216	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KMB-50
4259	10875	13232	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KOB-50
4260	10875	13233	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KPB-50
4261	10875	13234	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KQB-50
4262	10875	13235	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KRB-50
4263	10875	13236	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KSB-50
4264	10875	13254	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KLB-50
4239	10875	13251	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EP4
4240	10875	13255	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' GU4
4241	10875	13259	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CC4
4242	10875	13260	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CR4
4243	10875	13261	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' PG4
4244	10875	13265	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EE4
4215	10875	13226	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMU1000
4216	10875	13227	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMD1000
4217	10875	13228	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMF1000
4218	10875	13229	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMH1000
4219	10875	13230	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMR1000
4220	10875	13231	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMT1000
4221	10875	27108	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMN1000
4222	10875	27109	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZME1000
4197	10875	13252	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KZA1000
4200	10875	24641	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KTA100
4203	10875	10228	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KVA1000
4204	10875	13253	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KUA1000
4205	10875	13262	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KXA1000
4206	10875	13263	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KYA1000
4167	10875	10204	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGA100
4168	10875	13218	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGL100
4169	10875	13221	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGM100
4170	10875	13224	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGS100
4171	10875	13245	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGC100
4182	10875	13247	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMC100
4183	10875	13248	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZML100
4184	10875	13249	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMM100
4185	10875	13250	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMS100
4186	10875	24632	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMA100
4160	10875	19684	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET400
4137	10875	13166	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G1-Delta
4138	10875	13217	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G1-Epsilon
4139	10875	13220	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G1-Gamma
4140	10875	13223	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G1-Alpha
4141	10875	13246	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G1-Beta
4152	10875	13256	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET500
4153	10875	13257	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET300
4154	10875	13258	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET100
4155	10875	17871	1	\N	\N	\N	\N	\N	\N	\N	\N	29	10875000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET200
4056	10000	22126	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	10000000	\N	\N	\N	\N	\N	\N	Low-grade Snake Beta
4009	10000	22120	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	10000000	\N	\N	\N	\N	\N	\N	Low-grade Slave Beta
3845	10000	22114	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	10000000	\N	\N	\N	\N	\N	\N	Low-grade Halo Beta
3889	10000	22133	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	10000000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Beta
3945	10000	22108	1	\N	\N	\N	\N	\N	\N	\N	\N	14297	1	29	10000000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Beta
3717	10000	15719	1	\N	\N	\N	\N	\N	\N	\N	\N	11301	1	29	4000000	15615	3	15669	6	\N	\N	Republic Fleet Armor EM Hardener
3718	10000	15717	1	\N	\N	\N	\N	\N	\N	\N	\N	11303	1	29	4000000	15615	3	15669	6	\N	\N	Republic Fleet Armor Explosive Hardener
3719	10000	15715	1	\N	\N	\N	\N	\N	\N	\N	\N	11305	1	29	4000000	15615	3	15669	6	\N	\N	Republic Fleet Armor Kinetic Hardener
3720	10000	15713	1	\N	\N	\N	\N	\N	\N	\N	\N	11277	1	29	4000000	15615	3	15669	6	\N	\N	Republic Fleet Armor Thermic Hardener
3622	9000	15761	1	\N	\N	\N	\N	\N	\N	\N	\N	439	1	29	3600000	15599	44	15600	56	15601	68	Gallente Navy 1MN Afterburner
3539	9000	15913	1	\N	\N	\N	\N	\N	\N	\N	\N	2537	1	29	3600000	15592	23	15593	40	\N	\N	Caldari Navy Heat Dissipation Amplifier
3537	9000	15915	1	\N	\N	\N	\N	\N	\N	\N	\N	2529	1	29	3600000	15592	23	15593	40	\N	\N	Caldari Navy Explosion Dampening Amplifier
3543	9000	15911	1	\N	\N	\N	\N	\N	\N	\N	\N	2545	1	29	3600000	15592	23	15593	40	\N	\N	Caldari Navy Kinetic Deflection Amplifier
3546	9000	15909	1	\N	\N	\N	\N	\N	\N	\N	\N	1808	1	29	3600000	15592	23	15593	40	\N	\N	Caldari Navy Magnetic Scattering Amplifier
3453	9000	15729	1	\N	\N	\N	\N	\N	\N	\N	\N	11267	1	29	3600000	15630	23	15631	40	\N	\N	Amarr Navy Energized Adaptive Nano Membrane
3454	9000	15727	1	\N	\N	\N	\N	\N	\N	\N	\N	11247	1	29	3600000	15630	23	15631	40	\N	\N	Amarr Navy Energized Magnetic Membrane
3455	9000	15725	1	\N	\N	\N	\N	\N	\N	\N	\N	11227	1	29	3600000	15630	23	15631	40	\N	\N	Amarr Navy Energized Reactive Membrane
3456	9000	15723	1	\N	\N	\N	\N	\N	\N	\N	\N	11217	1	29	3600000	15630	23	15631	40	\N	\N	Amarr Navy Energized Reflective Membrane
3457	9000	15721	1	\N	\N	\N	\N	\N	\N	\N	\N	11257	1	29	3600000	15630	23	15631	40	\N	\N	Amarr Navy Energized Thermic Membrane
3823	9000	17536	1	\N	\N	\N	\N	\N	\N	\N	\N	11267	1	29	3600000	15630	23	15631	40	\N	\N	Ammatar Navy Energized Adaptive Nano Membrane
3824	9000	17538	1	\N	\N	\N	\N	\N	\N	\N	\N	11247	1	29	3600000	15630	23	15631	40	\N	\N	Ammatar Navy Energized Magnetic Membrane
3825	9000	17540	1	\N	\N	\N	\N	\N	\N	\N	\N	11227	1	29	3600000	15630	23	15631	40	\N	\N	Ammatar Navy Energized Reactive Membrane
3826	9000	17542	1	\N	\N	\N	\N	\N	\N	\N	\N	11217	1	29	3600000	15630	23	15631	40	\N	\N	Ammatar Navy Energized Reflective Membrane
3827	9000	17544	1	\N	\N	\N	\N	\N	\N	\N	\N	11257	1	29	3600000	15630	23	15631	40	\N	\N	Ammatar Navy Energized Thermic Membrane
4311	9000	12215	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Pulse Laser Specialization
4308	9000	12205	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Beam Laser Specialization
4348	9000	12207	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Railgun Specialization
4331	9000	20212	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Cruise Missile Specialization
4332	9000	20213	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Torpedo Specialization
4369	9000	12209	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Autocannon Specialization
4351	9000	12212	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Blaster Specialization
4367	9000	12203	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Large Artillery Specialization
4596	9000	28534	1	\N	\N	\N	\N	\N	\N	\N	\N	11267	1	29	3600000	15630	23	15631	40	\N	\N	Khanid Navy Energized Adaptive Nano Membrane
4597	9000	28536	1	\N	\N	\N	\N	\N	\N	\N	\N	11247	1	29	3600000	15630	23	15631	40	\N	\N	Khanid Navy Energized Magnetic Membrane
4598	9000	28538	1	\N	\N	\N	\N	\N	\N	\N	\N	11227	1	29	3600000	15630	23	15631	40	\N	\N	Khanid Navy Energized Reactive Membrane
4599	9000	28540	1	\N	\N	\N	\N	\N	\N	\N	\N	11217	1	29	3600000	15630	23	15631	40	\N	\N	Khanid Navy Energized Reflective Membrane
4600	9000	28542	1	\N	\N	\N	\N	\N	\N	\N	\N	11257	1	29	3600000	15630	23	15631	40	\N	\N	Khanid Navy Energized Thermic Membrane
4668	9000	28731	1	\N	\N	\N	\N	\N	\N	\N	\N	1957	1	29	6000000	\N	\N	\N	\N	\N	\N	Legion ECM Multispectral Jammer
3817	8750	15778	1	\N	\N	\N	\N	\N	\N	\N	\N	3576	1	29	3500000	15632	3	15661	5	\N	\N	Ammatar Navy Heavy Capacitor Booster
3463	8750	15786	1	\N	\N	\N	\N	\N	\N	\N	\N	3576	1	29	3500000	15632	3	15661	5	\N	\N	Amarr Navy Heavy Capacitor Booster
3472	8000	15784	1	\N	\N	\N	\N	\N	\N	\N	\N	577	1	29	3200000	15630	21	15631	35	\N	\N	Amarr Navy Medium Capacitor Booster
3638	8000	15739	1	\N	\N	\N	\N	\N	\N	\N	\N	11267	1	29	3200000	15602	21	15656	35	\N	\N	Gallente Navy Energized Adaptive Nano Membrane
3639	8000	15737	1	\N	\N	\N	\N	\N	\N	\N	\N	11247	1	29	3200000	15602	21	15656	35	\N	\N	Gallente Navy Energized Magnetic Membrane
3640	8000	15735	1	\N	\N	\N	\N	\N	\N	\N	\N	11227	1	29	3200000	15602	21	15656	35	\N	\N	Gallente Navy Energized Reactive Membrane
3641	8000	15733	1	\N	\N	\N	\N	\N	\N	\N	\N	11217	1	29	3200000	15602	21	15656	35	\N	\N	Gallente Navy Energized Reflective Membrane
3642	8000	15731	1	\N	\N	\N	\N	\N	\N	\N	\N	11257	1	29	3200000	15602	21	15656	35	\N	\N	Gallente Navy Energized Thermic Membrane
3816	8000	15776	1	\N	\N	\N	\N	\N	\N	\N	\N	577	1	29	3200000	15630	21	15631	35	\N	\N	Ammatar Navy Medium Capacitor Booster
3727	8000	15923	1	\N	\N	\N	\N	\N	\N	\N	\N	2529	1	29	3200000	15613	21	15614	35	\N	\N	Republic Fleet Explosion Dampening Amplifier
3729	8000	15921	1	\N	\N	\N	\N	\N	\N	\N	\N	2537	1	29	3200000	15613	21	15614	35	\N	\N	Republic Fleet Heat Dissipation Amplifier
3731	8000	15919	1	\N	\N	\N	\N	\N	\N	\N	\N	2545	1	29	3200000	15613	21	15614	35	\N	\N	Republic Fleet Kinetic Deflection Amplifier
3736	8000	15917	1	\N	\N	\N	\N	\N	\N	\N	\N	1808	1	29	3200000	15613	21	15614	35	\N	\N	Republic Fleet Magnetic Scattering Amplifier
4469	8000	17850	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Alpha Nexus Chip
4482	8000	17814	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Minmatar UUC Nexus Chip
4443	8000	17793	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Amarr TIL-1 Nexus Chip
4448	8000	17643	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Caldari AZ-1 Nexus Chip
4008	7500	22119	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	7500000	\N	\N	\N	\N	\N	\N	Low-grade Slave Alpha
4055	7500	22125	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	7500000	\N	\N	\N	\N	\N	\N	Low-grade Snake Alpha
3844	7500	22113	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	7500000	\N	\N	\N	\N	\N	\N	Low-grade Halo Alpha
3944	7500	22107	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	7500000	\N	\N	\N	\N	\N	\N	Low-grade Crystal Alpha
3888	7500	22131	1	\N	\N	\N	\N	\N	\N	\N	\N	14295	1	29	7500000	\N	\N	\N	\N	\N	\N	Low-grade Talisman Alpha
3785	7000	15788	1	\N	\N	\N	\N	\N	\N	\N	\N	1195	1	29	2800000	15631	2	15632	2	15661	4	Ammatar Navy Cap Recharger
3730	7000	17487	1	\N	\N	\N	\N	\N	\N	\N	\N	501	1	29	2800000	15613	18	15614	31	\N	\N	Republic Fleet Heavy Missile Launcher
3447	7000	17526	1	\N	\N	\N	\N	\N	\N	\N	\N	1195	1	29	2800000	15631	2	15632	2	15661	4	Amarr Navy Cap Recharger
4617	7000	28375	1	\N	\N	\N	\N	\N	\N	\N	\N	20138	1	29	2800000	15613	18	15614	31	\N	\N	Republic Fleet Heavy Assault Missile Launcher
4593	7000	28530	1	\N	\N	\N	\N	\N	\N	\N	\N	1195	1	29	2800000	15631	2	15632	2	15661	4	Khanid Navy Cap Recharger
4587	6750	28520	1	\N	\N	\N	\N	\N	\N	\N	\N	1304	1	29	2700000	15628	33	15629	42	15660	51	Khanid Navy Adaptive Nano Plating
4604	6750	28547	1	\N	\N	\N	\N	\N	\N	\N	\N	1284	1	29	2700000	15628	33	15629	42	15660	51	Khanid Navy Magnetic Plating
4613	6750	28559	1	\N	\N	\N	\N	\N	\N	\N	\N	1294	1	29	2700000	15628	33	15629	42	15660	51	Khanid Navy Thermic Plating
4607	6750	28552	1	\N	\N	\N	\N	\N	\N	\N	\N	1264	1	29	2700000	15628	33	15629	42	15660	51	Khanid Navy Reactive Plating
4608	6750	28554	1	\N	\N	\N	\N	\N	\N	\N	\N	1197	1	29	2700000	15628	33	15629	42	15660	51	Khanid Navy Reflective Plating
3469	6750	15691	1	\N	\N	\N	\N	\N	\N	\N	\N	1284	1	29	2700000	15628	33	15629	42	15660	51	Amarr Navy Magnetic Plating
3482	6750	15689	1	\N	\N	\N	\N	\N	\N	\N	\N	1264	1	29	2700000	15628	33	15629	42	15660	51	Amarr Navy Reactive Plating
3483	6750	15687	1	\N	\N	\N	\N	\N	\N	\N	\N	1197	1	29	2700000	15628	33	15629	42	15660	51	Amarr Navy Reflective Plating
3442	6750	15693	1	\N	\N	\N	\N	\N	\N	\N	\N	1304	1	29	2700000	15628	33	15629	42	15660	51	Amarr Navy Adaptive Nano Plating
3490	6750	15685	1	\N	\N	\N	\N	\N	\N	\N	\N	1294	1	29	2700000	15628	33	15629	42	15660	51	Amarr Navy Thermic Plating
3818	6750	17512	1	\N	\N	\N	\N	\N	\N	\N	\N	1284	1	29	2700000	15628	33	15629	42	15660	51	Ammatar Navy Magnetic Plating
3819	6750	17514	1	\N	\N	\N	\N	\N	\N	\N	\N	1304	1	29	2700000	15628	33	15629	42	15660	51	Ammatar Navy Adaptive Nano Plating
3820	6750	17516	1	\N	\N	\N	\N	\N	\N	\N	\N	1264	1	29	2700000	15628	33	15629	42	15660	51	Ammatar Navy Reactive Plating
3821	6750	17518	1	\N	\N	\N	\N	\N	\N	\N	\N	1197	1	29	2700000	15628	33	15629	42	15660	51	Ammatar Navy Reflective Plating
3814	6000	15772	1	\N	\N	\N	\N	\N	\N	\N	\N	3566	1	29	2400000	15628	29	15629	38	15660	45	Ammatar Navy Small Capacitor Booster
3735	6000	15701	1	\N	\N	\N	\N	\N	\N	\N	\N	1284	1	29	2400000	15610	29	15992	38	16000	45	Republic Fleet Magnetic Plating
3716	6000	15703	1	\N	\N	\N	\N	\N	\N	\N	\N	1304	1	29	2400000	15610	29	15992	38	16000	45	Republic Fleet Adaptive Nano Plating
3752	6000	15695	1	\N	\N	\N	\N	\N	\N	\N	\N	1294	1	29	2400000	15610	29	15992	38	16000	45	Republic Fleet Thermic Plating
3743	6000	15699	1	\N	\N	\N	\N	\N	\N	\N	\N	1264	1	29	2400000	15610	29	15992	38	16000	45	Republic Fleet Reactive Plating
3744	6000	15697	1	\N	\N	\N	\N	\N	\N	\N	\N	1197	1	29	2400000	15610	29	15992	38	16000	45	Republic Fleet Reflective Plating
3485	6000	15780	1	\N	\N	\N	\N	\N	\N	\N	\N	3566	1	29	2400000	15628	29	15629	38	15660	45	Amarr Navy Small Capacitor Booster
3629	6000	17549	1	\N	\N	\N	\N	\N	\N	\N	\N	1304	1	29	2400000	15599	29	15600	38	15601	45	Gallente Navy Adaptive Nano Plating
3653	6000	17551	1	\N	\N	\N	\N	\N	\N	\N	\N	1284	1	29	2400000	15599	29	15600	38	15601	45	Gallente Navy Magnetic Plating
3658	6000	17553	1	\N	\N	\N	\N	\N	\N	\N	\N	1264	1	29	2400000	15599	29	15600	38	15601	45	Gallente Navy Reactive Plating
3659	6000	17555	1	\N	\N	\N	\N	\N	\N	\N	\N	1197	1	29	2400000	15599	29	15600	38	15601	45	Gallente Navy Reflective Plating
3664	6000	17557	1	\N	\N	\N	\N	\N	\N	\N	\N	1294	1	29	2400000	15599	29	15600	38	15601	45	Gallente Navy Thermic Plating
3576	5500	27351	5000	\N	\N	\N	\N	\N	\N	\N	\N	2510	5000	29	5500000	\N	\N	\N	\N	\N	\N	Caldari Navy Inferno Torpedo
3583	5500	27345	5000	\N	\N	\N	\N	\N	\N	\N	\N	267	5000	29	5500000	\N	\N	\N	\N	\N	\N	Caldari Navy Juggernaut Torpedo
3587	5500	27339	5000	\N	\N	\N	\N	\N	\N	\N	\N	2506	5000	29	5500000	\N	\N	\N	\N	\N	\N	Caldari Navy Mjolnir Torpedo
3564	5500	27359	5000	\N	\N	\N	\N	\N	\N	\N	\N	2508	5000	29	5500000	\N	\N	\N	\N	\N	\N	Caldari Navy Bane Torpedo
3427	5250	9941	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5250000	\N	\N	\N	\N	\N	\N	\N	\N	Memory Augmentation - Basic
3436	5250	9956	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5250000	\N	\N	\N	\N	\N	\N	\N	\N	Social Adaptation Chip - Basic
3430	5250	9942	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5250000	\N	\N	\N	\N	\N	\N	\N	\N	Neural Boost - Basic
3433	5250	9899	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5250000	\N	\N	\N	\N	\N	\N	\N	\N	Ocular Filter - Basic
3414	5250	9943	1	\N	\N	\N	\N	\N	\N	\N	\N	29	5250000	\N	\N	\N	\N	\N	\N	\N	\N	Cybernetic Subprocessor - Basic
3588	4200	27377	5000	\N	\N	\N	\N	\N	\N	\N	\N	202	5000	29	4200000	\N	\N	\N	\N	\N	\N	Caldari Navy Paradise Cruise Missile
3566	4200	27423	5000	\N	\N	\N	\N	\N	\N	\N	\N	204	5000	29	4200000	\N	\N	\N	\N	\N	\N	Caldari Navy Cataclysm Cruise Missile
3567	4200	27429	5000	\N	\N	\N	\N	\N	\N	\N	\N	205	5000	29	4200000	\N	\N	\N	\N	\N	\N	Caldari Navy Devastator Cruise Missile
3611	4200	27395	5000	\N	\N	\N	\N	\N	\N	\N	\N	203	5000	29	4200000	\N	\N	\N	\N	\N	\N	Caldari Navy Wrath Cruise Missile
3479	4000	15782	1	\N	\N	\N	\N	\N	\N	\N	\N	3556	1	29	1600000	15628	38	15629	31	15660	24	Amarr Navy Micro Capacitor Booster
3815	4000	15774	1	\N	\N	\N	\N	\N	\N	\N	\N	3556	1	29	1600000	15628	38	15629	31	15660	24	Ammatar Navy Micro Capacitor Booster
4001	3850	27357	5000	\N	\N	\N	\N	\N	\N	\N	\N	2508	5000	29	3850000	\N	\N	\N	\N	\N	\N	Guristas Bane Torpedo
4002	3850	27349	5000	\N	\N	\N	\N	\N	\N	\N	\N	2510	5000	29	3850000	\N	\N	\N	\N	\N	\N	Guristas Inferno Torpedo
4003	3850	27343	5000	\N	\N	\N	\N	\N	\N	\N	\N	267	5000	29	3850000	\N	\N	\N	\N	\N	\N	Guristas Juggernaut Torpedo
4004	3850	27337	5000	\N	\N	\N	\N	\N	\N	\N	\N	2506	5000	29	3850000	\N	\N	\N	\N	\N	\N	Guristas Mjolnir Torpedo
3491	3750	23107	10	\N	\N	\N	\N	\N	\N	\N	\N	261	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Gamma L
3495	3750	23115	10	\N	\N	\N	\N	\N	\N	\N	\N	257	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Infrared L
3498	3750	23117	10	\N	\N	\N	\N	\N	\N	\N	\N	256	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Microwave L
3501	3750	23105	10	\N	\N	\N	\N	\N	\N	\N	\N	262	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Multifrequency L
3504	3750	23119	10	\N	\N	\N	\N	\N	\N	\N	\N	255	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Radio L
3509	3750	23113	10	\N	\N	\N	\N	\N	\N	\N	\N	258	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Standard L
3512	3750	23111	10	\N	\N	\N	\N	\N	\N	\N	\N	259	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Ultraviolet L
3515	3750	23109	10	\N	\N	\N	\N	\N	\N	\N	\N	260	10	29	3750000	\N	\N	\N	\N	\N	\N	Amarr Navy Xray L
3783	3600	21941	5000	\N	\N	\N	\N	\N	\N	\N	\N	17678	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet Titanium Sabot XL
3779	3600	21933	5000	\N	\N	\N	\N	\N	\N	\N	\N	17676	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet Proton XL
3760	3600	21900	5000	\N	\N	\N	\N	\N	\N	\N	\N	17668	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet EMP XL
3766	3600	21908	5000	\N	\N	\N	\N	\N	\N	\N	\N	17670	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet Fusion XL
3770	3600	21916	5000	\N	\N	\N	\N	\N	\N	\N	\N	17672	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet Nuclear XL
3775	3600	21920	5000	\N	\N	\N	\N	\N	\N	\N	\N	17674	5000	29	3600000	\N	\N	\N	\N	\N	\N	Republic Fleet Phased Plasma XL
3771	3000	27477	5000	\N	\N	\N	\N	\N	\N	\N	\N	1830	5000	29	3000000	\N	\N	\N	\N	\N	\N	Republic Fleet Obliterator F.O.F. Cruise Missile I
3900	3000	27457	5000	\N	\N	\N	\N	\N	\N	\N	\N	1828	5000	29	3000000	\N	\N	\N	\N	\N	\N	Blood Hunter F.O.F. Cruise Missile I
3494	3000	27459	5000	\N	\N	\N	\N	\N	\N	\N	\N	1828	5000	29	3000000	\N	\N	\N	\N	\N	\N	Amarr Navy Hunter F.O.F. Cruise Missile I
3602	3000	27435	5000	\N	\N	\N	\N	\N	\N	\N	\N	207	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Thunderbolt Heavy Missile
3603	3000	27419	5000	\N	\N	\N	\N	\N	\N	\N	\N	20306	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Torrent Assault Missile
3610	3000	27447	5000	\N	\N	\N	\N	\N	\N	\N	\N	208	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Widowmaker Heavy Missile
3568	3000	27465	5000	\N	\N	\N	\N	\N	\N	\N	\N	1826	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Dragon F.O.F. Cruise Missile I
3571	3000	27401	5000	\N	\N	\N	\N	\N	\N	\N	\N	21867	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Fulmination Assault Missile
3573	3000	27453	5000	\N	\N	\N	\N	\N	\N	\N	\N	206	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Havoc Heavy Missile
3574	3000	27405	5000	\N	\N	\N	\N	\N	\N	\N	\N	20308	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Hellfire Assault Missile
3597	3000	27413	5000	\N	\N	\N	\N	\N	\N	\N	\N	20307	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Terror Assault Missile
3595	3000	27441	5000	\N	\N	\N	\N	\N	\N	\N	\N	209	5000	29	3000000	\N	\N	\N	\N	\N	\N	Caldari Navy Scourge Heavy Missile
3669	3000	27471	5000	\N	\N	\N	\N	\N	\N	\N	\N	1832	5000	29	3000000	\N	\N	\N	\N	\N	\N	Gallente Navy Phoenix F.O.F. Cruise Missile I
4368	3000	12208	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Autocannon Specialization
4366	3000	12202	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Artillery Specialization
4352	3000	12486	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Drone Specialization
4350	3000	12211	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Blaster Specialization
4370	3000	12485	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Minmatar Drone Specialization
4333	3000	25718	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Heavy Assault Missile Specialization
4334	3000	12487	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Caldari Drone Specialization
4347	3000	12206	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Railgun Specialization
4330	3000	20211	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Heavy Missile Specialization
4307	3000	12204	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Beam Laser Specialization
4310	3000	12214	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Medium Pulse Laser Specialization
4312	3000	12484	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Amarr Drone Specialization
3950	2940	27409	5000	\N	\N	\N	\N	\N	\N	\N	\N	204	5000	29	2940000	\N	\N	\N	\N	\N	\N	Guristas Cataclysm Cruise Missile
3951	2940	27427	5000	\N	\N	\N	\N	\N	\N	\N	\N	205	5000	29	2940000	\N	\N	\N	\N	\N	\N	Guristas Devastator Cruise Missile
3952	2940	27373	5000	\N	\N	\N	\N	\N	\N	\N	\N	202	5000	29	2940000	\N	\N	\N	\N	\N	\N	Guristas Paradise Cruise Missile
3953	2940	27391	5000	\N	\N	\N	\N	\N	\N	\N	\N	203	5000	29	2940000	\N	\N	\N	\N	\N	\N	Guristas Wrath Cruise Missile
3964	2700	21368	5000	\N	\N	\N	\N	\N	\N	\N	\N	17648	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Antimatter Charge XL
3968	2700	21370	5000	\N	\N	\N	\N	\N	\N	\N	\N	17650	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Iridium Charge XL
3972	2700	21372	5000	\N	\N	\N	\N	\N	\N	\N	\N	17652	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Iron Charge XL
3976	2700	21374	5000	\N	\N	\N	\N	\N	\N	\N	\N	17654	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Lead Charge XL
3980	2700	21376	5000	\N	\N	\N	\N	\N	\N	\N	\N	17656	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Plutonium Charge XL
3984	2700	21378	5000	\N	\N	\N	\N	\N	\N	\N	\N	17658	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Thorium Charge XL
3988	2700	21380	5000	\N	\N	\N	\N	\N	\N	\N	\N	17660	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Tungsten Charge XL
3992	2700	21382	5000	\N	\N	\N	\N	\N	\N	\N	\N	17662	5000	29	2700000	\N	\N	\N	\N	\N	\N	Guristas Uranium Charge XL
3869	2700	20745	5000	\N	\N	\N	\N	\N	\N	\N	\N	17672	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Nuclear XL
3873	2700	20747	5000	\N	\N	\N	\N	\N	\N	\N	\N	17674	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Phased Plasma XL
3877	2700	20749	5000	\N	\N	\N	\N	\N	\N	\N	\N	17676	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Proton XL
3881	2700	20751	5000	\N	\N	\N	\N	\N	\N	\N	\N	17678	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Titanium Sabot XL
3853	2700	20737	5000	\N	\N	\N	\N	\N	\N	\N	\N	17664	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Carbonized Lead XL
3857	2700	20739	5000	\N	\N	\N	\N	\N	\N	\N	\N	17666	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Depleted Uranium XL
3861	2700	20741	5000	\N	\N	\N	\N	\N	\N	\N	\N	17668	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel EMP XL
3862	2700	20731	5000	\N	\N	\N	\N	\N	\N	\N	\N	199	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Fusion L
3865	2700	20743	5000	\N	\N	\N	\N	\N	\N	\N	\N	17670	5000	29	2700000	\N	\N	\N	\N	\N	\N	Arch Angel Fusion XL
4101	2700	20943	5000	\N	\N	\N	\N	\N	\N	\N	\N	17662	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Uranium Charge XL
4097	2700	20941	5000	\N	\N	\N	\N	\N	\N	\N	\N	17660	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Tungsten Charge XL
4073	2700	20929	5000	\N	\N	\N	\N	\N	\N	\N	\N	17648	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Antimatter Charge XL
4077	2700	20931	5000	\N	\N	\N	\N	\N	\N	\N	\N	17650	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Iridium Charge XL
4081	2700	20933	5000	\N	\N	\N	\N	\N	\N	\N	\N	17652	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Iron Charge XL
4085	2700	20935	5000	\N	\N	\N	\N	\N	\N	\N	\N	17654	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Lead Charge XL
4089	2700	20937	5000	\N	\N	\N	\N	\N	\N	\N	\N	17656	5000	29	2700000	\N	\N	\N	\N	\N	\N	Shadow Plutonium Charge XL
4093	2700	20939	5000	\N	\N	\N	\N	\N	\N	\N	\N	17658	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Thorium Charge XL
4086	2500	20925	5000	\N	\N	\N	\N	\N	\N	\N	\N	237	5000	29	2500000	\N	\N	\N	\N	\N	\N	Shadow Plutonium Charge L
3426	2500	14299	1	\N	\N	\N	\N	\N	\N	\N	\N	29	2500000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Social Adaptation Chip - Beta
3424	2500	14295	1	\N	\N	\N	\N	\N	\N	\N	\N	29	2500000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Ocular Filter - Beta
3418	2500	14298	1	\N	\N	\N	\N	\N	\N	\N	\N	29	2500000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Cybernetic Subprocessor - Beta
3420	2500	14297	1	\N	\N	\N	\N	\N	\N	\N	\N	29	2500000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Memory Augmentation - Beta
3422	2500	14296	1	\N	\N	\N	\N	\N	\N	\N	\N	29	2500000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Neural Boost - Beta
3565	2400	27361	5000	\N	\N	\N	\N	\N	\N	\N	\N	210	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Bloodclaw Light Missile
3561	2400	21740	5000	\N	\N	\N	\N	\N	\N	\N	\N	238	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Antimatter Charge L
3670	2400	22993	5000	\N	\N	\N	\N	\N	\N	\N	\N	238	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Antimatter Charge L
3673	2400	23003	5000	\N	\N	\N	\N	\N	\N	\N	\N	233	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Iridium Charge L
3676	2400	23007	5000	\N	\N	\N	\N	\N	\N	\N	\N	231	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Iron Charge L
3691	2400	22997	5000	\N	\N	\N	\N	\N	\N	\N	\N	236	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Uranium Charge L
3679	2400	23001	5000	\N	\N	\N	\N	\N	\N	\N	\N	234	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Lead Charge L
3682	2400	22995	5000	\N	\N	\N	\N	\N	\N	\N	\N	237	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Plutonium Charge L
3685	2400	22999	5000	\N	\N	\N	\N	\N	\N	\N	\N	235	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Thorium Charge L
3688	2400	23005	5000	\N	\N	\N	\N	\N	\N	\N	\N	232	5000	29	2400000	\N	\N	\N	\N	\N	\N	Federation Navy Tungsten Charge L
3594	2400	27387	5000	\N	\N	\N	\N	\N	\N	\N	\N	212	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Sabretooth Light Missile
3598	2400	23045	5000	\N	\N	\N	\N	\N	\N	\N	\N	235	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Thorium Charge L
3580	2400	23053	5000	\N	\N	\N	\N	\N	\N	\N	\N	231	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Iron Charge L
3590	2400	27381	5000	\N	\N	\N	\N	\N	\N	\N	\N	213	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Piranha Light Missile
3591	2400	23041	5000	\N	\N	\N	\N	\N	\N	\N	\N	237	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Plutonium Charge L
3569	2400	27371	5000	\N	\N	\N	\N	\N	\N	\N	\N	211	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Flameburst Light Missile
3584	2400	23047	5000	\N	\N	\N	\N	\N	\N	\N	\N	234	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Lead Charge L
3577	2400	23049	5000	\N	\N	\N	\N	\N	\N	\N	\N	233	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Iridium Charge L
3604	2400	23051	5000	\N	\N	\N	\N	\N	\N	\N	\N	232	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Tungsten Charge L
3607	2400	23043	5000	\N	\N	\N	\N	\N	\N	\N	\N	236	5000	29	2400000	\N	\N	\N	\N	\N	\N	Caldari Navy Uranium Charge L
3772	2400	21918	5000	\N	\N	\N	\N	\N	\N	\N	\N	200	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Phased Plasma L
3776	2400	21926	5000	\N	\N	\N	\N	\N	\N	\N	\N	196	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Proton L
3767	2400	21910	5000	\N	\N	\N	\N	\N	\N	\N	\N	195	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Nuclear L
3763	2400	21902	5000	\N	\N	\N	\N	\N	\N	\N	\N	199	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Fusion L
3780	2400	21935	5000	\N	\N	\N	\N	\N	\N	\N	\N	198	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Titanium Sabot L
3757	2400	21894	5000	\N	\N	\N	\N	\N	\N	\N	\N	201	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet EMP L
3882	2400	27475	5000	\N	\N	\N	\N	\N	\N	\N	\N	1830	5000	29	2400000	\N	\N	\N	\N	\N	\N	Arch Angel Obliterator F.O.F. Cruise Missile I
3906	2400	21252	10	\N	\N	\N	\N	\N	\N	\N	\N	17680	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Gamma XL
3910	2400	21244	10	\N	\N	\N	\N	\N	\N	\N	\N	17682	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Infrared XL
3914	2400	21242	10	\N	\N	\N	\N	\N	\N	\N	\N	17684	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Microwave XL
3918	2400	21254	10	\N	\N	\N	\N	\N	\N	\N	\N	17686	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Multifrequency XL
3922	2400	21240	10	\N	\N	\N	\N	\N	\N	\N	\N	17688	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Radio XL
3926	2400	21246	10	\N	\N	\N	\N	\N	\N	\N	\N	17690	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Standard XL
3930	2400	21248	10	\N	\N	\N	\N	\N	\N	\N	\N	17692	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Ultraviolet XL
3954	2400	27463	5000	\N	\N	\N	\N	\N	\N	\N	\N	1826	5000	29	2400000	\N	\N	\N	\N	\N	\N	Guristas Dragon F.O.F. Cruise Missile I
3934	2400	21250	10	\N	\N	\N	\N	\N	\N	\N	\N	17694	10	29	2400000	\N	\N	\N	\N	\N	\N	Blood Xray XL
4067	2400	27469	5000	\N	\N	\N	\N	\N	\N	\N	\N	1832	5000	29	2400000	\N	\N	\N	\N	\N	\N	Shadow Phoenix F.O.F. Cruise Missile I
4023	2400	20845	10	\N	\N	\N	\N	\N	\N	\N	\N	17680	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Gamma XL
4027	2400	20030	10	\N	\N	\N	\N	\N	\N	\N	\N	17682	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Infrared XL
4051	2400	20843	10	\N	\N	\N	\N	\N	\N	\N	\N	17694	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Xray XL
4047	2400	20841	10	\N	\N	\N	\N	\N	\N	\N	\N	17692	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Ultraviolet XL
4031	2400	20028	10	\N	\N	\N	\N	\N	\N	\N	\N	17684	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Microwave XL
4035	2400	20847	10	\N	\N	\N	\N	\N	\N	\N	\N	17686	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Multifrequency XL
4039	2400	20026	10	\N	\N	\N	\N	\N	\N	\N	\N	17688	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Radio XL
4043	2400	20032	10	\N	\N	\N	\N	\N	\N	\N	\N	17690	10	29	2400000	\N	\N	\N	\N	\N	\N	Sanshas Standard XL
4618	2400	28324	5000	\N	\N	\N	\N	\N	\N	\N	\N	194	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Carbonized Lead L
4621	2400	28332	5000	\N	\N	\N	\N	\N	\N	\N	\N	197	5000	29	2400000	\N	\N	\N	\N	\N	\N	Republic Fleet Depleted Uranium L
3901	2250	27481	5000	\N	\N	\N	\N	\N	\N	\N	\N	1820	5000	29	2250000	\N	\N	\N	\N	\N	\N	Blood Stalker F.O.F. Heavy Missile I
3761	2250	27501	5000	\N	\N	\N	\N	\N	\N	\N	\N	1822	5000	29	2250000	\N	\N	\N	\N	\N	\N	Republic Fleet Eradicator F.O.F. Heavy Missile I
3575	2250	27489	5000	\N	\N	\N	\N	\N	\N	\N	\N	1818	5000	29	2250000	\N	\N	\N	\N	\N	\N	Caldari Navy Hydra F.O.F. Heavy Missile I
3668	2250	27495	5000	\N	\N	\N	\N	\N	\N	\N	\N	1824	5000	29	2250000	\N	\N	\N	\N	\N	\N	Gallente Navy Hellhound F.O.F. Heavy Missile I
3508	2250	27483	5000	\N	\N	\N	\N	\N	\N	\N	\N	1820	5000	29	2250000	\N	\N	\N	\N	\N	\N	Amarr Navy Stalker F.O.F. Heavy Missile I
3513	2100	23095	10	\N	\N	\N	\N	\N	\N	\N	\N	251	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Ultraviolet M
3516	2100	23093	10	\N	\N	\N	\N	\N	\N	\N	\N	252	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Xray M
3510	2100	23097	10	\N	\N	\N	\N	\N	\N	\N	\N	250	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Standard M
3505	2100	23103	10	\N	\N	\N	\N	\N	\N	\N	\N	247	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Radio M
3502	2100	23089	10	\N	\N	\N	\N	\N	\N	\N	\N	254	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Multifrequency M
3499	2100	23101	10	\N	\N	\N	\N	\N	\N	\N	\N	248	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Microwave M
3496	2100	23099	10	\N	\N	\N	\N	\N	\N	\N	\N	249	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Infrared M
3492	2100	23091	10	\N	\N	\N	\N	\N	\N	\N	\N	253	10	29	2100000	\N	\N	\N	\N	\N	\N	Amarr Navy Gamma M
3957	2100	27451	5000	\N	\N	\N	\N	\N	\N	\N	\N	206	5000	29	2100000	\N	\N	\N	\N	\N	\N	Guristas Havoc Heavy Missile
3958	2100	27439	5000	\N	\N	\N	\N	\N	\N	\N	\N	209	5000	29	2100000	\N	\N	\N	\N	\N	\N	Guristas Scourge Heavy Missile
3959	2100	27433	5000	\N	\N	\N	\N	\N	\N	\N	\N	207	5000	29	2100000	\N	\N	\N	\N	\N	\N	Guristas Thunderbolt Heavy Missile
3960	2100	27445	5000	\N	\N	\N	\N	\N	\N	\N	\N	208	5000	29	2100000	\N	\N	\N	\N	\N	\N	Guristas Widowmaker Heavy Missile
4449	2000	17646	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Caldari CU-1 Nexus Chip
4444	2000	17794	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Amarr KIU-1 Nexus Chip
4468	2000	17849	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Beta Nexus Chip
4484	2000	17816	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Minmatar UUB Nexus Chip
4578	2000	17816	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Surplus Minmatar UUB Nexus Chip
4044	1875	20833	10	\N	\N	\N	\N	\N	\N	\N	\N	259	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Ultraviolet L
4040	1875	20024	10	\N	\N	\N	\N	\N	\N	\N	\N	258	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Standard L
4036	1875	20018	10	\N	\N	\N	\N	\N	\N	\N	\N	255	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Radio L
4032	1875	20839	10	\N	\N	\N	\N	\N	\N	\N	\N	262	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Multifrequency L
4048	1875	20835	10	\N	\N	\N	\N	\N	\N	\N	\N	260	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Xray L
4028	1875	20020	10	\N	\N	\N	\N	\N	\N	\N	\N	256	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Microwave L
4024	1875	20022	10	\N	\N	\N	\N	\N	\N	\N	\N	257	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Infrared L
4020	1875	20837	10	\N	\N	\N	\N	\N	\N	\N	\N	261	10	29	1875000	\N	\N	\N	\N	\N	\N	Sanshas Gamma L
3903	1875	21236	10	\N	\N	\N	\N	\N	\N	\N	\N	261	10	29	1875000	\N	\N	\N	\N	\N	\N	Blood Gamma L
3907	1875	21228	10	\N	\N	\N	\N	\N	\N	\N	\N	257	10	29	1875000	\N	\N	\N	\N	\N	\N	Blood Infrared L
3915	1875	21238	10	\N	\N	\N	\N	\N	\N	\N	\N	262	10	29	1875000	\N	\N	\N	\N	\N	\N	Blood Multifrequency L
3911	1875	21226	10	\N	\N	\N	\N	\N	\N	\N	\N	256	10	29	1875000	\N	\N	\N	\N	\N	\N	Blood Microwave L
3572	1850	27321	5000	\N	\N	\N	\N	\N	\N	\N	\N	2512	5000	29	1850000	\N	\N	\N	\N	\N	\N	Caldari Navy Gremlin Rocket
3589	1850	27327	5000	\N	\N	\N	\N	\N	\N	\N	\N	2516	5000	29	1850000	\N	\N	\N	\N	\N	\N	Caldari Navy Phalanx Rocket
3601	1850	27333	5000	\N	\N	\N	\N	\N	\N	\N	\N	266	5000	29	1850000	\N	\N	\N	\N	\N	\N	Caldari Navy Thorn Rocket
3931	1800	21234	10	\N	\N	\N	\N	\N	\N	\N	\N	260	10	29	1800000	\N	\N	\N	\N	\N	\N	Blood Xray L
3927	1800	21232	10	\N	\N	\N	\N	\N	\N	\N	\N	259	10	29	1800000	\N	\N	\N	\N	\N	\N	Blood Ultraviolet L
3923	1800	21230	10	\N	\N	\N	\N	\N	\N	\N	\N	258	10	29	1800000	\N	\N	\N	\N	\N	\N	Blood Standard L
3919	1800	21224	10	\N	\N	\N	\N	\N	\N	\N	\N	255	10	29	1800000	\N	\N	\N	\N	\N	\N	Blood Radio L
3883	1800	27499	5000	\N	\N	\N	\N	\N	\N	\N	\N	1822	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Eradicator F.O.F. Heavy Missile I
3878	1800	20729	5000	\N	\N	\N	\N	\N	\N	\N	\N	198	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Titanium Sabot L
3874	1800	20725	5000	\N	\N	\N	\N	\N	\N	\N	\N	196	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Proton L
3870	1800	20733	5000	\N	\N	\N	\N	\N	\N	\N	\N	200	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Phased Plasma L
3961	1800	21366	5000	\N	\N	\N	\N	\N	\N	\N	\N	238	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Antimatter Charge L
3965	1800	21356	5000	\N	\N	\N	\N	\N	\N	\N	\N	233	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Iridium Charge L
3955	1800	27487	5000	\N	\N	\N	\N	\N	\N	\N	\N	1818	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Hydra F.O.F. Heavy Missile I
3989	1800	21362	5000	\N	\N	\N	\N	\N	\N	\N	\N	236	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Uranium Charge L
3985	1800	21354	5000	\N	\N	\N	\N	\N	\N	\N	\N	232	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Tungsten Charge L
3981	1800	21360	5000	\N	\N	\N	\N	\N	\N	\N	\N	235	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Thorium Charge L
3977	1800	21364	5000	\N	\N	\N	\N	\N	\N	\N	\N	237	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Plutonium Charge L
3973	1800	21358	5000	\N	\N	\N	\N	\N	\N	\N	\N	234	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Lead Charge L
3969	1800	21352	5000	\N	\N	\N	\N	\N	\N	\N	\N	231	5000	29	1800000	\N	\N	\N	\N	\N	\N	Guristas Iron Charge L
3866	1800	20723	5000	\N	\N	\N	\N	\N	\N	\N	\N	195	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Nuclear L
3858	1800	20735	5000	\N	\N	\N	\N	\N	\N	\N	\N	201	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel EMP L
3854	1800	20727	5000	\N	\N	\N	\N	\N	\N	\N	\N	197	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Depleted Uranium L
3850	1800	20721	5000	\N	\N	\N	\N	\N	\N	\N	\N	194	5000	29	1800000	\N	\N	\N	\N	\N	\N	Arch Angel Carbonized Lead L
4068	1800	27493	5000	\N	\N	\N	\N	\N	\N	\N	\N	1824	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Hellhound F.O.F. Heavy Missile I
4070	1800	20927	5000	\N	\N	\N	\N	\N	\N	\N	\N	238	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Antimatter Charge L
4078	1800	20913	5000	\N	\N	\N	\N	\N	\N	\N	\N	231	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Iron Charge L
4074	1800	20917	5000	\N	\N	\N	\N	\N	\N	\N	\N	233	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Iridium Charge L
4082	1800	20919	5000	\N	\N	\N	\N	\N	\N	\N	\N	234	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Lead Charge L
4094	1800	20915	5000	\N	\N	\N	\N	\N	\N	\N	\N	232	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Tungsten Charge L
4090	1800	20921	5000	\N	\N	\N	\N	\N	\N	\N	\N	235	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Thorium Charge L
4098	1800	20923	5000	\N	\N	\N	\N	\N	\N	\N	\N	236	5000	29	1800000	\N	\N	\N	\N	\N	\N	Shadow Uranium Charge L
4685	1800	28768	10	\N	\N	\N	\N	\N	\N	\N	\N	25797	10	29	1200000	\N	\N	\N	\N	\N	\N	Sisters Radar Quest Probe
4686	1800	28762	10	\N	\N	\N	\N	\N	\N	\N	\N	25803	10	29	1200000	\N	\N	\N	\N	\N	\N	Sisters Ladar Quest Probe
4687	1800	28760	10	\N	\N	\N	\N	\N	\N	\N	\N	25799	10	29	1200000	\N	\N	\N	\N	\N	\N	Sisters Gravimetric Quest Probe
4688	1800	28764	10	\N	\N	\N	\N	\N	\N	\N	\N	25801	10	29	1200000	\N	\N	\N	\N	\N	\N	Sisters Magnetometric Quest Probe
4689	1800	28766	10	\N	\N	\N	\N	\N	\N	\N	\N	18588	10	29	1200000	\N	\N	\N	\N	\N	\N	Sisters Observator Deep Space Probe
3993	1680	27353	5000	\N	\N	\N	\N	\N	\N	\N	\N	210	5000	29	1680000	\N	\N	\N	\N	\N	\N	Guristas Bloodclaw Light Missile
3994	1680	27367	5000	\N	\N	\N	\N	\N	\N	\N	\N	211	5000	29	1680000	\N	\N	\N	\N	\N	\N	Guristas Flameburst Light Missile
3995	1680	27379	5000	\N	\N	\N	\N	\N	\N	\N	\N	213	5000	29	1680000	\N	\N	\N	\N	\N	\N	Guristas Piranha Light Missile
3996	1680	27383	5000	\N	\N	\N	\N	\N	\N	\N	\N	212	5000	29	1680000	\N	\N	\N	\N	\N	\N	Guristas Sabretooth Light Missile
3764	1600	21904	5000	\N	\N	\N	\N	\N	\N	\N	\N	191	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Fusion M
3768	1600	21912	5000	\N	\N	\N	\N	\N	\N	\N	\N	187	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Nuclear M
3777	1600	21928	5000	\N	\N	\N	\N	\N	\N	\N	\N	188	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Proton M
3773	1600	21922	5000	\N	\N	\N	\N	\N	\N	\N	\N	192	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Phased Plasma M
3781	1600	21937	5000	\N	\N	\N	\N	\N	\N	\N	\N	190	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Titanium Sabot M
3758	1600	21896	5000	\N	\N	\N	\N	\N	\N	\N	\N	193	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet EMP M
3599	1600	23031	5000	\N	\N	\N	\N	\N	\N	\N	\N	227	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Thorium Charge M
3581	1600	23039	5000	\N	\N	\N	\N	\N	\N	\N	\N	223	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Iron Charge M
3592	1600	23027	5000	\N	\N	\N	\N	\N	\N	\N	\N	229	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Plutonium Charge M
3578	1600	23035	5000	\N	\N	\N	\N	\N	\N	\N	\N	225	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Iridium Charge M
3585	1600	23033	5000	\N	\N	\N	\N	\N	\N	\N	\N	226	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Lead Charge M
3608	1600	23029	5000	\N	\N	\N	\N	\N	\N	\N	\N	228	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Uranium Charge M
3605	1600	23037	5000	\N	\N	\N	\N	\N	\N	\N	\N	224	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Tungsten Charge M
3692	1600	22981	5000	\N	\N	\N	\N	\N	\N	\N	\N	228	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Uranium Charge M
3689	1600	22989	5000	\N	\N	\N	\N	\N	\N	\N	\N	224	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Tungsten Charge M
3686	1600	22983	5000	\N	\N	\N	\N	\N	\N	\N	\N	227	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Thorium Charge M
3683	1600	22979	5000	\N	\N	\N	\N	\N	\N	\N	\N	229	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Plutonium Charge M
3680	1600	22985	5000	\N	\N	\N	\N	\N	\N	\N	\N	226	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Lead Charge M
3677	1600	22991	5000	\N	\N	\N	\N	\N	\N	\N	\N	223	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Iron Charge M
3674	1600	22987	5000	\N	\N	\N	\N	\N	\N	\N	\N	225	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Iridium Charge M
3671	1600	22977	5000	\N	\N	\N	\N	\N	\N	\N	\N	230	5000	29	1600000	\N	\N	\N	\N	\N	\N	Federation Navy Antimatter Charge M
3562	1600	23025	5000	\N	\N	\N	\N	\N	\N	\N	\N	230	5000	29	1600000	\N	\N	\N	\N	\N	\N	Caldari Navy Antimatter Charge M
4622	1600	28334	5000	\N	\N	\N	\N	\N	\N	\N	\N	189	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Depleted Uranium M
4619	1600	28326	5000	\N	\N	\N	\N	\N	\N	\N	\N	186	5000	29	1600000	\N	\N	\N	\N	\N	\N	Republic Fleet Carbonized Lead M
3507	1500	27507	5000	\N	\N	\N	\N	\N	\N	\N	\N	269	5000	29	1500000	\N	\N	\N	\N	\N	\N	Amarr Navy Seeker F.O.F. Light Missile I
3667	1500	27519	5000	\N	\N	\N	\N	\N	\N	\N	\N	1816	5000	29	1500000	\N	\N	\N	\N	\N	\N	Gallente Navy Firefly F.O.F. Light Missile I
3596	1500	27513	5000	\N	\N	\N	\N	\N	\N	\N	\N	1810	5000	29	1500000	\N	\N	\N	\N	\N	\N	Caldari Navy Serpent F.O.F. Light Missile I
3762	1500	27525	5000	\N	\N	\N	\N	\N	\N	\N	\N	1814	5000	29	1500000	\N	\N	\N	\N	\N	\N	Republic Fleet Exterminator F.O.F. Light Missile I
3511	1350	23079	10	\N	\N	\N	\N	\N	\N	\N	\N	242	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Standard S
3503	1350	23071	10	\N	\N	\N	\N	\N	\N	\N	\N	246	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Multifrequency S
3506	1350	23085	10	\N	\N	\N	\N	\N	\N	\N	\N	239	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Radio S
3493	1350	23073	10	\N	\N	\N	\N	\N	\N	\N	\N	245	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Gamma S
3497	1350	23081	10	\N	\N	\N	\N	\N	\N	\N	\N	241	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Infrared S
3500	1350	23083	10	\N	\N	\N	\N	\N	\N	\N	\N	240	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Microwave S
3517	1350	23075	10	\N	\N	\N	\N	\N	\N	\N	\N	244	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Xray S
3514	1350	23077	10	\N	\N	\N	\N	\N	\N	\N	\N	243	10	29	1350000	\N	\N	\N	\N	\N	\N	Amarr Navy Ultraviolet S
3570	1295	27315	5000	\N	\N	\N	\N	\N	\N	\N	\N	2514	5000	29	1295000	\N	\N	\N	\N	\N	\N	Caldari Navy Foxfire Rocket
3997	1295	27313	5000	\N	\N	\N	\N	\N	\N	\N	\N	2514	5000	29	1295000	\N	\N	\N	\N	\N	\N	Guristas Foxfire Rocket
3998	1295	27319	5000	\N	\N	\N	\N	\N	\N	\N	\N	2512	5000	29	1295000	\N	\N	\N	\N	\N	\N	Guristas Gremlin Rocket
3999	1295	27325	5000	\N	\N	\N	\N	\N	\N	\N	\N	2516	5000	29	1295000	\N	\N	\N	\N	\N	\N	Guristas Phalanx Rocket
4000	1295	27331	5000	\N	\N	\N	\N	\N	\N	\N	\N	266	5000	29	1295000	\N	\N	\N	\N	\N	\N	Guristas Thorn Rocket
3986	1200	21338	5000	\N	\N	\N	\N	\N	\N	\N	\N	224	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Tungsten Charge M
3990	1200	21346	5000	\N	\N	\N	\N	\N	\N	\N	\N	228	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Uranium Charge M
3970	1200	21336	5000	\N	\N	\N	\N	\N	\N	\N	\N	223	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Iron Charge M
3974	1200	21342	5000	\N	\N	\N	\N	\N	\N	\N	\N	226	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Lead Charge M
3978	1200	21348	5000	\N	\N	\N	\N	\N	\N	\N	\N	229	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Plutonium Charge M
3982	1200	21344	5000	\N	\N	\N	\N	\N	\N	\N	\N	227	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Thorium Charge M
3956	1200	27511	5000	\N	\N	\N	\N	\N	\N	\N	\N	1810	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Serpent F.O.F. Light Missile I
3966	1200	21340	5000	\N	\N	\N	\N	\N	\N	\N	\N	225	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Iridium Charge M
3962	1200	21350	5000	\N	\N	\N	\N	\N	\N	\N	\N	230	5000	29	1200000	\N	\N	\N	\N	\N	\N	Guristas Antimatter Charge M
3871	1200	20006	5000	\N	\N	\N	\N	\N	\N	\N	\N	192	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Phased Plasma M
3875	1200	19998	5000	\N	\N	\N	\N	\N	\N	\N	\N	188	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Proton M
3879	1200	20002	5000	\N	\N	\N	\N	\N	\N	\N	\N	190	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Titanium Sabot M
3884	1200	27523	5000	\N	\N	\N	\N	\N	\N	\N	\N	1814	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Exterminator F.O.F. Light Missile I
3902	1200	27505	5000	\N	\N	\N	\N	\N	\N	\N	\N	269	5000	29	1200000	\N	\N	\N	\N	\N	\N	Blood Seeker F.O.F. Light Missile I
3765	1200	21906	5000	\N	\N	\N	\N	\N	\N	\N	\N	183	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Fusion S
3769	1200	21914	5000	\N	\N	\N	\N	\N	\N	\N	\N	179	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Nuclear S
3774	1200	21924	5000	\N	\N	\N	\N	\N	\N	\N	\N	184	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Phased Plasma S
3778	1200	21931	5000	\N	\N	\N	\N	\N	\N	\N	\N	180	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Proton S
3782	1200	21939	5000	\N	\N	\N	\N	\N	\N	\N	\N	182	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Titanium Sabot S
3759	1200	21898	5000	\N	\N	\N	\N	\N	\N	\N	\N	185	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet EMP S
3851	1200	19994	5000	\N	\N	\N	\N	\N	\N	\N	\N	186	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Carbonized Lead M
3855	1200	20000	5000	\N	\N	\N	\N	\N	\N	\N	\N	189	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Depleted Uranium M
3859	1200	20008	5000	\N	\N	\N	\N	\N	\N	\N	\N	193	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel EMP M
3867	1200	19996	5000	\N	\N	\N	\N	\N	\N	\N	\N	187	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Nuclear M
3863	1200	20004	5000	\N	\N	\N	\N	\N	\N	\N	\N	191	5000	29	1200000	\N	\N	\N	\N	\N	\N	Arch Angel Fusion M
3586	1200	23017	5000	\N	\N	\N	\N	\N	\N	\N	\N	218	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Lead Charge S
3579	1200	23019	5000	\N	\N	\N	\N	\N	\N	\N	\N	217	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Iridium Charge S
3600	1200	23015	5000	\N	\N	\N	\N	\N	\N	\N	\N	219	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Thorium Charge S
3593	1200	23011	5000	\N	\N	\N	\N	\N	\N	\N	\N	221	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Plutonium Charge S
3582	1200	23023	5000	\N	\N	\N	\N	\N	\N	\N	\N	215	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Iron Charge S
3606	1200	23021	5000	\N	\N	\N	\N	\N	\N	\N	\N	216	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Tungsten Charge S
3609	1200	23013	5000	\N	\N	\N	\N	\N	\N	\N	\N	220	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Uranium Charge S
3672	1200	22961	5000	\N	\N	\N	\N	\N	\N	\N	\N	222	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Antimatter Charge S
3675	1200	22971	5000	\N	\N	\N	\N	\N	\N	\N	\N	217	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Iridium Charge S
3678	1200	22975	5000	\N	\N	\N	\N	\N	\N	\N	\N	215	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Iron Charge S
3681	1200	22969	5000	\N	\N	\N	\N	\N	\N	\N	\N	218	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Lead Charge S
3684	1200	22963	5000	\N	\N	\N	\N	\N	\N	\N	\N	221	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Plutonium Charge S
3687	1200	22967	5000	\N	\N	\N	\N	\N	\N	\N	\N	219	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Thorium Charge S
3690	1200	22973	5000	\N	\N	\N	\N	\N	\N	\N	\N	216	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Tungsten Charge S
3693	1200	22965	5000	\N	\N	\N	\N	\N	\N	\N	\N	220	5000	29	1200000	\N	\N	\N	\N	\N	\N	Federation Navy Uranium Charge S
3563	1200	23009	5000	\N	\N	\N	\N	\N	\N	\N	\N	222	5000	29	1200000	\N	\N	\N	\N	\N	\N	Caldari Navy Antimatter Charge S
4099	1200	20053	5000	\N	\N	\N	\N	\N	\N	\N	\N	228	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Uranium Charge M
4091	1200	20051	5000	\N	\N	\N	\N	\N	\N	\N	\N	227	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Thorium Charge M
4095	1200	20045	5000	\N	\N	\N	\N	\N	\N	\N	\N	224	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Tungsten Charge M
4083	1200	20049	5000	\N	\N	\N	\N	\N	\N	\N	\N	226	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Lead Charge M
4087	1200	20055	5000	\N	\N	\N	\N	\N	\N	\N	\N	229	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Plutonium Charge M
4075	1200	20047	5000	\N	\N	\N	\N	\N	\N	\N	\N	225	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Iridium Charge M
4079	1200	20043	5000	\N	\N	\N	\N	\N	\N	\N	\N	223	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Iron Charge M
4071	1200	20057	5000	\N	\N	\N	\N	\N	\N	\N	\N	230	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Antimatter Charge M
4069	1200	27517	5000	\N	\N	\N	\N	\N	\N	\N	\N	1816	5000	29	1200000	\N	\N	\N	\N	\N	\N	Shadow Firefly F.O.F. Light Missile I
4620	1200	28328	5000	\N	\N	\N	\N	\N	\N	\N	\N	178	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Carbonized Lead S
4623	1200	28336	5000	\N	\N	\N	\N	\N	\N	\N	\N	181	5000	29	1200000	\N	\N	\N	\N	\N	\N	Republic Fleet Depleted Uranium S
4021	1050	20829	10	\N	\N	\N	\N	\N	\N	\N	\N	253	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Gamma M
4025	1050	20014	10	\N	\N	\N	\N	\N	\N	\N	\N	249	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Infrared M
4029	1050	20012	10	\N	\N	\N	\N	\N	\N	\N	\N	248	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Microwave M
4049	1050	20827	10	\N	\N	\N	\N	\N	\N	\N	\N	252	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Xray M
4033	1050	20831	10	\N	\N	\N	\N	\N	\N	\N	\N	254	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Multifrequency M
4037	1050	20010	10	\N	\N	\N	\N	\N	\N	\N	\N	247	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Radio M
4041	1050	20016	10	\N	\N	\N	\N	\N	\N	\N	\N	250	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Standard M
4045	1050	20825	10	\N	\N	\N	\N	\N	\N	\N	\N	251	10	29	1050000	\N	\N	\N	\N	\N	\N	Sanshas Ultraviolet M
3908	1050	21212	10	\N	\N	\N	\N	\N	\N	\N	\N	249	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Infrared M
3912	1050	21210	10	\N	\N	\N	\N	\N	\N	\N	\N	248	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Microwave M
3916	1050	21222	10	\N	\N	\N	\N	\N	\N	\N	\N	254	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Multifrequency M
3920	1050	21450	10	\N	\N	\N	\N	\N	\N	\N	\N	247	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Radio M
3924	1050	21214	10	\N	\N	\N	\N	\N	\N	\N	\N	250	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Standard M
3928	1050	21216	10	\N	\N	\N	\N	\N	\N	\N	\N	251	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Ultraviolet M
3932	1050	21218	10	\N	\N	\N	\N	\N	\N	\N	\N	252	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Xray M
3904	1050	21220	10	\N	\N	\N	\N	\N	\N	\N	\N	253	10	29	1050000	\N	\N	\N	\N	\N	\N	Blood Gamma M
3905	1050	21206	10	\N	\N	\N	\N	\N	\N	\N	\N	245	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Gamma S
4309	1000	12213	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Pulse Laser Specialization
4306	1000	11083	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Beam Laser Specialization
4349	1000	12210	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Blaster Specialization
4346	1000	11082	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Railgun Specialization
4328	1000	20209	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Rocket Specialization
4329	1000	20210	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Standard Missile Specialization
4364	1000	11084	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Autocannon Specialization
4365	1000	12201	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Small Artillery Specialization
4072	900	20040	5000	\N	\N	\N	\N	\N	\N	\N	\N	222	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Antimatter Charge S
4080	900	19962	5000	\N	\N	\N	\N	\N	\N	\N	\N	215	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Iron Charge S
4076	900	19966	5000	\N	\N	\N	\N	\N	\N	\N	\N	217	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Iridium Charge S
4088	900	20038	5000	\N	\N	\N	\N	\N	\N	\N	\N	221	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Plutonium Charge S
4084	900	19968	5000	\N	\N	\N	\N	\N	\N	\N	\N	218	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Lead Charge S
4096	900	19964	5000	\N	\N	\N	\N	\N	\N	\N	\N	216	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Tungsten Charge S
4092	900	20034	5000	\N	\N	\N	\N	\N	\N	\N	\N	219	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Thorium Charge S
4100	900	20036	5000	\N	\N	\N	\N	\N	\N	\N	\N	220	5000	29	900000	\N	\N	\N	\N	\N	\N	Shadow Uranium Charge S
3963	900	21334	5000	\N	\N	\N	\N	\N	\N	\N	\N	222	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Antimatter Charge S
3967	900	21324	5000	\N	\N	\N	\N	\N	\N	\N	\N	217	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Iridium Charge S
3983	900	21328	5000	\N	\N	\N	\N	\N	\N	\N	\N	219	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Thorium Charge S
3979	900	21332	5000	\N	\N	\N	\N	\N	\N	\N	\N	221	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Plutonium Charge S
3975	900	21326	5000	\N	\N	\N	\N	\N	\N	\N	\N	218	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Lead Charge S
3971	900	21320	5000	\N	\N	\N	\N	\N	\N	\N	\N	215	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Iron Charge S
3991	900	21330	5000	\N	\N	\N	\N	\N	\N	\N	\N	220	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Uranium Charge S
3987	900	21322	5000	\N	\N	\N	\N	\N	\N	\N	\N	216	5000	29	900000	\N	\N	\N	\N	\N	\N	Guristas Tungsten Charge S
3880	900	19986	5000	\N	\N	\N	\N	\N	\N	\N	\N	182	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Titanium Sabot S
3876	900	19974	5000	\N	\N	\N	\N	\N	\N	\N	\N	180	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Proton S
3872	900	19990	5000	\N	\N	\N	\N	\N	\N	\N	\N	184	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Phased Plasma S
3864	900	19988	5000	\N	\N	\N	\N	\N	\N	\N	\N	183	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Fusion S
3868	900	19972	5000	\N	\N	\N	\N	\N	\N	\N	\N	179	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Nuclear S
3860	900	19992	5000	\N	\N	\N	\N	\N	\N	\N	\N	185	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel EMP S
3856	900	19976	5000	\N	\N	\N	\N	\N	\N	\N	\N	181	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Depleted Uranium S
3852	900	19970	5000	\N	\N	\N	\N	\N	\N	\N	\N	178	5000	29	900000	\N	\N	\N	\N	\N	\N	Arch Angel Carbonized Lead S
3423	750	13283	1	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Ocular Filter
3421	750	13285	1	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Neural Boost
3419	750	13284	1	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Memory Augmentation
3417	750	13287	1	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Cybernetic Subprocessor
3425	750	13286	1	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Limited Social Adaptation Chip
3933	675	21204	10	\N	\N	\N	\N	\N	\N	\N	\N	244	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Xray S
3929	675	21202	10	\N	\N	\N	\N	\N	\N	\N	\N	243	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Ultraviolet S
3925	675	21200	10	\N	\N	\N	\N	\N	\N	\N	\N	242	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Standard S
3921	675	21194	10	\N	\N	\N	\N	\N	\N	\N	\N	239	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Radio S
3917	675	21208	10	\N	\N	\N	\N	\N	\N	\N	\N	246	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Multifrequency S
3913	675	21196	10	\N	\N	\N	\N	\N	\N	\N	\N	240	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Microwave S
3909	675	21198	10	\N	\N	\N	\N	\N	\N	\N	\N	241	10	29	675000	\N	\N	\N	\N	\N	\N	Blood Infrared S
4046	675	20817	10	\N	\N	\N	\N	\N	\N	\N	\N	243	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Ultraviolet S
4042	675	19984	10	\N	\N	\N	\N	\N	\N	\N	\N	242	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Standard S
4038	675	19978	10	\N	\N	\N	\N	\N	\N	\N	\N	239	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Radio S
4034	675	20823	10	\N	\N	\N	\N	\N	\N	\N	\N	246	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Multifrequency S
4050	675	20819	10	\N	\N	\N	\N	\N	\N	\N	\N	244	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Xray S
4030	675	19980	10	\N	\N	\N	\N	\N	\N	\N	\N	240	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Microwave S
4026	675	19982	10	\N	\N	\N	\N	\N	\N	\N	\N	241	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Infrared S
4022	675	20821	10	\N	\N	\N	\N	\N	\N	\N	\N	245	10	29	675000	\N	\N	\N	\N	\N	\N	Sanshas Gamma S
4467	500	17848	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Gamma Nexus Chip
4483	500	17815	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Minmatar UUA Nexus Chip
4445	500	17795	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Amarr MIY-1 Nexus Chip
4450	500	17647	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Caldari BY-1 Nexus Chip
3833	500	24597	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Ammatar Mandate Starbase Charter
3834	500	24596	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Khanid Kingdom Starbase Charter
3784	500	24595	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Minmatar Republic Starbase Charter
3518	500	24592	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Amarr Empire Starbase Charter
3694	500	24594	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Gallente Federation Starbase Charter
3612	500	24593	100	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Caldari State Starbase Charter
4579	500	17815	1	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	\N	Surplus Minmatar UUA Nexus Chip
4426	375	27103	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Yeti' BX-0
4423	375	27151	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HY-0
4504	375	27113	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' FY-0
4506	375	27115	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' HY-0
4513	375	27193	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPG-0
4511	375	27191	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPF-0
4527	375	27157	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPA-0
4534	375	27164	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPD-0
4532	375	27162	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPC-0
4530	375	27160	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPB-0
4515	375	27195	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Prospector' PPH-0
4536	375	27166	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Poteque Pharmaceuticals 'Consul' PPE-0
4412	375	27185	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' K40
4410	375	27182	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' J40
4408	375	27180	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' I40
4417	375	27240	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Alchemist' ZA-0
4420	375	27102	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Highwall' HX-0
4403	375	27175	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' H40
4400	375	27170	1	\N	\N	\N	\N	\N	\N	\N	\N	29	150000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Beancounter' F40
4283	375	27237	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KTB-25
4114	375	27075	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' AX-0
4115	375	27081	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' CX-0
4116	375	27084	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' SX-0
4117	375	27087	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' MX-0
4118	375	27090	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co 'Gunslinger' LX-0
4136	375	27111	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' EY-0
4130	375	27097	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' CY-0
4131	375	27098	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' DY-0
4132	375	27099	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' AY-0
4133	375	27100	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' GY-0
4134	375	27101	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Eifyr and Co. 'Rogue' MY-0
4147	375	27077	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G0-Delta
4148	375	27079	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G0-Beta
4149	375	27082	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G0-Alpha
4150	375	27085	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G0-Gamma
4151	375	27088	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Lancer' G0-Epsilon
4162	375	27070	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET10
4163	375	27071	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET20
4164	375	27072	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET30
4165	375	27073	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET40
4166	375	27074	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Noble' ZET50
4177	375	27076	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGA10
4178	375	27078	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGC10
4179	375	27083	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGS10
4180	375	27086	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGM10
4181	375	27089	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZGL10
4192	375	27092	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMC10
4193	375	27093	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZML10
4194	375	27094	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMA10
4195	375	27095	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMS10
4196	375	27096	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Deadeye' ZMM10
4199	375	27080	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KZA500
4211	375	27104	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KUA500
4212	375	27105	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KVA500
4213	375	27106	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KXA500
4214	375	27107	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KYA500
4228	375	27249	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMF500
4226	375	27246	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZME500
4224	375	27244	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMD500
4202	375	27091	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gnome' KTA10
4246	375	27117	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CC2
4238	375	27259	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMU500
4236	375	27257	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMT500
4234	375	27255	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMR500
4232	375	27253	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMN500
4230	375	27251	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Snapshot' ZMH500
4256	375	27127	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' PG2
4254	375	27125	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' GU2
4252	375	27123	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EP2
4248	375	27119	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' CR2
4249	375	27120	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Inherent Implants 'Squire' EE2
4281	375	27235	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KSB-25
4279	375	27233	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KRB-25
4277	375	27231	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KQB-25
4275	375	27229	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KPB-25
4273	375	27226	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KOB-25
4270	375	27143	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KMB-25
4268	375	27131	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KNB-25
4266	375	27129	1	\N	\N	\N	\N	\N	\N	\N	\N	29	375000	\N	\N	\N	\N	\N	\N	\N	\N	Hardwiring - Zainou 'Gypsy' KLB-25
4790	250	28671	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Blue Pill Booster Blueprint
4791	250	28673	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Crash Booster Blueprint
4792	250	28675	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Drop Booster Blueprint
4793	250	28677	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Exile Booster Blueprint
4794	250	28677	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	DUPLICATE Synth Exile Booster Blueprint
4795	250	28681	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Mindflood Booster Blueprint
4796	250	28679	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Frentix Booster Blueprint
4797	250	28683	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth X-Instinct Booster Blueprint
4798	250	28685	1000	\N	\N	\N	\N	\N	\N	\N	\N	29	750000	\N	\N	\N	\N	\N	\N	\N	\N	Synth Sooth Sayer Booster Blueprint
\.

ALTER TABLE ONLY public."agtOfferDetails"
    ADD CONSTRAINT "agtOfferDetails_pkey" PRIMARY KEY ("contentID");
