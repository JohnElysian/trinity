--
-- PostgreSQL database dump
--

\restrict xYW2GyerCgwi8lOFesdbsGdXRheXHOl5fGAyUEDsvwJeRzWiytnw5OxGiip4jLj

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invGroups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invGroups" (
    "groupID" integer NOT NULL,
    "categoryID" integer,
    "groupName" text,
    description text,
    "graphicID" integer,
    "useBasePrice" integer,
    "allowManufacture" integer,
    "allowRecycler" integer,
    anchored integer,
    anchorable integer,
    "fittableNonSingleton" integer,
    published integer
);


--
-- Data for Name: invGroups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invGroups" ("groupID", "categoryID", "groupName", description, "graphicID", "useBasePrice", "allowManufacture", "allowRecycler", anchored, anchorable, "fittableNonSingleton", published) FROM stdin;
0	0	#System		\N	0	1	1	0	0	0	0
1	1	Character		1	0	1	1	0	0	0	0
2	1	Corporation		2	0	1	1	0	0	0	0
3	2	Region		4	0	1	1	0	0	0	0
4	2	Constellation		5	0	1	1	0	0	0	0
5	2	Solar System		6	0	1	1	0	0	0	0
6	2	Sun		8	0	1	1	0	0	0	0
7	2	Planet		9	0	1	1	0	0	0	0
8	2	Moon		10	0	1	1	0	0	0	0
9	2	Asteroid Belt		11	0	1	1	0	0	0	0
10	2	Stargate		12	0	1	1	0	0	0	0
11	2	Asteroid OLD		15	0	1	1	1	0	0	0
12	2	Cargo Container		16	0	1	1	0	0	0	1
13	2	Ring		0	0	1	1	0	0	0	0
14	2	Biomass	Corpse of human. Can be sold for clone production.	0	0	1	1	0	0	0	1
15	3	Station		17	0	1	1	1	0	0	0
16	3	Station Services		18	0	1	1	0	0	0	0
17	4	Money		21	0	1	1	0	0	0	0
18	4	Mineral		399	1	1	1	0	0	0	1
19	1	Faction		\N	0	1	1	0	0	0	0
20	4	Drug	Drug	32	0	1	1	0	0	0	0
23	5	Clone		34	0	1	1	0	0	0	0
24	5	Voucher		37	0	1	1	0	0	0	0
25	6	Frigate		38	0	1	1	0	0	0	1
26	6	Cruiser		41	0	1	1	0	0	0	1
27	6	Battleship		43	0	1	1	0	0	0	1
28	6	Industrial		51	0	1	1	0	0	0	1
29	6	Capsule		73	0	1	1	0	0	0	0
30	6	Titan	The collective name for these behemoths is Titans, the largest spacefaring vessels ever constructed. The sheer cost in resources, manpower and time, as well as the necessary technological knowledge, makes construction of a Titan-class vessel a venture only empires can usually fathom. Some of these mammoth vessels have taken decades to assemble. Many are over a century old themselves, and the three mammoth Jovian motherships, the first Titans, have origins pre-dating modern space travel. They are	64	0	1	1	0	0	0	1
31	6	Shuttle		0	0	1	1	0	0	0	1
32	1	Alliance		2	0	1	1	0	0	0	0
38	7	Shield Extender		82	0	1	1	0	0	0	1
39	7	Shield Recharger		83	0	1	1	0	0	0	1
40	7	Shield Booster		84	0	1	1	0	0	0	1
41	7	Shield Transporter		86	0	1	1	0	0	0	1
43	7	Capacitor Recharger		90	0	1	1	0	0	0	1
46	7	Afterburner		96	0	1	1	0	0	0	1
47	7	Cargo Scanner		106	0	1	1	0	0	0	1
48	7	Ship Scanner		107	0	1	1	0	0	0	1
49	7	Survey Scanner		108	0	1	1	0	0	0	1
52	7	Warp Scrambler		111	0	1	1	0	0	0	1
53	7	Energy Weapon		359	0	1	1	0	0	0	1
54	7	Mining Laser	Mining Laser	138	0	1	1	0	0	0	1
55	7	Projectile Weapon		385	0	1	1	0	0	0	1
56	7	Missile Launcher		168	0	1	1	0	0	0	0
57	7	Shield Power Relay	These module usually act on the power and/or capacitor requirements of modules.	0	0	1	1	0	0	0	1
59	7	Gyrostabilizer	Uses gyroscopes and inertial dampeners to reduce recoil and stabilize the weapon while firing	0	0	1	1	0	0	0	1
60	7	Damage Control	Reinforcement are modules that increase the "armorHP" of some module group or specific module type. It typically only defines a passive effect.	0	0	1	1	0	0	0	1
61	7	Capacitor Battery	Supplement the ships builtin power battery.	0	0	1	1	0	0	0	1
62	7	Armor Repair Unit		0	0	1	1	0	0	0	1
63	7	Hull Repair Unit		0	0	1	1	0	0	0	1
65	7	Stasis Web	Reduces max speed of a target ship.	0	0	1	1	0	0	0	1
67	7	Energy Transfer Array	Transfers some of our energy to the target ships.	0	0	1	1	0	0	0	1
68	7	Energy Vampire		0	0	1	1	0	0	0	1
71	7	Energy Destabilizer	Target ship loses power.	0	0	1	1	0	0	0	1
72	7	Smart Bomb	Smart Bomb	0	0	1	1	0	0	0	1
74	7	Hybrid Weapon	Hybrid	370	0	1	1	0	0	0	1
76	7	Capacitor Booster	In times of danger and need, being able to boost your power supply can save your skin.  Don't leave home without one of these.  And don't forget to feed it.	1031	0	1	1	0	0	0	1
77	7	Shield Hardener	Increases the resistance of the shield to damages of specified types.	0	0	1	1	0	0	0	1
78	7	Reinforced Bulkhead		0	0	1	1	0	0	0	1
80	7	ECM Burst	Clears all targets on all ships(excluding self) wihin range.	0	0	1	1	0	0	0	1
82	7	Passive Targeting System	Targets ship quietly (as in does not alert other ship to the fact rhat its been targeted).	0	0	1	1	0	0	0	1
83	8	Ammo	Ammo	171	0	1	1	0	0	1	1
84	8	Missile		182	0	1	1	0	0	1	1
85	8	Hybrid Ammo	Raw minerals	1325	0	1	1	0	0	1	1
86	8	Frequency Crystal	the frequency of Laser weapon	1142	0	1	1	0	0	1	1
87	8	Capacitor Booster Charge	Capacitor Booster Charge	1033	0	1	1	0	0	1	1
88	8	Defender Missile		192	0	1	1	0	0	1	1
89	8	Torpedo	Torrpedo	1349	0	1	1	0	0	1	1
90	8	Bomb	Remote triggered. Have no internal Thrust or Guidance. Are dropped at 80% of ship current speed	3278	0	1	1	0	0	1	1
92	8	Mine		0	0	1	1	0	0	0	0
94	10	Trading		195	0	1	1	0	0	0	0
95	10	Trade Session		196	0	1	1	0	0	0	0
96	7	Automated Targeting System	Targets all hostile ships within range.	0	0	1	1	0	0	0	1
97	18	Proximity Drone	ProximityDrone	0	0	1	1	0	0	0	0
98	7	Armor Coating		0	0	1	1	0	0	0	1
99	11	Sentry Gun	Protecting the weak and upholding the law, these shining examples of fabrication maintain the peace.	0	0	1	1	1	0	0	0
100	18	Combat Drone		0	0	1	1	0	0	0	1
101	18	Mining Drone	Mines.	0	0	1	1	0	0	0	1
104	9	Clone Blueprint		34	1	1	1	0	0	0	1
105	9	Frigate Blueprint		38	1	1	1	0	0	0	1
106	9	Cruiser Blueprint		41	1	1	1	0	0	0	1
107	9	Battleship Blueprint		43	1	1	1	0	0	0	1
108	9	Industrial Blueprint		51	1	1	1	0	0	0	1
109	9	Capsule Blueprint		73	1	1	1	0	0	0	1
110	9	Titan Blueprint		64	1	1	1	0	0	0	1
111	9	Shuttle Blueprint		0	1	1	1	0	0	0	1
118	9	Shield Extender Blueprint		82	1	1	1	0	0	0	1
119	9	Shield Recharger Blueprint		83	1	1	1	0	0	0	1
120	9	Shield Booster Blueprint		84	1	1	1	0	0	0	1
121	9	Shield Transporter Blueprint		86	1	1	1	0	0	0	1
123	9	Capacitor Recharger Blueprint		90	1	1	1	0	0	0	1
126	9	Afterburner Blueprint		96	1	1	1	0	0	0	1
127	9	Cargo Scanner Blueprint		106	1	1	1	0	0	0	1
128	9	Ship Scanner Blueprint		107	1	1	1	0	0	0	1
129	9	Survey Scanner Blueprint		108	1	1	1	0	0	0	1
130	9	ECM Blueprint		109	1	1	1	0	0	0	1
131	9	ECCM Blueprint		110	1	1	1	0	0	0	1
132	9	Warp Scrambler Blueprint		111	1	1	1	0	0	0	1
133	9	Energy Weapon Blueprint		113	1	1	1	0	0	0	1
134	9	Mining Laser Blueprint		138	1	1	1	0	0	0	1
135	9	Projectile Weapon Blueprint		156	1	1	1	0	0	0	1
136	9	Missile Launcher Blueprint		168	1	1	1	0	0	0	1
137	9	Power Manager Blueprint		0	1	1	1	0	0	0	1
139	9	Fast Loader Blueprint		0	1	1	1	0	0	0	1
140	9	Damage Control Blueprint		0	1	1	1	0	0	0	1
141	9	Capacitor Battery Blueprint		0	1	1	1	0	0	0	1
142	9	Armor Repair Unit Blueprint		0	1	1	1	0	0	0	1
143	9	Hull Repair Unit Blueprint		0	1	1	1	0	0	0	1
145	9	Stasis Web Blueprint		0	1	1	1	0	0	0	1
147	9	Energy Transfer Array Blueprint		0	1	1	1	0	0	0	1
148	9	Energy Vampire Blueprint		0	1	1	1	0	0	0	1
151	9	Energy Destabilizer Blueprint		0	1	1	1	0	0	0	1
152	9	Smart Bomb Blueprint		0	1	1	1	0	0	0	1
154	9	Hybrid Weapon Blueprint		0	1	1	1	0	0	0	1
156	9	Capacitor Booster Blueprint		0	1	1	1	0	0	0	1
157	9	Shield Hardener Blueprint		0	1	1	1	0	0	0	1
158	9	Hull Mods Blueprint		0	1	1	1	0	0	0	1
160	9	ECM Burst Blueprint		0	1	1	1	0	0	0	1
161	9	Passive Targeting System Blueprint		0	1	1	1	0	0	0	1
162	9	Automated Targeting System Blueprint		0	1	1	1	0	0	0	1
163	9	Armor Coating Blueprint		0	1	1	1	0	0	0	1
165	9	Projectile Ammo Blueprint		171	1	1	1	0	0	0	1
166	9	Missile Blueprint		182	1	1	1	0	0	0	1
167	9	Hybrid Ammo Blueprint		179	1	1	1	0	0	0	1
168	9	Frequency Crystal Blueprint		0	1	1	1	0	0	0	1
169	9	Capacitor Booster Charge Blueprint		0	1	1	1	0	0	0	1
170	9	Defender Missile Blueprint		0	1	1	1	0	0	0	1
172	9	Bomb Blueprint		0	1	1	1	0	0	0	1
174	9	Mine Blueprint		0	1	1	1	0	0	0	1
175	9	Proximity Drone Blueprint		0	1	1	1	0	0	0	1
176	9	Combat Drone Blueprint		0	1	1	1	0	0	0	1
177	9	Mining Drone Blueprint		0	1	1	1	0	0	0	1
178	9	Drug Blueprint		194	1	1	1	0	0	0	1
180	11	Protective Sentry Gun	Defends all within its observation range who get attacked.	\N	0	1	1	0	0	0	0
182	11	Police Drone	Ho hum.	\N	0	1	1	0	0	0	0
185	11	Pirate Drone		0	0	1	1	0	0	0	0
186	2	Wreck	Shipwrecks and stuff like that	0	0	1	1	0	0	0	0
190	14	Bloodline Bonus	Bonuses for the given bloodlines.	0	0	1	1	0	0	0	0
191	14	Physical Benefit	Physical Benefit	0	0	1	1	0	0	0	0
192	14	Physical Handicap	Physical Handicap.	0	0	1	1	0	0	0	0
193	14	Phobia Handicap	Phobia handicap	0	0	1	1	0	0	0	0
194	14	Social Handicap	Social handicap.	0	0	1	1	0	0	0	0
195	14	Amarr Education	Bonuses for having various Amarr educations.	0	0	1	1	0	0	0	0
196	14	Caldari Education	Bonuses for having various Caldari educations.	0	0	1	1	0	0	0	0
197	14	Gallente Education	Bonuses for having a variety of Gallente educations.	0	0	1	1	0	0	0	0
198	14	Minmatar Education	A variety of bonuses for having a Minmatar education.	0	0	1	1	0	0	0	0
199	14	Career Bonus	Bonus for taking a career or some sh1t.	0	0	1	1	0	0	0	0
201	7	ECM	Electronic Countermeasure	0	0	1	1	0	0	0	1
202	7	ECCM		0	0	1	1	0	0	0	1
203	7	Sensor Backup Array	An upgrade to the electronics capacilities of the ship 1.	0	0	1	1	0	0	0	1
205	7	Heat Sink		0	0	1	1	0	0	0	1
208	7	Remote Sensor Damper	Electronic Warfare System 2	105	0	1	1	0	0	0	1
209	7	Tracking Link	Tracking Link	3346	0	1	1	0	0	0	1
210	7	Signal Amplifier		0	0	1	1	0	0	0	1
211	7	Tracking Enhancer		0	0	1	1	0	0	0	1
212	7	Sensor Booster	Boosts the Range, Speed and Max targets of electronics module	74	0	1	1	0	0	0	1
213	7	Tracking Computer	On command adjust the effectiveness of the sensor functions of the electronics of the users ship.	3346	0	1	1	0	0	0	1
218	9	Heat Sink Blueprint		0	1	1	1	0	0	0	1
223	9	Sensor Booster Blueprint		0	1	1	1	0	0	0	1
224	9	Tracking Computer Blueprint		0	1	1	1	0	0	0	1
225	7	Cheat Module Group	For limited distribution.  Speed up testing.	0	0	1	1	0	0	0	0
226	2	Large Collidable Object		\N	0	1	1	1	0	0	0
227	2	Cloud		0	0	1	1	0	0	0	0
237	6	Rookie ship	These are the rookie frigates, read: n00be ships yo!	0	0	1	1	0	0	0	0
255	16	Gunnery		\N	1	1	1	0	0	0	1
256	16	Missile Launcher Operation		\N	1	1	1	0	0	0	1
257	16	Spaceship Command		\N	1	1	1	0	0	0	1
258	16	Leadership		\N	1	1	1	0	0	0	1
266	16	Corporation Management		\N	1	1	1	0	0	0	1
267	16	Learning		\N	1	1	1	0	0	0	1
268	16	Industry		\N	1	1	1	0	0	0	1
269	16	Mechanic		\N	1	1	1	0	0	0	1
270	16	Science		\N	1	1	1	0	0	0	1
271	16	Engineering		\N	1	1	1	0	0	0	1
272	16	Electronics		\N	1	1	1	0	0	0	1
273	16	Drones		\N	1	1	1	0	0	0	1
274	16	Trade		\N	1	1	1	0	0	0	1
275	16	Navigation		\N	1	1	1	0	0	0	1
278	16	Social		\N	1	1	1	0	0	0	1
279	11	LCO Drone		0	0	1	1	0	0	0	0
280	17	General		0	1	1	1	0	0	0	1
281	17	Frozen		0	1	1	1	0	0	0	1
282	17	Radioactive		0	1	1	1	0	0	0	1
283	17	Livestock		0	1	1	1	0	0	0	1
284	17	Biohazard		0	1	1	1	0	0	0	1
285	7	CPU Enhancer		0	0	1	1	0	0	0	1
286	11	Tutorial Drone		0	0	1	1	0	0	0	0
287	11	Rogue Drone	These drones can be found by wrecks, mineral deposits and various other hang-outs for junk metal gone bad.	\N	0	1	1	0	0	0	0
288	11	Faction Drone		0	0	0	1	0	0	0	0
289	7	Projected ECCM	ECCM Projector	\N	0	1	1	0	0	0	1
290	7	Remote Sensor Booster	Electronic Warfare System 2	74	0	1	1	0	0	0	1
291	7	Tracking Disrupter		1639	0	1	1	0	0	0	1
295	7	Shield Amplifier		82	0	1	1	0	0	0	1
296	9	Shield Amplifier Blueprint		82	1	1	1	0	0	0	1
297	11	Convoy		0	0	1	1	0	0	0	0
298	11	Convoy Drone		0	0	1	1	0	0	0	0
299	18	Repair Drone	Repair drones reapair the structure and armor of ships	0	0	1	1	0	0	0	1
300	20	Cyberimplant		0	1	0	1	0	0	0	1
301	11	Concord Drone		0	0	0	1	0	0	0	0
302	7	Magnetic Field Stabilizer		0	0	1	1	0	0	0	1
303	20	Booster		0	0	0	1	0	0	0	1
304	20	DNA Mutator		0	0	1	1	0	0	0	0
305	2	Comet		0	0	1	1	0	0	0	0
306	11	Spawn Container		0	0	0	1	1	0	0	0
307	2	Construction Platform		0	0	1	1	0	1	0	1
308	7	Countermeasure Launcher		0	0	1	1	0	0	0	0
309	7	Autopilot		0	0	1	1	0	0	0	0
310	2	Beacon	This is a group for Beacons. Beacons are fixed global objects with no functionality	0	0	1	1	1	0	0	0
311	23	Refining Array		0	1	1	1	0	1	0	1
312	2	Planetary Cloud		0	0	1	1	0	0	0	0
313	17	Drugs	This group contains commodities that are drugs or 'boosters'.	0	1	1	1	0	0	0	1
314	17	Miscellaneous	Miscellaneos special mission items that should not be on the market and not available from random missions.	0	1	1	1	0	0	0	1
315	7	Warp Core Stabilizer		0	0	1	1	0	0	0	1
316	7	Gang Coordinator		0	0	1	1	0	0	0	1
317	7	Computer Interface Node		0	0	1	1	0	0	0	0
318	2	Landmark	Landmarks are used on the map for locations that are not physical objects neccesarily, such as important areas and regions, political borders and so on.	0	0	1	1	0	0	0	0
319	11	Large Collidable Structure		0	0	0	1	1	0	0	0
321	7	Shield Disruptor		0	0	1	1	0	0	0	1
323	11	Billboard		0	0	0	1	1	0	0	0
324	6	Assault Ship	Da Leet Frigates	0	0	1	1	0	0	0	1
325	7	Armor Repair Projector		0	0	1	1	0	0	0	1
326	7	Armor Plating Energized		0	0	1	1	0	0	0	1
328	7	Armor Hardener		0	0	1	1	0	0	0	1
329	7	Armor Reinforcer		0	0	1	1	0	0	0	1
330	7	Cloaking Device		0	0	0	1	0	0	0	1
332	17	Tool	Tools used in manufacturing and Research	0	0	1	1	0	0	0	1
333	17	Datacores		0	0	1	1	0	0	0	1
334	17	Construction Components	components for use i item construction	0	0	1	1	0	0	0	1
335	11	Temporary Cloud		0	0	0	1	1	0	0	0
336	2	Mobile Sentry Gun		0	0	1	1	0	1	0	0
337	11	Mission Drone		0	0	0	1	0	0	0	0
338	7	Shield Boost Amplifier		0	0	1	1	0	0	0	1
339	7	Auxiliary Power Core		0	0	1	1	0	0	0	1
340	2	Secure Cargo Container		0	0	1	1	0	1	0	1
341	7	Signature Scrambling		0	0	1	1	0	0	0	0
342	9	Anti Warp Scrambler Blueprint		0	1	0	1	0	0	0	1
343	9	Tracking Disruptor Blueprint		0	1	0	1	0	0	0	1
344	9	Tracking Enhancer Blueprint		0	1	0	1	0	0	0	1
345	9	Tracking Link Blueprint		0	1	0	1	0	0	0	1
346	9	Co-Processor Blueprint		0	1	0	1	0	0	0	1
347	9	Signal Amplifier Blueprint		0	1	0	1	0	0	0	1
348	9	Armor Hardener Blueprint		0	1	0	1	0	0	0	1
349	9	Armor Reinforcer Blueprint		0	1	0	1	0	0	0	1
350	9	Armor Repair Projector Blueprint		0	1	0	1	0	0	0	1
352	9	Auxiliary Power Core Blueprint		0	1	0	1	0	0	0	1
353	7	GM Modules		0	0	0	1	0	0	0	0
355	17	Refinables	Group for mineral compounds and alloys that can be refined into valuable minerals.	0	0	1	1	0	0	0	1
356	9	Tool Blueprint		0	1	1	1	0	0	0	1
357	7	DroneBayExpander		0	0	1	1	0	0	0	0
358	6	Heavy Assault Ship		0	0	1	1	0	0	0	1
360	9	Shield Boost Amplifier Blueprint		0	1	1	1	0	0	0	1
361	22	Mobile Warp Disruptor	Self powered warp disruptors.  Do not require a control tower.	0	0	1	1	0	1	0	1
363	23	Ship Maintenance Array		0	1	1	1	0	1	0	1
364	23	Mobile Storage		0	0	1	1	0	1	0	0
365	23	Control Tower		0	1	1	1	0	1	0	1
366	2	Warp Gate		0	0	1	1	1	0	0	0
367	7	Ballistic Control system		0	0	1	1	0	0	0	1
368	2	Global Warp Disruptor	Prevents warping into the radius it covers.	0	0	1	1	1	0	0	0
369	17	Ship Logs		0	1	1	1	0	0	0	1
370	17	Criminal Tags	Items such as Dog Tags that NPC pirates drop.	0	1	1	1	0	0	0	1
371	9	Mobile Warp Disruptor Blueprint		0	1	1	1	0	0	0	1
372	8	Advanced Autocannon Ammo		1296	0	1	1	0	0	1	1
373	8	Advanced Railgun Ammo		1321	0	1	1	0	0	1	1
374	8	Advanced Beam Laser Crystal		1145	0	1	1	0	0	1	1
375	8	Advanced Pulse Laser Crystal		1140	0	1	1	0	0	1	1
376	8	Advanced Artillery Ammo		1292	0	1	1	0	0	1	1
377	8	Advanced Blaster Ammo		1317	0	1	1	0	0	1	1
378	7	Cruise Control		0	0	1	1	0	0	0	0
379	7	Target Painter		0	0	1	1	0	0	0	1
380	6	Transport Ship		0	0	1	1	0	0	0	1
381	6	Elite Battleship		0	1	1	1	0	0	0	0
382	2	Shipping Crates	Shipping Crate	0	0	1	1	0	0	0	0
383	11	Destructible Sentry Gun	Sentry guns inside scenarios, usually owned by pirate factions, that can be destroyed by players.	0	0	1	1	1	0	0	0
384	8	Light Missile	Light Missile Charges	192	0	1	1	0	0	1	1
385	8	Heavy Missile	Heavy Missile Charges	188	0	1	1	0	0	1	1
386	8	Cruise Missile		182	0	1	1	0	0	1	1
387	8	Rocket		1352	0	1	1	0	0	1	1
394	8	FoF Light Missile		1336	0	1	1	0	0	1	1
395	8	FoF Heavy Missile		1339	0	1	1	0	0	1	1
396	8	FoF Cruise Missile		1344	0	1	1	0	0	1	1
397	23	Assembly Array	Deployable Assembly Array	0	1	1	1	0	1	0	1
400	9	Ballistic Control System Blueprint		0	1	1	1	0	0	0	1
401	9	Cloaking Device Blueprint		0	1	1	1	0	0	0	1
404	23	Silo	Used to store or provide resources of a specific type.	0	1	1	1	0	1	0	1
405	7	Anti Cloaking Pulse	Broadcast a signal in all directions within a limited range that cause all the cloaked objects within it to decloak.	0	0	1	1	0	0	0	0
406	7	Smartbomb Supercharger	Modules that boost the Damage of Smartbombs	0	0	1	1	0	0	0	0
407	7	Drone Control Unit		0	0	1	1	0	0	0	1
408	9	Drone Control Unit Blueprint		0	1	1	1	0	0	0	1
409	17	Empire Insignia Drops	The insignia drops are implemented to replace the "bounty" feature for Empire mission drones, such as Navy ships.  Insignias are traded in to agents for money (will be implemented in Shiva).	0	1	1	1	0	0	0	1
410	9	Anti Cloaking Pulse Blueprint		0	1	1	1	0	0	0	1
411	2	Force Field	A spherical barrier, maybe placed around something.	0	0	1	1	1	0	0	0
413	23	Mobile Laboratory		0	1	1	1	0	1	0	1
414	23	Mobile Power Core		0	0	1	1	0	1	0	0
416	23	Moon Mining		0	1	1	1	0	1	0	1
417	23	Mobile Missile Sentry		0	1	1	1	0	1	0	1
418	23	Mobile Shield Generator		0	0	1	1	0	1	0	0
419	6	Battlecruiser		0	0	1	1	0	0	0	1
420	6	Destroyer		0	0	1	1	0	0	0	1
422	4	Gas Isotopes	Gas Isotopes harvested from gas clouds.	0	0	1	1	0	0	0	0
423	4	Ice Product		0	1	1	1	0	0	0	1
425	8	Orbital Assault Unit		0	0	1	1	0	0	1	0
426	23	Mobile Projectile Sentry		0	1	1	1	0	1	0	1
427	4	Moon Materials	Stuff Harvested directly from Moons	0	1	1	1	0	0	0	1
428	4	Intermediate Materials	Stuff made from moon materials in a reactor	0	1	1	1	0	0	0	1
429	4	Composite		0	1	1	1	0	0	0	1
430	23	Mobile Laser Sentry		0	1	1	1	0	1	0	1
435	11	Deadspace Overseer		0	0	1	1	0	0	0	0
436	24	Simple Reaction		2665	1	1	1	0	0	0	1
438	23	Mobile Reactor		0	1	1	1	0	1	0	1
439	23	Electronic Warfare Battery	Group for mobile racial ECM.	0	1	1	1	0	1	0	1
440	23	Sensor Dampening Battery	Deployable Sensor Dampener	0	1	1	1	0	1	0	1
441	23	Stasis Webification Battery	Deployable Stasis Webber	0	1	1	1	0	1	0	1
443	23	Warp Scrambling Battery	Deployable warp jammers.	0	1	1	1	0	1	0	1
444	23	Shield Hardening Array	Increases control tower shield resistances	0	1	1	1	0	1	0	1
445	23	Force Field Array	Projects a shield around structures outside the range of a control tower.	0	1	1	1	0	1	0	0
446	11	Customs Official		0	0	1	1	0	0	0	0
447	9	Construction Component Blueprints		\N	1	1	1	0	0	0	1
448	2	Audit Log Secure Container		\N	1	1	1	0	1	0	1
449	23	Mobile Hybrid Sentry		0	1	1	1	0	1	0	1
450	25	Arkonor		15	0	1	1	1	0	0	1
451	25	Bistot		15	0	1	1	1	0	0	1
452	25	Crokite		15	0	1	1	1	0	0	1
453	25	Dark Ochre		15	0	1	1	1	0	0	1
454	25	Hedbergite		15	0	1	1	1	0	0	1
455	25	Hemorphite		15	0	1	1	1	0	0	1
456	25	Jaspet		15	0	1	1	1	0	0	1
457	25	Kernite		15	0	1	1	1	0	0	1
458	25	Plagioclase		15	0	1	1	1	0	0	1
459	25	Pyroxeres		15	0	1	1	1	0	0	1
460	25	Scordite		15	0	1	1	1	0	0	1
461	25	Spodumain		15	0	1	1	1	0	0	1
462	25	Veldspar		15	0	1	1	1	0	0	1
463	6	Mining Barge	Mining Barges	0	0	1	1	0	0	0	1
464	7	Strip Miner		0	0	1	1	0	0	0	1
465	25	Ice		15	0	1	1	1	0	0	1
467	25	Gneiss		15	0	1	1	1	0	0	1
468	25	Mercoxit		15	0	1	1	1	0	0	1
469	25	Omber		15	0	1	1	1	0	0	1
470	18	Unanchoring Drone		0	0	1	1	0	0	0	0
471	23	Corporate Hangar Array	A Corp Hangar in space.	0	1	1	1	0	1	0	1
472	7	System Scanner		0	0	1	1	0	0	0	1
473	23	Tracking Array	Increases Optimal Range and Tracking Speed of all Turret Sentries	0	1	1	1	0	1	0	1
474	17	Acceleration Gate Keys	Contains keys, passcards, cyphers and other objects required to open locked acceleration gates in deadspace complexes.	0	0	1	1	0	0	0	1
475	7	Microwarpdrive		96	0	1	1	0	0	0	0
476	8	Citadel Torpedo		2630	0	1	1	0	0	1	1
477	9	Mining Barge Blueprint		0	1	1	1	0	0	0	1
478	9	System Scanner Blueprint		0	0	1	1	0	0	0	1
479	8	Scanner Probe		2704	0	1	1	0	0	1	1
480	23	Stealth Emitter Array		0	0	1	1	0	1	0	0
481	7	Scan Probe Launcher		2677	0	1	1	0	0	0	1
482	8	Mining Crystal		2660	0	1	1	0	0	1	1
483	7	Frequency Mining Laser		138	0	1	1	0	0	0	1
484	24	Complex Reactions		2666	1	1	1	0	0	0	1
485	6	Dreadnought		0	0	1	1	0	0	0	1
486	9	Scan Probe Blueprint		0	1	1	1	0	0	0	1
487	9	Destroyer Blueprint		0	1	1	1	0	0	0	1
489	9	Battlecruiser Blueprint		0	1	1	1	0	0	0	1
490	9	Strip Miner Blueprint		0	1	1	1	0	0	0	1
492	8	Survey Probe		2663	0	1	1	0	0	1	1
493	17	Overseer Personal Effects		0	1	1	1	0	0	0	1
494	11	Deadspace Overseer's Structure	This structure belongs to the overseer of this deadspace pocket.	0	0	1	1	1	0	0	0
495	11	Deadspace Overseer's Sentry	This sentry is controlled by the overseer of this deadspace pocket.	0	0	1	1	1	0	0	0
496	11	Deadspace Overseer's Belongings	This container is tagged as the property of this deadspace pocket's overseer.	0	0	1	1	1	0	0	0
497	8	Fuel		0	0	1	1	0	0	1	0
498	8	Modifications		0	0	1	1	0	0	1	0
499	7	New EW Testing		0	0	1	1	0	0	0	0
500	8	Snowballs		0	0	1	1	0	0	1	0
501	7	Missile Launcher Snowball		0	0	1	1	0	0	0	1
502	2	Cosmic Signature	Disturbances and other anomalies in the electromagnetic or gravity field	0	0	1	1	1	0	0	0
503	9	Elite Industrial Blueprint		0	0	1	1	0	0	0	1
504	9	Target Painter Blueprint		0	1	1	1	0	0	0	1
505	16	Fake Skills	This group is for fake skills used for bonuses.	0	0	1	1	0	0	0	0
506	7	Missile Launcher Cruise		2530	0	1	1	0	0	0	1
507	7	Missile Launcher Rocket		1345	0	1	1	0	0	0	1
508	7	Missile Launcher Siege		170	0	1	1	0	0	0	1
509	7	Missile Launcher Standard		168	0	1	1	0	0	0	1
510	7	Missile Launcher Heavy		169	0	1	1	0	0	0	1
511	7	Missile Launcher Assault		1345	0	1	1	0	0	0	1
512	7	Missile Launcher Defender		0	0	1	1	0	0	0	1
513	6	Freighter		0	0	1	1	0	0	0	1
514	7	ECM Stabilizer		0	0	1	1	0	0	0	1
515	7	Siege Module		0	0	1	1	0	0	0	1
516	9	Siege Module Blueprint		0	1	1	1	0	0	0	1
517	2	Agents in Space	Piiiiiigs iiiiiin Spaaaaaaaace.....	0	0	1	1	1	0	0	0
518	7	Anti Ballistic Defense System		0	0	1	1	0	0	0	0
519	25	Terran Artifacts		0	1	1	1	0	0	0	0
520	11	Storyline Frigate		0	0	1	1	0	0	0	0
521	17	Identification		0	0	1	1	0	0	0	1
522	11	Storyline Cruiser		0	0	1	1	0	0	0	0
523	11	Storyline Battleship		0	0	1	1	0	0	0	0
524	7	Missile Launcher Citadel		2839	0	1	1	0	0	0	1
525	9	Freighter Blueprint		0	1	1	1	0	0	0	1
526	17	Commodities		0	0	1	1	0	0	0	1
527	11	Storyline Mission Frigate		0	0	1	1	0	0	0	0
528	17	Artifacts and Prototypes	Artifacts of ancient cultures in the world of eve.	0	0	1	1	0	0	0	1
530	17	Materials and Compounds	Alloys and Special materials used in manufacture of Ancient technology	0	0	1	1	0	0	0	1
532	9	Gang Coordinator Blueprint		0	1	1	1	0	0	0	1
533	11	Storyline Mission Cruiser		0	0	1	1	0	0	0	0
534	11	Storyline Mission Battleship		0	0	1	1	0	0	0	0
535	9	Construction Platform Blueprint		0	1	1	1	0	0	0	1
536	17	Station Components		0	1	1	1	0	0	0	1
537	9	Dreadnought Blueprint		0	1	1	1	0	0	0	1
538	7	Data Miners		0	0	1	1	0	0	0	1
540	6	Command Ship		0	0	1	1	0	0	0	1
541	6	Interdictor		0	0	1	1	0	0	0	1
543	6	Exhumer		0	0	1	1	0	0	0	1
544	18	Cap Drain Drone		0	0	1	1	0	0	0	1
545	18	Warp Scrambling Drone		0	0	1	1	0	0	0	1
546	7	Mining Upgrade		0	0	1	1	0	0	0	1
547	6	Carrier		0	0	1	1	0	0	0	1
548	8	Warp Disruption Probe		3018	0	1	1	0	0	1	1
549	18	Fighter Drone		0	0	1	1	0	0	0	1
550	11	Asteroid Angel Cartel Frigate		0	0	1	1	0	0	0	0
551	11	Asteroid Angel Cartel Cruiser		0	0	1	1	0	0	0	0
552	11	Asteroid Angel Cartel Battleship		0	0	1	1	0	0	0	0
553	11	Asteroid Angel Cartel Officer		0	0	1	1	0	0	0	0
554	11	Asteroid Angel Cartel Hauler		0	0	1	1	0	0	0	0
555	11	Asteroid Blood Raiders Cruiser		0	0	1	1	0	0	0	0
556	11	Asteroid Blood Raiders Battleship		0	0	1	1	0	0	0	0
557	11	Asteroid Blood Raiders Frigate		0	0	1	1	0	0	0	0
558	11	Asteroid Blood Raiders Hauler		0	0	1	1	0	0	0	0
559	11	Asteroid Blood Raiders Officer		0	0	1	1	0	0	0	0
560	11	Asteroid Guristas Battleship		0	0	1	1	0	0	0	0
561	11	Asteroid Guristas Cruiser		0	0	1	1	0	0	0	0
562	11	Asteroid Guristas Frigate		0	0	1	1	0	0	0	0
563	11	Asteroid Guristas Hauler		0	0	1	1	0	0	0	0
564	11	Asteroid Guristas Officer		0	0	1	1	0	0	0	0
565	11	Asteroid Sansha's Nation Battleship		0	0	1	1	0	0	0	0
566	11	Asteroid Sansha's Nation Cruiser		0	0	1	1	0	0	0	0
567	11	Asteroid Sansha's Nation Frigate		0	0	1	1	0	0	0	0
568	11	Asteroid Sansha's Nation Hauler		0	0	1	1	0	0	0	0
569	11	Asteroid Sansha's Nation Officer		0	0	1	1	0	0	0	0
570	11	Asteroid Serpentis Battleship		0	0	1	1	0	0	0	0
571	11	Asteroid Serpentis Cruiser		0	0	1	1	0	0	0	0
572	11	Asteroid Serpentis Frigate		0	0	1	1	0	0	0	0
573	11	Asteroid Serpentis Hauler		0	0	1	1	0	0	0	0
574	11	Asteroid Serpentis Officer		0	0	1	1	0	0	0	0
575	11	Asteroid Angel Cartel Destroyer		0	0	1	1	0	0	0	0
576	11	Asteroid Angel Cartel BattleCruiser		0	0	1	1	0	0	0	0
577	11	Asteroid Blood Raiders Destroyer		0	0	1	1	0	0	0	0
578	11	Asteroid Blood Raiders BattleCruiser		0	0	1	1	0	0	0	0
579	11	Asteroid Guristas Destroyer		0	0	1	1	0	0	0	0
580	11	Asteroid Guristas BattleCruiser		0	0	1	1	0	0	0	0
581	11	Asteroid Sansha's Nation Destroyer		0	0	1	1	0	0	0	0
582	11	Asteroid Sansha's Nation BattleCruiser		0	0	1	1	0	0	0	0
583	11	Asteroid Serpentis Destroyer		0	0	1	1	0	0	0	0
584	11	Asteroid Serpentis BattleCruiser		0	0	1	1	0	0	0	0
585	7	Remote Hull Repairer	Modules used to repair damaged hull of friendly vessels	0	0	1	1	0	0	0	1
586	7	Drone Modules		0	0	1	1	0	0	0	0
588	7	Super Weapon		0	0	1	1	0	0	0	1
589	7	Bubble Probe Launcher		2990	0	1	1	0	0	0	1
590	7	Jump Portal Generator		0	0	1	1	0	0	0	1
593	11	Deadspace Angel Cartel BattleCruiser		0	0	1	1	0	0	0	0
594	11	Deadspace Angel Cartel Battleship		0	0	1	1	0	0	0	0
595	11	Deadspace Angel Cartel Cruiser		0	0	1	1	0	0	0	0
596	11	Deadspace Angel Cartel Destroyer		0	0	1	1	0	0	0	0
597	11	Deadspace Angel Cartel Frigate		0	0	1	1	0	0	0	0
602	11	Deadspace Blood Raiders BattleCruiser		0	0	1	1	0	0	0	0
603	11	Deadspace Blood Raiders Battleship		0	0	1	1	0	0	0	0
604	11	Deadspace Blood Raiders Cruiser		0	0	1	1	0	0	0	0
605	11	Deadspace Blood Raiders Destroyer		0	0	1	1	0	0	0	0
606	11	Deadspace Blood Raiders Frigate		0	0	1	1	0	0	0	0
611	11	Deadspace Guristas BattleCruiser		0	0	1	1	0	0	0	0
612	11	Deadspace Guristas Battleship		0	0	1	1	0	0	0	0
613	11	Deadspace Guristas Cruiser		0	0	1	1	0	0	0	0
614	11	Deadspace Guristas Destroyer		0	0	1	1	0	0	0	0
615	11	Deadspace Guristas Frigate		0	0	1	1	0	0	0	0
620	11	Deadspace Sansha's Nation BattleCruiser		0	0	1	1	0	0	0	0
621	11	Deadspace Sansha's Nation Battleship		0	0	1	1	0	0	0	0
622	11	Deadspace Sansha's Nation Cruiser		0	0	1	1	0	0	0	0
623	11	Deadspace Sansha's Nation Destroyer		0	0	1	1	0	0	0	0
624	11	Deadspace Sansha's Nation Frigate		0	0	1	1	0	0	0	0
629	11	Deadspace Serpentis BattleCruiser		0	0	1	1	0	0	0	0
630	11	Deadspace Serpentis Battleship		0	0	1	1	0	0	0	0
631	11	Deadspace Serpentis Cruiser		0	0	1	1	0	0	0	0
632	11	Deadspace Serpentis Destroyer		0	0	1	1	0	0	0	0
633	11	Deadspace Serpentis Frigate		0	0	1	1	0	0	0	0
638	7	Navigation Computer		0	0	1	1	0	0	0	0
639	18	Electronic Warfare Drone		0	0	1	1	0	0	0	1
640	18	Logistic Drone		0	0	1	1	0	0	0	1
641	18	Stasis Webifying Drone		0	0	1	1	0	0	0	1
642	7	Super Gang Enhancer		0	0	1	1	0	0	0	0
643	9	Carrier Blueprint		0	1	1	1	0	0	0	1
644	7	Drone Navigation Computer		0	0	1	1	0	0	0	1
645	7	Drone Damage Modules		0	0	1	1	0	0	0	0
646	7	Drone Tracking Modules		0	0	1	1	0	0	0	1
647	7	Drone Control Range Module		0	0	1	1	0	0	0	1
648	8	Advanced Rocket		1351	0	1	1	0	0	1	1
649	2	Freight Container	Freight Containers are commonly used in Freighter-class ships to accomodate their massive cargobays.	1174	1	1	1	0	0	0	1
650	7	Tractor Beam		0	0	1	1	0	0	0	1
651	9	Super Weapon Blueprint		0	1	1	1	0	0	0	1
652	17	Lease	Each 'Starbase Code Cycle' equals 1 hour of operation of a control tower in the sovereign space of the entity that issued the code. If no Starbase Code Cycle is available during a Control Tower consumption cycle, it should be considered as it has no fuel and therefore offlined.	0	1	1	1	0	0	0	1
653	8	Advanced Light Missile		191	0	1	1	0	0	1	1
654	8	Advanced Assault Missile		3235	0	1	1	0	0	1	1
655	8	Advanced Heavy Missile		188	0	1	1	0	0	1	1
656	8	Advanced Cruise Missile		184	0	1	1	0	0	1	1
657	8	Advanced Torpedo		1347	0	1	1	0	0	1	1
658	7	Cynosural Field		0	0	1	1	0	0	0	1
659	6	Mothership	Mothership	0	0	1	1	0	0	0	1
660	7	Energy Vampire Slayer		0	0	1	1	0	0	0	0
661	24	Simple Biochemical Reactions		2665	0	1	1	0	0	0	1
662	24	Complex Biochemical Reactions		2665	0	1	1	0	0	0	1
663	8	Mercoxit Mining Crystal		2654	0	1	1	0	0	1	1
665	11	Mission Amarr Empire Frigate		0	0	1	1	0	0	0	0
666	11	Mission Amarr Empire Battlecruiser		0	0	1	1	0	0	0	0
667	11	Mission Amarr Empire Battleship		0	0	1	1	0	0	0	0
668	11	Mission Amarr Empire Cruiser		0	0	1	1	0	0	0	0
669	11	Mission Amarr Empire Destroyer		0	0	1	1	0	0	0	0
670	11	Mission Amarr Empire Other		0	0	1	1	0	0	0	0
671	11	Mission Caldari State Frigate		0	0	1	1	0	0	0	0
672	11	Mission Caldari State Battlecruiser		0	0	1	1	0	0	0	0
673	11	Mission Caldari State Cruiser		0	0	1	1	0	0	0	0
674	11	Mission Caldari State Battleship		0	0	1	1	0	0	0	0
675	11	Mission Caldari State Other		0	0	1	1	0	0	0	0
676	11	Mission Caldari State Destroyer		0	0	1	1	0	0	0	0
677	11	Mission Gallente Federation Frigate		0	0	1	1	0	0	0	0
678	11	Mission Gallente Federation Cruiser		0	0	1	1	0	0	0	0
679	11	Mission Gallente Federation Destroyer		0	0	1	1	0	0	0	0
680	11	Mission Gallente Federation Battleship		0	0	1	1	0	0	0	0
681	11	Mission Gallente Federation Battlecruiser		0	0	1	1	0	0	0	0
682	11	Mission Gallente Federation Other		0	0	1	1	0	0	0	0
683	11	Mission Minmatar Republic Frigate		0	0	1	1	0	0	0	0
684	11	Mission Minmatar Republic Destroyer		0	0	1	1	0	0	0	0
685	11	Mission Minmatar Republic Battlecruiser		0	0	1	1	0	0	0	0
686	11	Mission Minmatar Republic Other		0	0	1	1	0	0	0	0
687	11	Mission Khanid Frigate		0	0	1	1	0	0	0	0
688	11	Mission Khanid Destroyer		0	0	1	1	0	0	0	0
689	11	Mission Khanid Cruiser		0	0	1	1	0	0	0	0
690	11	Mission Khanid Battlecruiser		0	0	1	1	0	0	0	0
691	11	Mission Khanid Battleship		0	0	1	1	0	0	0	0
692	11	Mission Khanid Other		0	0	1	1	0	0	0	0
693	11	Mission CONCORD Frigate		0	0	1	1	0	0	0	0
694	11	Mission CONCORD Destroyer		0	0	1	1	0	0	0	0
695	11	Mission CONCORD Cruiser		0	0	1	1	0	0	0	0
696	11	Mission CONCORD Battlecruiser		0	0	1	1	0	0	0	0
697	11	Mission CONCORD Battleship		0	0	1	1	0	0	0	0
698	11	Mission CONCORD Other		0	0	1	1	0	0	0	0
699	11	Mission Mordu Frigate		0	0	1	1	0	0	0	0
700	11	Mission Mordu Destroyer		0	0	1	1	0	0	0	0
701	11	Mission Mordu Cruiser		0	0	1	1	0	0	0	0
702	11	Mission Mordu Battlecruiser		0	0	1	1	0	0	0	0
703	11	Mission Mordu Battleship		0	0	1	1	0	0	0	0
704	11	Mission Mordu Other		0	0	1	1	0	0	0	0
705	11	Mission Minmatar Republic Cruiser		0	0	1	1	0	0	0	0
706	11	Mission Minmatar Republic Battleship		0	0	1	1	0	0	0	0
707	23	Jump Portal Array		0	1	1	1	0	1	0	1
709	23	Scanner Array		0	1	1	1	0	1	0	1
710	23	Logistics Array		0	1	1	1	0	1	0	0
711	2	Harvestable Cloud		0	0	1	1	0	0	0	1
712	4	Biochemical Material		0	0	1	1	0	0	0	1
715	11	Destructible Agents In Space		0	0	1	1	1	0	0	0
716	17	Data Interfaces		0	0	1	1	0	0	0	1
718	9	Booster Blueprints		0	0	1	1	0	0	0	1
721	20	Temp		0	0	1	1	0	0	0	0
722	9	Advanced Hybrid Ammo Blueprint		179	1	1	1	0	0	0	1
723	9	Tractor Beam Blueprint		375	1	1	1	0	0	0	1
724	9	Implant Blueprints		0	1	1	1	0	0	0	1
725	9	Advanced Projectile Ammo Blueprint		171	1	1	1	0	0	0	1
726	9	Advanced Frequency Crystal Blueprint		0	1	1	1	0	0	0	1
727	9	Mining Crystal Blueprint		0	1	1	1	0	0	0	1
728	17	Decryptors - Amarr		0	0	1	1	0	0	0	1
729	17	Decryptors - Minmatar		0	0	1	1	0	0	0	1
730	17	Decryptors - Gallente		0	0	1	1	0	0	0	1
731	17	Decryptors - Caldari		0	0	1	1	0	0	0	1
732	17	Decryptors - Sleepers		0	0	1	1	0	0	0	1
733	17	Decryptors - Yan Jung		0	0	1	1	0	0	0	1
734	17	Decryptors - Takmahl		0	0	1	1	0	0	0	1
735	17	Decryptors - Talocan		0	0	1	1	0	0	0	1
737	7	Gas Cloud Harvester		0	0	1	1	0	0	0	1
738	20	Cyber Armor	Implants relating to armor.	0	1	1	1	0	0	0	1
739	20	Cyber Drones	Implants relating to drones	0	1	1	1	0	0	0	1
740	20	Cyber Electronics	Implants relating to electronic warfare	0	1	1	1	0	0	0	1
741	20	Cyber Engineering	Implants related to capacitor	0	1	1	1	0	0	0	1
742	20	Cyber Gunnery	Implants relating to gunnery	0	1	1	1	0	0	0	1
743	20	Cyber Industry	Implants related to mining, refining and manufacturing.	0	1	1	1	0	0	0	1
744	20	Cyber Leadership	Implants relating to gangs	0	1	1	1	0	0	0	1
745	20	Cyber Learning	Implants relating to character attributes.	0	1	1	1	0	0	0	1
746	20	Cyber Missile	Implants relating to missile launcher operation.	0	1	1	1	0	0	0	1
747	20	Cyber Navigation	Implants relating to speed mods.	0	1	1	1	0	0	0	1
748	20	Cyber Science	Implants related to research.	0	1	1	1	0	0	0	1
749	20	Cyber Shields	Implants relating to shields.	0	1	1	1	0	0	0	1
750	20	Cyber Social	Implants relating to agents.	0	1	1	1	0	0	0	1
751	20	Cyber Trade	Implants related to trading.	0	1	1	1	0	0	0	1
753	7	ECM Enhancer		0	0	1	1	0	0	0	0
754	4	Salvaged Materials		0	0	1	1	0	0	0	1
755	11	Asteroid Rogue Drone BattleCruiser		0	0	1	1	0	0	0	0
756	11	Asteroid Rogue Drone Battleship		0	0	1	1	0	0	0	0
757	11	Asteroid Rogue Drone Cruiser		0	0	1	1	0	0	0	0
758	11	Asteroid Rogue Drone Destroyer		0	0	1	1	0	0	0	0
759	11	Asteroid Rogue Drone Frigate		0	0	1	1	0	0	0	0
760	11	Asteroid Rogue Drone Hauler		0	0	1	1	0	0	0	0
761	11	Asteroid Rogue Drone Swarm		0	0	1	1	0	0	0	0
762	7	Inertia Stabilizer		0	0	1	1	0	0	0	1
763	7	Nanofiber Internal Structure		0	0	1	1	0	0	0	1
764	7	Overdrive Injector System		0	0	1	1	0	0	0	1
765	7	Expanded Cargohold		0	0	1	1	0	0	0	1
766	7	Power Diagnostic System		0	0	1	1	0	0	0	1
767	7	Capacitor Power Relay		0	0	1	1	0	0	0	1
768	7	Capacitor Flux Coil		0	0	1	1	0	0	0	1
769	7	Reactor Control Unit		0	0	1	1	0	0	0	1
770	7	Shield Flux Coil		0	0	1	1	0	0	0	1
771	7	Missile Launcher Heavy Assault		3241	0	1	1	0	0	0	1
772	8	Assault Missile		3237	0	1	1	0	0	1	1
773	7	Rig Armor		0	0	1	1	0	0	0	1
774	7	Rig Shield		0	0	1	1	0	0	0	1
775	7	Rig Energy Weapon		0	0	1	1	0	0	0	1
776	7	Rig Hybrid Weapon		0	0	1	1	0	0	0	1
777	7	Rig Projectile Weapon		0	0	1	1	0	0	0	1
778	7	Rig Drones		0	0	1	1	0	0	0	1
779	7	Rig Launcher		0	0	1	1	0	0	0	1
780	7	Rig Electronics		0	0	1	1	0	0	0	1
781	7	Rig Energy Grid		0	0	1	1	0	0	0	1
782	7	Rig Astronautic		0	0	1	1	0	0	0	1
783	20	Cyber X Specials		0	1	1	1	0	0	0	0
784	11	Large Collidable Ship		0	0	1	1	1	0	0	0
786	7	Rig Electronics Superiority		0	0	1	1	0	0	0	1
787	9	Rig Blueprint		1038	1	1	1	0	0	0	1
789	11	Asteroid Angel Cartel Commander Frigate		0	0	1	1	0	0	0	0
790	11	Asteroid Angel Cartel Commander Cruiser		0	0	1	1	0	0	0	0
791	11	Asteroid Blood Raiders Commander Cruiser		0	0	1	1	0	0	0	0
792	11	Asteroid Blood Raiders Commander Frigate		0	0	1	1	0	0	0	0
793	11	Asteroid Angel Cartel Commander BattleCruiser		0	0	1	1	0	0	0	0
794	11	Asteroid Angel Cartel Commander Destroyer		0	0	1	1	0	0	0	0
795	11	Asteroid Blood Raiders Commander BattleCruiser		0	0	1	1	0	0	0	0
796	11	Asteroid Blood Raiders Commander Destroyer		0	0	1	1	0	0	0	0
797	11	Asteroid Guristas Commander BattleCruiser		0	0	1	1	0	0	0	0
798	11	Asteroid Guristas Commander Cruiser		0	0	1	1	0	0	0	0
799	11	Asteroid Guristas Commander Destroyer		0	0	1	1	0	0	0	0
800	11	Asteroid Guristas Commander Frigate		0	0	1	1	0	0	0	0
801	11	Deadspace Rogue Drone BattleCruiser		0	0	1	1	0	0	0	0
802	11	Deadspace Rogue Drone Battleship		0	0	1	1	0	0	0	0
803	11	Deadspace Rogue Drone Cruiser		0	0	1	1	0	0	0	0
804	11	Deadspace Rogue Drone Destroyer		0	0	1	1	0	0	0	0
805	11	Deadspace Rogue Drone Frigate		0	0	1	1	0	0	0	0
806	11	Deadspace Rogue Drone Swarm		0	0	1	1	0	0	0	0
807	11	Asteroid Sansha's Nation Commander BattleCruiser		0	0	1	1	0	0	0	0
808	11	Asteroid Sansha's Nation Commander Cruiser		0	0	1	1	0	0	0	0
809	11	Asteroid Sansha's Nation Commander Destroyer		0	0	1	1	0	0	0	0
810	11	Asteroid Sansha's Nation Commander Frigate		0	0	1	1	0	0	0	0
811	11	Asteroid Serpentis Commander BattleCruiser		0	0	1	1	0	0	0	0
812	11	Asteroid Serpentis Commander Cruiser		0	0	1	1	0	0	0	0
813	11	Asteroid Serpentis Commander Destroyer		0	0	1	1	0	0	0	0
814	11	Asteroid Serpentis Commander Frigate		0	0	1	1	0	0	0	0
815	7	Clone Vat Bay		0	0	1	1	0	0	0	1
816	11	Mission Generic Battleships	Remnants of the "Mission Drones" and "Faction Drones" groups. Contains NPC's that do not fall under other categories. Holds Battleship sized entities.	0	0	1	1	0	0	0	0
817	11	Mission Generic Cruisers	Remnants of the "Mission Drones" and "Faction Drones" groups. Contains NPC's that do not fall under other categories. Holds Cruiser sized entities.	0	0	1	1	0	0	0	0
818	11	Mission Generic Frigates	Remnants of the "Mission Drones" and "Faction Drones" groups. Contains NPC's that do not fall under other categories. Holds Frigate sized NPC's	0	0	1	1	0	0	0	0
819	11	Deadspace Overseer Frigate		0	0	1	1	0	0	0	0
820	11	Deadspace Overseer Cruiser		0	0	1	1	0	0	0	0
821	11	Deadspace Overseer Battleship		0	0	1	1	0	0	0	0
822	11	Mission Thukker Battlecruiser		0	0	1	1	0	0	0	0
823	11	Mission Thukker Battleship		0	0	1	1	0	0	0	0
824	11	Mission Thukker Cruiser		0	0	1	1	0	0	0	0
825	11	Mission Thukker Destroyer		0	0	1	1	0	0	0	0
826	11	Mission Thukker Frigate		0	0	1	1	0	0	0	0
827	11	Mission Thukker Other		0	0	1	1	0	0	0	0
828	11	Mission Generic Battle Cruisers	Remnants of the "Mission Drones" and "Faction Drones" groups. Contains NPC's that do not fall under other categories. Holds Battle Cruiser sized entities.	0	0	1	1	0	0	0	0
829	11	Mission Generic Destroyers	Remnants of the "Mission Drones" and "Faction Drones" groups. Contains NPC's that do not fall under other categories. Holds Destroyer sized entities.	0	0	1	1	0	0	0	0
830	6	Covert Ops		0	0	1	1	0	0	0	1
831	6	Interceptor		0	0	1	1	0	0	0	1
832	6	Logistics		0	0	1	1	0	0	0	1
833	6	Force Recon Ship		0	0	1	1	0	0	0	1
834	6	Stealth Bomber		0	0	1	1	0	0	0	1
835	2	Station Upgrade Platform		0	1	1	1	0	1	0	1
836	2	Station Improvement Platform		0	1	1	1	0	1	0	1
837	23	Energy Neutralizing Battery	Deployable Energy Neutralizer	0	1	1	1	0	1	0	1
838	23	Cynosural Generator Array		0	1	1	1	0	1	0	1
839	23	Cynosural System Jammer		0	1	1	1	0	1	0	1
840	23	Structure Repair Array		0	0	1	1	0	0	0	1
841	9	Structures - Control Tower Blueprints		0	0	1	1	0	0	0	1
842	7	Remote ECM Burst		0	0	1	1	0	0	0	1
843	11	Asteroid Rogue Drone Commander BattleCruiser		0	0	1	1	0	0	0	0
844	11	Asteroid Rogue Drone Commander Battleship		0	0	1	1	0	0	0	0
845	11	Asteroid Rogue Drone Commander Cruiser		0	0	1	1	0	0	0	0
846	11	Asteroid Rogue Drone Commander Destroyer		0	0	1	1	0	0	0	0
847	11	Asteroid Rogue Drone Commander Frigate		0	0	1	1	0	0	0	0
848	11	Asteroid Angel Cartel Commander Battleship		0	0	1	1	0	0	0	0
849	11	Asteroid Blood Raiders Commander Battleship		0	0	1	1	0	0	0	0
850	11	Asteroid Guristas Commander Battleship		0	0	1	1	0	0	0	0
851	11	Asteroid Sansha's Nation Commander Battleship		0	0	1	1	0	0	0	0
852	11	Asteroid Serpentis Commander Battleship		0	0	1	1	0	0	0	0
853	9	Structures - Laser Battery Blueprints		0	0	1	1	0	0	0	1
854	9	Structures - Projectile Battery Blueprints		0	0	1	1	0	0	0	1
855	9	Structures - Hybrid Battery Blueprints		0	0	1	1	0	0	0	1
856	9	Structures - ECM Jamming Array Blueprints		0	0	1	1	0	0	0	1
857	9	Structures - Warp Scrambling Battery Blueprints		0	0	1	1	0	0	0	1
858	9	Structures - Stasis Webification Battery Blueprints		0	0	1	1	0	0	0	1
859	9	Structures - Sensor Dampening Array Blueprints		0	0	1	1	0	0	0	1
860	9	Structures - Energy Neutralizing Battery Blueprints		0	0	1	1	0	0	0	1
861	11	Mission Fighter Drone		0	0	1	1	0	0	0	0
862	7	Missile Launcher Bomb		2677	0	1	1	0	0	0	1
863	8	Bomb ECM		3283	0	1	1	0	0	1	1
864	8	Bomb Energy		3282	0	1	1	0	0	1	1
865	11	Mission Amarr Empire Carrier		0	0	1	1	1	0	0	0
866	11	Mission Caldari State Carrier		0	0	1	1	1	0	0	0
867	11	Mission Gallente Federation Carrier		0	0	1	1	1	0	0	0
868	11	Mission Minmatar Republic Carrier		0	0	1	1	1	0	0	0
870	9	Remote Hull Repairer Blueprint		0	1	1	1	0	0	0	1
871	9	Structures - Missile Battery Blueprints		0	0	1	1	0	0	0	1
872	5	Outpost Improvements		0	0	1	1	0	0	0	1
873	17	Capital Construction Components	Capital Construction Components	0	0	1	1	0	0	0	1
874	2	Destructible Station Services		0	0	1	1	0	0	0	0
875	11	Mission Faction Freighters		0	0	1	1	0	0	0	0
876	5	Outpost Upgrades		0	0	1	1	0	0	0	1
877	23	Target Painting Battery		0	0	1	1	0	0	0	0
878	7	Cloak Enhancements	Module group for modules that affect cloaking devices	0	0	1	1	0	0	0	0
879	17	Slave Reception		0	0	1	1	0	0	0	1
880	17	Slave Converts		0	0	1	1	0	0	0	0
881	24	Freedom Programs		0	0	1	1	0	0	0	0
882	24	Enslavement Programs		0	0	1	1	0	0	0	0
883	6	Capital Industrial Ship		0	0	1	1	0	0	0	1
884	17	Test Compressed Ore		0	0	1	1	0	0	0	0
885	2	Cosmic Anomaly		0	0	1	1	1	0	0	0
886	4	Rogue Drone Components		0	0	1	1	0	0	0	1
888	9	Ore Compression Blueprints		0	1	1	1	0	0	0	1
889	9	Ore Enhancement Blueprints		0	0	1	1	0	0	0	0
890	9	Ice Compression Blueprints		0	1	1	1	0	0	0	1
891	9	Structures - Mobile Laboratories		0	0	1	1	0	0	0	0
892	8	Veldspar Blast Crystals		0	0	1	1	0	0	0	0
893	6	Electronic Attack Ship		38	0	1	1	0	0	0	1
894	6	Heavy Interdictor		41	0	1	1	0	0	0	1
896	7	Rig Security Transponder		0	0	1	1	0	0	0	0
897	2	Covert Beacon		0	0	1	1	0	0	0	0
898	6	Black Ops		43	0	1	1	0	0	0	1
899	7	Warp Disrupt Field Generator		0	0	1	1	0	0	0	1
900	6	Marauder		43	0	1	1	0	0	0	1
901	7	Mining Enhancer		0	0	1	1	0	0	0	0
902	6	Jump Freighter		0	0	1	1	0	0	0	1
903	25	Ancient Compressed Ice		0	0	1	1	0	0	0	0
904	7	Rig Mining		0	0	1	1	0	0	0	0
905	7	Covert Cynosural Field Generator		0	0	1	1	0	0	0	1
906	6	Combat Recon Ship		0	0	1	1	0	0	0	1
907	8	Tracking Script		3346	0	1	1	0	0	1	1
908	8	Warp Disruption Script		111	0	1	1	0	0	1	1
909	8	Tracking Disruption Script		1639	0	1	1	0	0	1	1
910	8	Sensor Booster Script		74	0	1	1	0	0	1	1
911	8	Sensor Dampener Script		105	0	1	1	0	0	1	1
912	9	Script Blueprint		0	1	1	1	0	0	0	1
913	17	Advanced Capital Construction Components		0	0	1	1	0	0	0	1
914	9	Advanced Capital Construction Component Blueprints		0	1	1	1	0	0	0	1
915	9	Capital Construction Blueprints		0	1	1	1	0	0	0	1
916	8	Nanite Repair Paste		0	1	1	1	0	0	0	1
\.


--
-- Name: invGroups invGroups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invGroups"
    ADD CONSTRAINT "invGroups_pkey" PRIMARY KEY ("groupID");


--
-- PostgreSQL database dump complete
--

\unrestrict xYW2GyerCgwi8lOFesdbsGdXRheXHOl5fGAyUEDsvwJeRzWiytnw5OxGiip4jLj

