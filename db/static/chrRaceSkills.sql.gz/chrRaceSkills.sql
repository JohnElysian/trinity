-- chrRaceSkills: Trinity 1.0 static data (tools/trinity_static.py)
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

CREATE TABLE public."chrRaceSkills" (
    "raceID" integer,
    "skillTypeID" integer,
    levels integer
);

COPY public."chrRaceSkills" ("raceID", "skillTypeID", levels) FROM stdin;
1	3300	1
1	3301	1
1	3319	1
1	3327	1
1	3330	1
1	3374	1
1	3386	1
1	3413	1
1	3416	1
2	3300	1
2	3302	1
2	3327	1
2	3329	1
2	3374	1
2	3386	1
2	3413	1
2	3416	1
4	3300	1
4	3303	1
4	3327	1
4	3331	1
4	3374	1
4	3386	1
4	3392	1
4	3393	1
4	3394	1
8	3300	1
8	3301	1
8	3327	1
8	3328	1
8	3374	1
8	3386	1
8	3392	1
8	3436	1
\.
