-- chrCareers: Trinity 1.0 static data (tools/trinity_static.py)
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

CREATE TABLE public."chrCareers" (
    "raceID" integer,
    "careerID" integer,
    "careerName" text,
    description text,
    "shortDescription" text,
    "graphicID" integer,
    "schoolID" integer
);

COPY public."chrCareers" ("raceID", "careerID", "careerName", description, "shortDescription", "graphicID", "schoolID") FROM stdin;
1	11	Military	A career in the military means learning what you need to know about how to dispose of enemy vessels as fast and securely as possible, without them disposing of you. Military academies educate enlist cadets thoroughly in combat related skills.	Focuses mainly on combat training.	3178	17
1	14	Business	Business is all about dealing with people, solving problems or finding compromises in quarrels and servicing trade routes. And of course, all in the name of financial success. Business careers can be roughly divided into two categories. One revolves entirely around buying and selling, dealing with business contacts and playing the market with the sole purpose of maximizing the profit margin. The other catergory is all about preparing the pilot to lead a group or a crowd of people, form and run a corporation and to supply leadership.	Focuses mainly on practical studies.	3175	18
1	17	Industry	A carrier in industry is a career that spells not only wealth for those that choose to follow that path, but it also opens the door to potential popularity. In the war torn reaches of space, everyone loves a provider. Serious industrialists need to learn how to harvest precious ore, refine it and either produce something from it or haul it around and sell where prices are high. Eventually, a successful industrialist often ends up with a lot of cash on his hands to spend on some other line of work.	Focuses mainly on technical studies.	3172	19
2	21	Military	A career in the military means learning what you need to know about how to dispose of enemy vessels as fast and securely as possible, without them disposing of you. Military academies educate enlist cadets thoroughly in combat related skills.	An up-and-coming military training institution.	3178	14
2	24	Business	Business is all about dealing with people, solving problems or finding compromises in quarrels and servicing trade routes. And of course, all in the name of financial success. Business careers can be roughly divided into two categories. One revolves entirely around buying and selling, dealing with business contacts and playing the market with the sole purpose of maximizing the profit margin. The other catergory is all about preparing the pilot to lead a group or a crowd of people, form and run a corporation and to supply leadership.	Founded to help gifted children reach their potential.	3175	16
2	27	Industry	A carrier in industry is a career that spells not only wealth for those that choose to follow that path, but it also opens the door to potential popularity. In the war torn reaches of space, everyone loves a provider. Serious industrialists need to learn how to harvest precious ore, refine it and either produce something from it or haul it around and sell where prices are high. Eventually, a successful industrialist often ends up with a lot of cash on his hands to spend on some other line of work.	A forward-thinking house of higher learning.	3172	15
4	41	Military	A career in the military means learning what you need to know about how to dispose of enemy vessels as fast and securely as possible, without them disposing of you. Military academies educate enlist cadets thoroughly in combat related skills.	The Empire's breeding grounds for military might.	3178	11
4	44	Business	Business is all about dealing with people, solving problems or finding compromises in quarrels and servicing trade routes. And of course, all in the name of financial success. Business careers can be roughly divided into two categories. One revolves entirely around buying and selling, dealing with business contacts and playing the market with the sole purpose of maximizing the profit margin. The other catergory is all about preparing the pilot to lead a group or a crowd of people, form and run a corporation and to supply leadership.	A bastion of liberalism and free thought.	3175	12
4	47	Industry	A carrier in industry is a career that spells not only wealth for those that choose to follow that path, but it also opens the door to potential popularity. In the war torn reaches of space, everyone loves a provider. Serious industrialists need to learn how to harvest precious ore, refine it and either produce something from it or haul it around and sell where prices are high. Eventually, a successful industrialist often ends up with a lot of cash on his hands to spend on some other line of work.	One of the most venerable educational facilities in the universe.	3172	13
8	81	Military	A career in the military means learning what you need to know how about to dispose of enemy vessels as fast and securely as possible, without them disposing of you. Military academies educate enlist cadets thoroughly in combat related skills.	An extremely strict but effective military academy.	3178	20
8	84	Business	Business is all about dealing with people, solving problems or finding compromises in quarrels and servicing trade routes. And of course, all in the name of financial success. Business careers can be roughly divided into two categories. One revolves entirely around buying and selling, dealing with business contacts and playing the market with the sole purpose of maximizing the profit margin. The other catergory is all about preparing the pilot to lead a group or a crowd of people, form and run a corporation and to supply leadership.	The largest school in the universe.	3175	21
8	87	Industry	A carrier in industry is a career that spells not only wealth for those that choose to follow that path, but it also opens the door to potential popularity. In the war torn reaches of space, everyone loves a provider. Serious industrialists need to learn how to harvest precious ore, refine it and either produce something from it or haul it around and sell where prices are high. Eventually, a successful industrialist often ends up with a lot of cash on his hands to spend on some other line of work.	One of the very best technical schools in the universe.	3172	22
16	161	Business			3175	23
16	164	Industry			3172	24
16	167	Military			3178	25
\.

ALTER TABLE ONLY public."chrCareers"
    ADD CONSTRAINT "chrCareers_pkey" PRIMARY KEY ("careerID");
