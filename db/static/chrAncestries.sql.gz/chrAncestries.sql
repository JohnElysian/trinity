--
-- PostgreSQL database dump
--

\restrict FqZ42ZXbuf3YJZkKoWJ9lBpcVy2S8ekq7xKGoedrLo7tKgEqPCSceYKMgK5fA1c

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrAncestries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrAncestries" (
    "ancestryID" integer DEFAULT 0 NOT NULL,
    "ancestryName" text DEFAULT ''::text NOT NULL,
    "bloodlineID" integer DEFAULT 0 NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "postPerception" integer DEFAULT 0 NOT NULL,
    "postWillpower" integer DEFAULT 0 NOT NULL,
    "postCharisma" integer DEFAULT 0 NOT NULL,
    "postMemory" integer DEFAULT 0 NOT NULL,
    "postIntelligence" integer DEFAULT 0 NOT NULL,
    perception integer DEFAULT 0 NOT NULL,
    willpower integer DEFAULT 0 NOT NULL,
    charisma integer DEFAULT 0 NOT NULL,
    memory integer DEFAULT 0 NOT NULL,
    intelligence integer DEFAULT 0 NOT NULL,
    "skillTypeID1" integer DEFAULT 0 NOT NULL,
    "skillTypeID2" integer DEFAULT 0 NOT NULL,
    "typeID" integer,
    "typeQuantity" integer,
    "typeID2" text,
    "typeQuantity2" integer,
    "graphicID" integer,
    "shortDescription" text
);


--
-- Data for Name: chrAncestries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrAncestries" ("ancestryID", "ancestryName", "bloodlineID", description, "postPerception", "postWillpower", "postCharisma", "postMemory", "postIntelligence", perception, willpower, charisma, memory, intelligence, "skillTypeID1", "skillTypeID2", "typeID", "typeQuantity", "typeID2", "typeQuantity2", "graphicID", "shortDescription") FROM stdin;
1	Liberal Holders	5	Holders, the elite caste in Amarr society, are usually very conservative and habitual. A few, however, have rejected their traditional role as inactive power-mongers and are instead active members of the economical life of the Empire. Their champion is Catiz Tash-Murkon, the Udorian Royal Heir.	0	1	3	0	0	0	1	3	0	0	3355	3417	\N	1	\N	5	1641	Members of the upper class who have rejected their traditional ways.
2	Wealthy Commoners	5	Some commoners manage to break out of Amarr society's strict caste form and make a name for themselves, usually through trade or other mercantile activities. Though they can never enjoy political power within the empire, they are free to hoard vast amounts of wealth through interstellar trade.	0	0	1	3	0	0	0	1	3	0	3380	3417	\N	1	\N	5	1642	Commoners who have transcended their class through shrewd business sense.
3	Religious Reclaimers	5	Many Amarrians still dream of the glory days of the Empire, when the Amarrians seemed poised to conquer the world. They abhor the peace policies of recent regimes, regarding them as weak and against everything the Empire has stood for in its magnificent history.	0	4	0	0	0	0	4	0	0	0	3348	3417	\N	1	\N	\N	1643	Those who wish to see the Empire regain its former glory.
4	Free Merchants	6	The Ni-Kunni, originally a slave race within the Amarr Empire, have adapted exceptionally well and most of them are today free. The Ni-Kunni have used the Amarrian upper class's inherent dislike of mercantile work to their advantage, and Ni-Kunni merchants now fill vital niches in the Empire's economy.	0	0	4	0	0	0	0	4	0	0	3355	3444	\N	1	\N	1	1644	Roaming businessmen who will sell anything for the right price.
5	Border Runners	6	The Amarr Empire has strict rules regarding trade with other races. This encourages smuggling operations to ferry goods not otherwise permitted to cross the border to flourish. None are better at this than the Ni-Kunni, who have spent generations perfecting their smuggling runs.	3	0	0	0	1	3	0	0	0	1	3449	3444	\N	1	\N	1	1645	Wily smugglers, bound by no borders.
6	Navy Veterans	6	A large portion of the Ni-Kunni live in impoverished slums and ghettos. One of the few ways for them to escape is to enlist in the Imperial Navy, where they receive the career training and education they need to make a prosperous life for themselves and their families.	0	4	0	0	0	0	4	0	0	0	3348	3444	\N	1	\N	1	1646	Those who have escaped poverty through enlisted service.
7	Entrepreneurs	2	Civire are not usually known for their business endeavors, but when they do go into business they conduct themselves with the same aggressiveness and confidence as they do in battle. To them, business is war, to be pursued with warrior-like vigilance and ruthlessness.	0	0	0	4	0	0	0	0	4	0	3380	3320	\N	10	\N	\N	1647	Warriors of the board room.
8	Mercs	2	Civire love the brutality of battle and take every opportunity to engage in one. This is the reason why so many of them sell their services as mercenaries - it promises a constant supply of combat. For many families, a mercenary career has become mandatory for every member before he can settle down for a quiet family life.	0	4	0	0	0	0	4	0	0	0	3426	3320	\N	10	\N	\N	1648	Guns for hire to the highest bidder.
9	Dissenters	2	The cold discipline of Caldari society does not appeal to everyone, nor is everyone happy with the stranglehold the mega-corporations have on everyday life. These people are not rebellious, but have for years been trying to actively change the system from within. One of these days the State will want to deal with them once and for all.	0	2	2	0	0	0	2	2	0	0	3355	3320	\N	10	\N	\N	1649	Unhappy cogs in the capitalist machine.
10	Merchandisers	1	There is nothing the Deteis love more than having total control over all their activities and this holds true for producing items. They want to master every aspect of the process, from mining the materials, through the actual production, to the distribution and marketing.	0	0	0	4	0	0	0	0	4	0	3380	3416	\N	1	\N	\N	1650	Purveyors of your daily life.
11	Scientists	1	The Deteis beautifully combine efficiency with inventiveness, making them superb researchers and scientists. It's the ability of the Deteis to continuously create hi-tech devices and the combat abilities of the Civire that together make the Caldari State such a formidable force.	1	0	0	0	3	1	0	0	0	3	3402	3416	\N	1	\N	\N	1651	Combining efficiency with inventiveness, Deteis scientists are on the cutting edge.
12	Tube Child	1	Acutely aware of the small population of the Caldari State in comparison with the sprawling Gallente Federation, the Deteis have for decades utilized artificial procreation to increase their population. These tube-children are then raised in inhospitable, State-run orphanages, making them tough and self-reliant.	0	4	0	0	0	0	4	0	0	0	3374	3416	\N	1	\N	\N	1652	Citizens of the State, born and bred.
13	Activists	7	The common Gallente citizen is extremely politically aware in comparison with citizens of other nations. To outsiders, it seems like each and every Gallentean is fighting for one issue or another - anti-corruption, pro-war, anti-pollution, pro-Federation - anything and everything is worth at least one good rally and a general strike.	0	0	4	0	0	0	0	4	0	0	3355	3437	\N	1	\N	\N	1653	Making the world a better place, one rally at a time.
14	Miners	7	The insatiable Gallente industry demands massive amounts of minerals for its day-to-day operation. The Federation, loath to be dependent on other races, encourages asteroid mining on a large scale. The sense of independence gained while mining your own minerals appeals greatly to the individualistic Gallenteans.	0	0	0	4	0	0	0	0	4	0	3386	3437	\N	1	\N	\N	1654	The backbone of a booming industry.
15	Immigrants	7	Nowhere are honest immigrants as welcome as in the Gallente Federation, and no nation is as quick to assimilate them and mold them gently into their own. Hard-working immigrants of every race, creed and color can quickly make it on their own - the opportunities are plentiful.	2	2	0	0	0	2	2	0	0	0	3443	3437	\N	1	\N	\N	1655	Recent arrivals to the land of plenty.
16	Artists	8	It is widely believed that the introvert Intaki create the most stunning and thought provoking art around. They've revolutionized many art forms and created new ones, such as metapaints and touch sculpture. Intaki artists seem to have a unique ability to create and convey unparalleled beauty of a sort that's universal to all human races.	2	0	2	0	0	2	0	2	0	0	3374	3427	\N	1	\N	\N	1656	Intaki sculptors and painters are among the most revered artists in the world.
17	Diplomats	8	Since their inauguration into the Federation, the Intaki have slowly established a reputation as superb diplomats, negotiators and bureaucrats. In the tense and often violent world of international politics, these qualities can be of vital importance.	0	0	4	0	0	0	0	4	0	0	3355	3427	\N	1	\N	\N	1657	Those who build bridges between cultures.
18	Reborn	8	Although people in risky positions (such as capsuleers) use clones, the general Intaki public refrains from using them. Instead they have a unique method for transferring the personality of a dying person into a newborn baby. Steeped in tradition and perfected with technology, the Reborn process is the ideal Intaki vision of the afterlife.	0	0	0	4	0	0	0	0	4	0	3402	3427	\N	1	\N	\N	1658	Those who have been There and Back.
19	Tinkerers	3	The Sebiestors are the engineers and inventors of the Minmatars. They are especially adept at taking various ideas and techniques and molding them into their own special designs. Some Sebiestors seem to have an uncanny empathy with the ways things work and tick, making them extremely competent tinkerers.	0	0	0	0	4	0	0	0	0	4	3413	3393	\N	\N	\N	\N	1659	Natural engineers and inventors.
20	Traders	3	Many Sebiestor traders live like nomads and travel the width and breadth of the world in search of quick profit. They seldom settle down to exploit a prosperous trade route for long, always moving on to seek the big payoff that will make them rich beyond their wildest dreams.	0	0	4	0	0	0	0	4	0	0	3443	3393	\N	1	\N	\N	1660	Nomadic merchants looking to strike it rich.
21	Rebels	3	While most Matari are just trying to establish some sort of a normal life since the Rebellion, many are unwilling to forgive the Amarrians or to forget their atrocities. Fighting to free the millions of Matari still enslaved by the Amarrians, the rebels are building hidden bases close to Amarrian borders.	3	1	0	0	0	3	1	0	0	0	3449	3393	\N	1	\N	\N	1661	Those who refuse to forget.
22	Workers	4	The majority of Brutors have a modest background - that of working the fields, mines and factories of the Republic (and before that, those of the Amarr Empire).  Still they take pride in their jobs, and they are expert craftsmen and builders.	0	0	0	4	0	0	0	0	4	0	3380	3450	\N	1	\N	\N	1662	Men and women of the fields, mines and factories.
23	Tribal Traditionalists	4	The Brutor clan was treated harshly while the Matari were under the yoke of the Amarr Empire. This strengthened their bond with their cultural heritage, the only thing the Amarrians couldn't take away from them.	0	3	1	0	0	0	3	1	0	0	3348	3450	\N	1	\N	\N	1663	Staying true to the way.
24	Slave Child	4	The many millions of slaves within the Amarr Empire dream of escape, especially for their children. Every year thousands of newly-born slave children are smuggled out of the Empire into Minmatar space, where foster parents raise them.	2	2	0	0	0	2	2	0	0	0	3303	3450	\N	1	\N	\N	1664	From the cold to the fold.
25	Elders	9	The Elders were one of the first groups to use genetic engineering for a special purpose, namely that of slowing the aging process. Once, the Elders were a prominent political force in the Jovian society, but after they brought about the fall of the first Jovian empire they have become more reclusive. Elders can become many centuries old, it's uncertain exactly how old they can become, but some suggest they can outlive even members of the Amarrian royal families.	0	3	0	1	0	0	3	0	1	0	3363	3755	\N	\N	\N	\N	\N	
26	Unsullied	9	Genetic engineering has through the centuries transformed Jovian society in every aspect imaginable. Many Jovians believe that enough has been done. The Unsullied is a group of Jovians that have rejected further generic experiments and instead adopt conventional methods to deal with sickness and old age. They are advocates of cyber-implants and want to use machines instead of genes in the search for better life.	0	0	4	0	0	0	0	4	0	0	3355	3392	\N	\N	\N	\N	\N	
27	Stasis People	9	For many Jovians their race is in the twilight of their greatness. Ever since the fall of the first empire the Jovian society have been in a slow, steady decline. Most blame the Jovian Disease for this and believe that the Jovians can only hope to turn the tide once a cure for the disease has been found. The Stasis People are Jovians that voluntarily go into cryo-stasis for decades or centuries, hoping that when they wake a bright and better world will greet them.	4	0	0	0	0	4	0	0	0	0	3378	3413	\N	\N	\N	\N	\N	
28	Existentialists	10	The Existentialists are the most energetic and vociferous Jovian group. They live for the moment and are always ready to experiment, even with their own bodies. To them, nothing is sacred. The Existentialists tend to have little to do with the other races, as they find them boring and uninspiring.	1	0	0	0	3	1	0	0	0	3	3348	3426	\N	\N	\N	\N	\N	
29	Puritan	10	Many Jovians dream of returning to their genetic roots, now long since lost during the Shrouded Days. Those that are most active in their search for the 'untainted' Jovian genes are called the Puritans. In the hope of cleansing the nation of the Jovian Disease the Puritans try out ever-more outrageous genetic engineering stunts, often with quite unexpected results. But unlike the Existentialists the genetic engineering of the Puritans has the specific aim to return the human element to the Jovians, instead of being just narcissistic in nature.	0	0	0	4	0	0	0	0	4	0	3380	3355	\N	\N	\N	\N	\N	
30	Lab Rat	10	All Jovians are artificially conceived. In most cases a family unit is involved, donating genes, taking care of the rearing and so on, but this is not always so. Often, persons are conceived for some altruist reasons, usually research purposes. These Jovians are treated the same as everyone else, but they tend to be a little 'off', due to the clinical way of their conceivement.	0	4	0	0	0	0	4	0	0	0	3300	3404	\N	\N	\N	\N	\N	
31	Inventors	11	Creativity is a prized attribute amongst the Achur, as inventions are considered spiritual rather than strictly scientific in nature. Only those in touch with themselves and the universe can ‘tap’ into the universal consciousness and return with novel ideas.	0	0	0	0	4	0	0	0	0	4	3402	3403	\N	\N	\N	\N	3025	Those who are sufficiently attuned with the universe to receive its idea-gifts.
32	Monks	11	Thousands of monasteries are scattered around Saisio III, operated by dozens of different monastic orders. While each order has its own code of conduct regarding member behaviour, celibacy and other issues, they all agree on one thing; only by perfecting the body can you perfect the soul.	2	2	0	0	0	2	2	0	0	0	3449	3403	\N	\N	\N	\N	3027	Aspirants of the Achur-way in all its different forms and flavors.
33	Stargazers	11	While the spiritualism exercised by the Achur is not an organized religion in any sense, the Achura nation still holds seers and visionaries in high esteem. While the Achur are realistic enough not to attribute them with supernatural prophetic powers, these individuals are still believed to possess uncanny understanding of what makes the universe, and humans, tick.	1	0	0	3	0	1	0	0	3	0	3413	3403	\N	\N	\N	\N	3026	Seers of that which lies hidden.
34	Sang Do Caste	12	The Sang Do caste (translates as overlords) is the ruling class in Jin-Mei society.  They rule with a benevolent hand and most are noble and charitable. With easy demeanors and insightful natures, they have a distinct knack for inspiring loyalty in those under their dominion.	0	3	1	0	0	0	3	1	0	0	3348	3374	\N	\N	\N	\N	3028	The Sang Do are the ruling class of Jin-Mei society.
35	Saan Go Caste	12	The Saan Go caste (translates as standing high) are just below the Sang Do caste in this social hierarchy of the Jin-Meis. They are commonly found as governmental officials, administration officers, police commissioners and the like. They are resilient and amiable, generally well educated and possessing good common sense.	0	0	0	2	2	0	0	0	2	2	3355	3374	\N	\N	\N	\N	3029	The Saan Go are the administrative class of the Jin-Mei social hierarchy.
36	Jing Ko Caste	12	The Jing Ko caste (translates as good spirit) is the proverbial middle-class of Jin-Mei society. While most people that belong to this caste toil in obscurity all their life, a select few of exceptional talent manage to rise above the masses. These individuals usually attach themselves to an upper class patron, which paves the way for them to receive the education and career opportunities they merit.	4	0	0	0	0	4	0	0	0	0	3300	3374	\N	\N	\N	\N	3030	The Jing Ko are the middle class of the strictly regimented Jin-Mei society.
37	Cyber Knights	13	Many of the Khanid want to keep their warriors competitive, but the only way to do so in the modern world is through massive body enhancements. The extensive knowledge of cyberimplants possessed by the Amarrians has proven handy in this regard. Some Khanids still aim to excel in physical combat, while the more progressive ones seek to become masters of modern warfare.	3	0	0	0	1	3	0	0	0	1	3303	3316	\N	\N	\N	\N	3031	Chrome crusaders, bred for tactical superiority.
38	Unionists	13	A number of Khanid were unhappy with the break from the Amarr Empire. While they never succumbed to insurgence, they are now rejoicing at the improving relations with the Empire and are hoping the two nations can unite once more. They’re willing to do what it takes for that to happen, including taking on the common enemies of the Empire and the Kingdom.	0	0	2	0	2	0	0	2	0	2	3355	3316	\N	\N	\N	\N	3032	Those who would see the Khanid Kingdom and the Amarr Empire joined.
39	Zealots	13	The Khanid are not known to be as religious-minded as the Amarrians, but when they are they tend to be even more fanatical. Religious Khanids are often involved in cults of some sort, usually ones based more or less on the Scriptures. The Amarrians regard religious Khanids with suspicious interest; on one hand they are alarmed by the extremism often shown by the Khanids, but on the other the religious fervor displayed often results in deep theosophical insights.	0	2	0	2	0	0	2	0	2	0	3348	3316	\N	\N	\N	\N	3033	Religious fanatics who pursue their faith with fervor.
40	Drifters	14	The wanderlust is still strong with many Vherokiors. While most have managed to curb their lust for adventure, there are those that can never settle down in one place for long. Never at rest, they are constantly lured by the horizon - for there are places to be seen and riches to be discovered.	2	0	0	0	2	2	0	0	0	2	3449	3385	\N	\N	\N	\N	3036	Wandering the world in search of adventure.
41	Mystics	14	The Vherokiors have always seemed a bit odd to the other Minmatar tribes, doubly so when it comes to those of them with mystical inclinations. Vherokior shamans are both revered and feared by the Minmatars. They possess insights that can be of great help to people, insights that can also grant them great power.	0	3	0	0	1	0	3	0	0	1	3374	3385	\N	\N	\N	\N	3034	Keepers of sacred traditions, held in great respect.
42	Retailers	14	Walk into any dingy little eatery in Minmatar space and odds are it’s owned and operated by a Vherokior. The same goes for any other small business establishment in the Republic. The Vherokiors have been notorious peddlers since their caravan days. They usually run a family business and are seldom inclined to create big corporations.	0	0	1	3	0	0	0	1	3	0	3443	3385	\N	\N	\N	\N	3035	Small business owners and purveyors of everyday goods.
\.


--
-- Name: chrAncestries chrAncestries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrAncestries"
    ADD CONSTRAINT "chrAncestries_pkey" PRIMARY KEY ("ancestryID");


--
-- PostgreSQL database dump complete
--

\unrestrict FqZ42ZXbuf3YJZkKoWJ9lBpcVy2S8ekq7xKGoedrLo7tKgEqPCSceYKMgK5fA1c

