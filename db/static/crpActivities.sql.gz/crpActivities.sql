-- crpActivities: Trinity 1.0 static data (tools/trinity_static.py)
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

CREATE TABLE public."crpActivities" (
    "activityID" integer,
    "activityName" text,
    description text
);

COPY public."crpActivities" ("activityID", "activityName", description) FROM stdin;
1	Agriculture	
2	Construction	
3	Mining	
4	Chemical	
5	Military	
6	Biotech	
7	Hi-Tech	
8	Entertainment	
9	Shipyard	
10	Warehouse	
11	Retail	
12	Trading	
13	Bureaucratic	
14	Political	
15	Legal	
16	Security	
17	Financial	
18	Education	
19	Manufacture	
20	Disputed	
\.

ALTER TABLE ONLY public."crpActivities"
    ADD CONSTRAINT "crpActivities_pkey" PRIMARY KEY ("activityID");
