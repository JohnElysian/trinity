--
-- PostgreSQL database dump
--

\restrict ghTb4HXkQJKiaKfunNJAx0xXe9WTS9ELubPu7bFfs4EsY5cZP0wWoBluHOEbyGG

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: eveUnits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."eveUnits" (
    "unitID" integer NOT NULL,
    "unitName" text,
    "displayName" text,
    description text
);


--
-- Data for Name: eveUnits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."eveUnits" ("unitID", "unitName", "displayName", description) FROM stdin;
1	Length	m	Meter
2	Mass	kg	Kilogram
3	Time	sec	Second
4	Electric Current	A	Ampere
5	Temperature	K	Kelvin
6	Amount Of Substance	mol	Mole
7	Luminous Intensity	cd	Candela
8	Area	m2	Square meter
9	Volume	m3	Cubic meter
10	Speed	m/sec	Meter per second
11	Acceleration	m/sec	Meter per second squared
12	Wave Number	m-1	Reciprocal meter
13	Mass Density	kg/m3	Kilogram per cubic meter
14	Specific Volume	m3/kg	Cubic meter per kilogram
15	Current Density	A/m2	Ampere per square meter
16	Magnetic Field Strength	A/m	Ampere per meter
17	Amount-Of-Substance Concentration	mol/m3	Mole per cubic meter
18	Luminance	cd/m2	Candela per square meter
19	Mass Fraction	kg/kg = 1	Kilogram per kilogram, which may be represented by the number 1
101	Milliseconds	ms	
102	Millimeters	mm	
103	MegaPascals		
104	Multiplier	x	Indicates that the unit is a multiplier.
105	Percentage	%	
106	Teraflops	tf	
107	MegaWatts	MW	
108	Inverse Absolute Percent	%	Used for resistance.\\n0.0 = 100% 1.0 = 0%
109	Modifier Percent	%	Used for multipliers displayed as %\\n1.1 = +10%\\n0.9 = -10%
111	Inversed Modifier Percent	%	Used to modify damage resistance. Damage resistance bonus.\\n0.1 = 90%\\n0.9 = 10%
112	Radians/Second	rad/sec	Rotation speed.
113	Hitpoints	HP	
114	capacitor units	Energy	
115	groupID	groupID	
116	typeID	typeID	
117	Sizeclass	1=small 2=medium 3=l	
118	Ore units	Ore units	
119	attributeID	attributeID	
120	attributePoints	points	
121	realPercent	%	Used for real percentages, i.e. the number 5 is 5%
122	Fitting slots		
123	trueTime	sec	Shows seconds directly
124	Modifier Relative Percent	%	Used for relative percentages displayed as %
125	Newton	N	
126	Light Year	ly	
127	Absolute Percent	%	0.0 = 0% 1.0 = 100%
128	Drone bandwidth	Mbit/sec	Mega bits per second
\.


--
-- Name: eveUnits eveUnits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."eveUnits"
    ADD CONSTRAINT "eveUnits_pkey" PRIMARY KEY ("unitID");


--
-- PostgreSQL database dump complete
--

\unrestrict ghTb4HXkQJKiaKfunNJAx0xXe9WTS9ELubPu7bFfs4EsY5cZP0wWoBluHOEbyGG

