--
-- PostgreSQL database dump
--

\restrict 5yLk6Jv69Z2xb6W0MPVMlM9mWmq1WpHgyA9fGdu0pQsEFSmCSi5kjhXbsLQaqlQ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mapUniverse; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."mapUniverse" (
    "universeID" integer NOT NULL,
    "universeName" text,
    x double precision,
    y double precision,
    z double precision,
    "xMin" double precision,
    "xMax" double precision,
    "yMin" double precision,
    "yMax" double precision,
    "zMin" double precision,
    "zMax" double precision,
    radius double precision
);


--
-- Data for Name: mapUniverse; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."mapUniverse" ("universeID", "universeName", x, y, z, "xMin", "xMax", "yMin", "yMax", "zMin", "zMax", radius) FROM stdin;
9		-7.8414612025763e+16	4.00068382454404e+16	1.87911133534779e+16	-4.49013589606488e+17	2.92184365554962e+17	-3.13915018760047e+16	1.11405178366885e+17	-4.33602446107849e+17	4.7118467281480403e+17	4.52393559461327e+17
\.


--
-- Name: mapUniverse mapUniverse_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."mapUniverse"
    ADD CONSTRAINT "mapUniverse_pkey" PRIMARY KEY ("universeID");


--
-- PostgreSQL database dump complete
--

\unrestrict 5yLk6Jv69Z2xb6W0MPVMlM9mWmq1WpHgyA9fGdu0pQsEFSmCSi5kjhXbsLQaqlQ

