--
-- PostgreSQL database dump
--

\restrict uHHnCUYJglHktMM0pQrTe0KSGhrI8KT4Sr6e4t9c7mAQ7Lj8URgNOAAk1Jekdwu

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: staStationTypes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."staStationTypes" (
    "stationTypeID" integer NOT NULL,
    "dockingBayGraphicID" integer,
    "hangarGraphicID" integer,
    "dockEntryX" integer,
    "dockEntryY" integer,
    "dockEntryZ" integer,
    "dockOrientationX" integer,
    "dockOrientationY" integer,
    "dockOrientationZ" integer,
    "operationID" integer,
    "officeSlots" integer,
    "reprocessingEfficiency" double precision,
    conquerable double precision
);


--
-- Data for Name: staStationTypes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."staStationTypes" ("stationTypeID", "dockingBayGraphicID", "hangarGraphicID", "dockEntryX", "dockEntryY", "dockEntryZ", "dockOrientationX", "dockOrientationY", "dockOrientationZ", "operationID", "officeSlots", "reprocessingEfficiency", conquerable) FROM stdin;
16	\N	\N	101	0	-1498	0	0	-1351	\N	\N	\N	0.0
17	\N	\N	0	0	-2300	0	0	-1015	\N	\N	\N	0.0
54	\N	241	36	6854	-7948	0	0	-1	\N	\N	\N	0.0
56	\N	1210	0	-5000	4800	0	-1	0	\N	\N	\N	0.0
57	\N	244	0	6144	-3100	0	0	1	\N	\N	\N	0.0
58	\N	241	0	0	0	0	0	-1	\N	\N	\N	0.0
59	\N	242	0	0	0	0	0	-1	\N	\N	\N	0.0
1529	\N	241	-170	3217	-12112	0	0	-1	\N	\N	\N	0.0
1530	\N	241	11384	7499	-270	1	0	0	\N	\N	\N	0.0
1531	\N	241	2447	-3841	-2988	1	0	0	\N	\N	\N	0.0
1926	\N	1075	0	11158	0	0	1	0	\N	\N	\N	0.0
1927	\N	1075	0	-37007	0	0	-1	0	\N	\N	\N	0.0
1928	\N	1075	0	-21316	0	0	-1	0	\N	\N	\N	0.0
1929	\N	1075	200	-12937	52	0	-1	0	\N	\N	\N	0.0
1930	\N	1075	-10709	-9721	-2069	0	-1	0	\N	\N	\N	0.0
1931	\N	1075	-13	-5689	0	0	-1	0	\N	\N	\N	0.0
1932	\N	1075	-1750	-9968	27	0	-1	0	\N	\N	\N	0.0
2496	\N	242	-2909	-1438	20657	0	0	1	\N	\N	\N	0.0
2497	\N	242	6299	2654	-11166	0	0	-1	\N	\N	\N	0.0
2498	\N	242	30416	-1172	3100	1	0	0	\N	\N	\N	0.0
2499	\N	242	11904	8452	-9744	1	0	0	\N	\N	\N	0.0
2500	\N	242	1390	27	27771	0	0	1	\N	\N	\N	0.0
2501	\N	242	17	3115	18255	0	0	1	\N	\N	\N	0.0
2502	\N	242	17	10096	12607	0	0	1	\N	\N	\N	0.0
3864	\N	1075	371	8566	-390	-1	0	0	\N	\N	\N	0.0
3865	\N	244	-1663	4799	6254	0	0	1	\N	\N	\N	0.0
3866	\N	244	9265	884	0	1	0	0	\N	\N	\N	0.0
3867	\N	1210	8445	208	-20040	0	0	-1	\N	\N	\N	0.0
3868	\N	1210	9956	1059	0	1	0	0	\N	\N	\N	0.0
3869	\N	244	10680	1007	0	1	0	0	\N	\N	\N	0.0
3870	\N	1210	9789	938	0	1	0	0	\N	\N	\N	0.0
3871	\N	241	123	-4044	17010	0	0	1	\N	\N	\N	0.0
3872	\N	241	-28558	-1159	2436	-1	0	0	\N	\N	\N	0.0
3873	\N	\N	-6	-335	3201	0	0	1015	\N	\N	\N	0.0
3874	\N	\N	0	-33	2923	0	-351	483	\N	\N	\N	0.0
3875	\N	\N	0	-32	-276	0	-290	399	\N	\N	\N	0.0
3876	\N	\N	0	0	-47	0	-2	892	\N	\N	\N	0.0
3877	\N	\N	0	0	0	0	0	-1948	\N	\N	\N	0.0
4023	\N	241	-27845	-1354	2399	-1	0	0	\N	\N	\N	0.0
4024	\N	241	-33431	-2574	2477	-1	0	0	\N	\N	\N	0.0
9856	\N	1075	-176	-11789	4116	0	0	1	\N	\N	\N	0.0
9857	\N	1075	2804	8566	-390	-5178	0	0	\N	\N	\N	0.0
9866	\N	242	-1500	405	-1800	-1602	885	-2205	\N	\N	\N	0.0
9867	\N	2303	-896	-26555	4800	0	-21214	0	\N	\N	\N	0.0
9868	\N	2067	0	6110	0	0	5078	0	\N	\N	\N	0.0
9873	\N	242	-1449	-10148	24	-1645	-4313	-10	\N	\N	\N	0.0
9874	\N	242	0	-9631	0	0	-14338	0	\N	\N	\N	0.0
10795	\N	1075	-1203	-18300	5400	0	-4616	0	\N	\N	\N	0.0
12242	\N	2067	0	5079	-5338	0	0	1	\N	\N	\N	1.0
12294	\N	2067	0	-6002	4509	0	-1	0	\N	\N	\N	1.0
12295	\N	2067	-1298	4860	6949	0	0	1	\N	\N	\N	1.0
19757	\N	2067	3454	-103	1666	1	0	0	\N	\N	\N	0.0
21642	\N	2067	331	-838	12617	0	0	1	48	8	\N	1.0
21644	\N	2067	-13209	88	237	-1	0	0	49	4	\N	1.0
21645	\N	2067	69	-190	2996	0	0	1	50	24	\N	1.0
21646	\N	2067	3454	-103	1666	1	0	0	51	6	0.35	1.0
22296	\N	1075	4674	14278	-650	-3327	0	0	\N	\N	\N	0.0
22297	\N	1075	64	-1249	1261	0	0	-3948	\N	\N	\N	0.0
22298	\N	1075	-294	-20500	2504	0	0	5255	\N	\N	\N	0.0
28075	\N	2067	-10537	88	237	-8575	0	0	49	\N	\N	0.0
\.


--
-- Name: staStationTypes staStationTypes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."staStationTypes"
    ADD CONSTRAINT "staStationTypes_pkey" PRIMARY KEY ("stationTypeID");


--
-- PostgreSQL database dump complete
--

\unrestrict uHHnCUYJglHktMM0pQrTe0KSGhrI8KT4Sr6e4t9c7mAQ7Lj8URgNOAAk1Jekdwu

