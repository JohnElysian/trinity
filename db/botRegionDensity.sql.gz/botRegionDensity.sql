--
-- PostgreSQL database dump
--

\restrict 4LzoUEY08g8w8zr2AB4tGMQjZJEuoJpsRgSPuWpY4DXF5i414e0OwQcg5y0Hf9j

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: botRegionDensity; Type: TABLE; Schema: public; Owner: rmr
--

CREATE TABLE public."botRegionDensity" (
    "regionID" integer NOT NULL,
    factor real DEFAULT 1 NOT NULL
);



--
-- Name: TABLE "botRegionDensity"; Type: COMMENT; Schema: public; Owner: rmr
--

COMMENT ON TABLE public."botRegionDensity" IS 'MADE: how much more or less the bots living in a region play than usual, set from the dashboard or /bots density (bots::control).';


--
-- Name: botRegionDensity botRegionDensity_pkey; Type: CONSTRAINT; Schema: public; Owner: rmr
--

ALTER TABLE ONLY public."botRegionDensity"
    ADD CONSTRAINT "botRegionDensity_pkey" PRIMARY KEY ("regionID");


--
-- PostgreSQL database dump complete
--

\unrestrict 4LzoUEY08g8w8zr2AB4tGMQjZJEuoJpsRgSPuWpY4DXF5i414e0OwQcg5y0Hf9j

