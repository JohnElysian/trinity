--
-- PostgreSQL database dump
--

\restrict oym74sSBlGQ5dvpK5FkhKuznkZPtdrfOe1FqDoOdv7NABmpavh0ZJUmu6yvS4Rf

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: moonScans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."moonScans" (
    "charID" integer NOT NULL,
    "moonID" integer NOT NULL,
    "scannedAt" bigint NOT NULL
);


--
-- Name: TABLE "moonScans"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."moonScans" IS 'MADE: moons each character has surveyed with a probe (svc::scan).';


--
-- Name: moonScans moonScans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."moonScans"
    ADD CONSTRAINT "moonScans_pkey" PRIMARY KEY ("charID", "moonID");


--
-- PostgreSQL database dump complete
--

\unrestrict oym74sSBlGQ5dvpK5FkhKuznkZPtdrfOe1FqDoOdv7NABmpavh0ZJUmu6yvS4Rf

