--
-- PostgreSQL database dump
--

\restrict mkGHn4K9XtfUG8DMxg9cZ0hWvh1TAhGBD9EOUJ6GAqLod4vf4aD8U2IUx08bkDx

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: deadspaceComplexes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."deadspaceComplexes" (
    "complexID" integer DEFAULT nextval('public.dyn_id_seq'::regclass) NOT NULL,
    "solarSystemID" integer NOT NULL,
    level smallint NOT NULL,
    seed bigint NOT NULL,
    x double precision NOT NULL,
    y double precision NOT NULL,
    z double precision NOT NULL,
    rooms smallint NOT NULL,
    cleared smallint DEFAULT 0 NOT NULL,
    "spawnedAt" bigint NOT NULL,
    expires bigint NOT NULL
);


--
-- Name: TABLE "deadspaceComplexes"; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public."deadspaceComplexes" IS 'MADE: generated deadspace complexes: where each lies, how hard it is, how far it has been cleared (complexes).';


--
-- Name: deadspaceComplexes deadspaceComplexes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."deadspaceComplexes"
    ADD CONSTRAINT "deadspaceComplexes_pkey" PRIMARY KEY ("complexID");


--
-- PostgreSQL database dump complete
--

\unrestrict mkGHn4K9XtfUG8DMxg9cZ0hWvh1TAhGBD9EOUJ6GAqLod4vf4aD8U2IUx08bkDx

