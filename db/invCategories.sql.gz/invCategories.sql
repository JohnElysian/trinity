--
-- PostgreSQL database dump
--

\restrict GoQK0aATv9mYb7nj5m8LaUmvmIPGx03cU4qLQ0pGHQGtoDaiPhGBRK6yBKQy6YW

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: invCategories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."invCategories" (
    "categoryID" integer NOT NULL,
    "categoryName" text,
    description text,
    "graphicID" integer,
    published integer
);


--
-- Data for Name: invCategories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."invCategories" ("categoryID", "categoryName", description, "graphicID", published) FROM stdin;
0	#System		\N	0
1	Owner		1	0
2	Celestial		6	1
3	Station		17	0
4	Material		399	1
5	Accessories		33	0
6	Ship		38	1
7	Module		67	1
8	Charge		171	1
9	Blueprint		194	1
10	Trading		195	0
11	Entity		\N	0
14	Bonus	Character creation bonuses.  Like innate skills but genetic rather than learned.	0	0
16	Skill	Where all the skills go under.	33	1
17	Commodity		0	1
18	Drone	Player owned and controlled drones.	0	1
20	Implant	Implant	0	1
22	Deployable		0	1
23	Structure	Player owned structure related objects	0	1
24	Reaction		0	1
25	Asteroid		\N	1
\.


--
-- Name: invCategories invCategories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."invCategories"
    ADD CONSTRAINT "invCategories_pkey" PRIMARY KEY ("categoryID");


--
-- PostgreSQL database dump complete
--

\unrestrict GoQK0aATv9mYb7nj5m8LaUmvmIPGx03cU4qLQ0pGHQGtoDaiPhGBRK6yBKQy6YW

