--
-- PostgreSQL database dump
--

\restrict jqENo4he3wZH7FgYi7ef4sUaeME2YOXoDxOhFtQuqLRRqiisN2Nsd5L8iunVq8H

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: chrRaces; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."chrRaces" (
    "raceID" integer NOT NULL,
    "raceName" text,
    description text,
    "skillTypeID1" integer,
    "typeID" integer,
    "typeQuantity" integer,
    "graphicID" integer,
    "shortDescription" text
);


--
-- Data for Name: chrRaces; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."chrRaces" ("raceID", "raceName", description, "skillTypeID1", "typeID", "typeQuantity", "graphicID", "shortDescription") FROM stdin;
1	Caldari	Ruled by a handful of mega corporations, the Caldari State is the epitome of civil duty and efficiency, where ruthless capitalism leaves no room for human rights or feelings. They are brutally efficient fighters, giving their opponents no chance of retaliation. Through grit and superior technology, the State fought the much larger Gallente Federation to a standstill.	3330	215	100	1439	The Caldari State is the epitome of civil duty and ruthless militaristic efficiency.
2	Minmatar	Enslaved by the Amarr Empire for centuries, the Minmatar Republic now revels in its relatively newfound freedom, fighting for its claim as a major power. Steeped in a deep-rooted tribal society, the Matari display vehement attachment to their kindred. They will never forget their lost brothers and sisters, still enslaved by the Amarr Empire.	3329	178	100	1440	Formerly enslaved by the Amarr, the Minmatar are a nation of tough, no-nonsense tribalists.
4	Amarr	Amarr is a vast and ancient empire, with the Amarr Emperor sitting at the head of a feudal society. It is rich in history and traditions, with a caste system that is cruel to those on the bottom, but kind to those at the top. Centuries ago, during a time known as the Reclaiming, the Amarr Empire enslaved several nations, including the Minmatars, but has calmed down in recent times.	3331	\N	\N	1442	Amarr is a vast and ancient empire, solely devoted to God and Emperor.
8	Gallente	The Gallente Federation is the only true democracy in the universe at present, and its inhabitants regard themselves as champions of freedom and liberty. Their human touch makes them excellent traders and media moguls. Forged in fire in a war against the Caldari State, the Federation still depends on its mighty drone fleets to defend its beliefs against encroaching anarchy.	3328	215	100	1441	Championing freedom and liberty across the universe, the Gallente Federation is the only true democracy currently in existence.
16	Jove	The most mysterious and elusive of all the universe's peoples, the Jovians number only a fraction of any of their neighbors, but their technological superiority makes them powerful beyond all proportion.	\N	\N	\N	\N	
32	Pirate		\N	\N	\N	\N	
\.


--
-- Name: chrRaces chrRaces_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."chrRaces"
    ADD CONSTRAINT "chrRaces_pkey" PRIMARY KEY ("raceID");


--
-- PostgreSQL database dump complete
--

\unrestrict jqENo4he3wZH7FgYi7ef4sUaeME2YOXoDxOhFtQuqLRRqiisN2Nsd5L8iunVq8H

