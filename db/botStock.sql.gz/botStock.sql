--
-- PostgreSQL database dump
--

\restrict gRbFDNBVbeckSdi9DxaGjTkIj07YdIL1oIWH9Veto0Kz7MSaoT6M26CDnk4MKeZ

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: botStock; Type: TABLE; Schema: public; Owner: rmr
--

CREATE TABLE public."botStock" (
    "stationID" integer NOT NULL,
    "typeID" integer NOT NULL,
    quantity bigint DEFAULT 0 NOT NULL
);



--
-- Name: TABLE "botStock"; Type: COMMENT; Schema: public; Owner: rmr
--

COMMENT ON TABLE public."botStock" IS 'MADE: goods the bot simulation holds in each station: ore mined, minerals refined, hulls built (bots::economy).';


--
-- Name: botStock botStock_pkey; Type: CONSTRAINT; Schema: public; Owner: rmr
--

ALTER TABLE ONLY public."botStock"
    ADD CONSTRAINT "botStock_pkey" PRIMARY KEY ("stationID", "typeID");


--
-- PostgreSQL database dump complete
--

\unrestrict gRbFDNBVbeckSdi9DxaGjTkIj07YdIL1oIWH9Veto0Kz7MSaoT6M26CDnk4MKeZ

