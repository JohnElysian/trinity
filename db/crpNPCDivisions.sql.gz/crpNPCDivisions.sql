--
-- PostgreSQL database dump
--

\restrict rMkP9IRaVL1YnOjPfDoETF81Oit8X3jsbprqSfbljYNotZcRkBqvfO2MddRJlvx

-- Dumped from database version 16.15
-- Dumped by pg_dump version 16.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: crpNPCDivisions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."crpNPCDivisions" (
    "divisionID" integer NOT NULL,
    "divisionName" text,
    description text,
    "leaderType" text
);


--
-- Data for Name: crpNPCDivisions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."crpNPCDivisions" ("divisionID", "divisionName", description, "leaderType") FROM stdin;
1	Accounting		CFO
2	Administration		CFO
3	Advisory		Chief Advisor
4	Archives		Chief Archivist
5	Astrosurveying		Survey Manager
6	Command		COO
7	Distribution		Distribution Manager
8	Financial		CFO
9	Intelligence		Chief Operative
10	Internal Security		Commander
11	Legal		Principal Clerk
12	Manufacturing		Assembly Manager
13	Marketing		Market Manager
14	Mining		Mining Coordinator
15	Personnel		Chief of Staff
16	Production		Production Manager
17	Public Relations		Chief Coordinator
18	R&D		Chief Researcher
19	Security		Commander
20	Storage		Storage Facilitator
21	Surveillance		Chief Scout
\.


--
-- Name: crpNPCDivisions crpNPCDivisions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."crpNPCDivisions"
    ADD CONSTRAINT "crpNPCDivisions_pkey" PRIMARY KEY ("divisionID");


--
-- PostgreSQL database dump complete
--

\unrestrict rMkP9IRaVL1YnOjPfDoETF81Oit8X3jsbprqSfbljYNotZcRkBqvfO2MddRJlvx

